

export type IMyTextElementTypes = 'h1'  | 'h2' |  'h3' | 'p' | 'span';

export interface IDefIcon {
  name: string | null;
  color: string | null;
  size: any;
  weight: any;
}