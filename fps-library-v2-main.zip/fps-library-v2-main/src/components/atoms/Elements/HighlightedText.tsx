
import * as React from 'react';


  // Could be used to add ellipse:  https://semicolon.dev/tutorial/css/text-overflow-ellipsis-doesnt-work
  // Need to test though.
  const ellipseStyle: React.CSSProperties = {
    minWidth: '0px',
    whiteSpace: 'pre-wrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  }

  /**
 * Copied from ECStorage
 * Super cool solution based on:  https://stackoverflow.com/a/43235785
 * @param text 
 * @param highlight 
 */

   export function getHighlightedText( text: string, highlight: string ) {
    // <div dangerouslySetInnerHTML={{ __html: this.state.showPanelItem.WikiField }} />
    // Split on highlight term and include term into parts, ignore case
    if (!highlight || highlight.indexOf('*') > -1 ) {
      return text;

    } else if ( !text ) {
      // added for https://github.com/mikezimm/Compliance/issues/118
      console.log('FPS-getHighlightedText text does not exist for highlight:', highlight );
      return '';

    } else {
      // Found that ID is a number and if it's passed in, it will crash

      const nan = isNaN( text as any ) ? true : false;
      let thisText = `${text}` ;
      if ( typeof text !== 'string' && nan === true ) {
        console.log( `getHighlightedText: this is not a string or number.. converting to string now. `, text );
        thisText = JSON.stringify( text );
      }

      const parts = thisText.split(new RegExp(`(${highlight})`, 'gi'));
      return <span> { parts.map((part, i) => 
        <span key={i} style={part.toLowerCase() === highlight.toLowerCase() ? { fontWeight: 'bold', backgroundColor: 'yellow' } : {} }>
          { part }
        </span>)
      } </span>;
    }

  }
