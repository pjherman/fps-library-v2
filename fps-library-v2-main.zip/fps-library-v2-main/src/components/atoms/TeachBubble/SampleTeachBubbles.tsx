

// import { IMinTeachBubble } from "@mikezimm/fps-library-v2/lib/components/atoms/TeachBubble/IMinTeachBubble";
import { IMinTeachBubble, ReplaceWpId } from "./IMinTeachBubble";

export type ITeachGroups = 'MainPivot' | 'Contacts' | 'Site';

const MainPivot: ITeachGroups = 'MainPivot';
const Contacts: ITeachGroups = 'Contacts';

const defaultMessage: string = `Click for more information`;

export const AllTeachBubbles: IMinTeachBubble[] =     [
  {
    // step: 0,
    // target: `#ComplHomeBanner${wpId}`,
    target: `#${MainPivot}Home${ReplaceWpId}`,
    headline: `Quick summary of your site`,
    message: `This provides a quick overview of what a recent audit found on your site.`,
  }, {
    // step: 0,
    target: `#${Contacts}Committee${ReplaceWpId}`,
    headline: `'Committee' tab`,
    message: ``,
    // message: `${defaultMessage}`,
  }, {
    // step: 1,
    target: `#${Contacts}Coordinators${ReplaceWpId}`,
    headline: `'Coordinators' tab`,
    message: ``,
    // message: `${defaultMessage}`,
  },{
    // step: 0,
    target: `#${MainPivot}Details${ReplaceWpId}`,
    headline: `'Details' Tab`,
    message: ``,
    // message: `${defaultMessage}`,
  },
]
