

import { IMinTeachBubble, ReplaceWpId } from "./IMinTeachBubble";
import { check4This } from "@mikezimm/fps-pnp2/lib/services/sp/CheckSearch";

/**
 * 
 * @param AllTeachBubbles 
 * @param wpId 
 * @param teach - Beginning of Ids ( LESS # symbol which is automatically added )
 * @returns 
 */
export function getTeachBubbles( AllTeachBubbles: IMinTeachBubble[] , wpId: string, teach: string ): IMinTeachBubble[] {
  let theseBubbles: IMinTeachBubble[] = AllTeachBubbles.filter( bubble => { return bubble.target.indexOf( `#${teach}`) === 0 } );
  theseBubbles = theseBubbles.map( bubble => { 
    // const newBubble = bubble;
    // newBubble.target = newBubble.target.replace( ReplaceWpId, wpId );
    // return newBubble;
    bubble.target = bubble.target.replace( ReplaceWpId, wpId );
    return bubble;
  });
  if ( check4This(`showBubbles`) === true ) console.log( console.log( 'showBubbles getTeachBubbles', theseBubbles ) );
  return theseBubbles;
}
