export interface IPersonaCardState {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  livePersonaCard: any;
  pictureUrl: string;
}
