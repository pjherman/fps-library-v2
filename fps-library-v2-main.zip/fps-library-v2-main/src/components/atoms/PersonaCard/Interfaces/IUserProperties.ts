export interface IUserProperties {
  Department: string;
  MobilePhone?: string;
  PictureUrl: string;
  Title: string;
  DisplayName: string;
  Email: string;
  WorkPhone?: string;
  Location?: string;
  isSiteAdmin?: boolean;
  isGuest?: boolean;
}
