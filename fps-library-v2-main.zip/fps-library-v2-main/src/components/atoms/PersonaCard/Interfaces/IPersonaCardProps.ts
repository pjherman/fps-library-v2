import { WebPartContext } from "@microsoft/sp-webpart-base";
import { IUserProperties } from "./IUserProperties";
import {
  PersonaSize,
} from 'office-ui-fabric-react/lib/Persona';
export interface IPersonaCardProps {
  context: WebPartContext;
  profileProperties: IUserProperties;
  //2020-11-24:  Added for adjusting card size
  size: PersonaSize;
  iconSize: number;
  iconTextSize: number;

  // This property is option to pass in theme from site for border color styles.documentCardDefault .
  // Should add this class to main react component styles at the top:
  // then pass styles.borderColorDarkTheme in to this property

  // .borderColorDarkTheme {
  //   border-color: $ms-color-themeDark !important;
  // }

  borderColorMsColorThemeDarkClass?: string;
}
