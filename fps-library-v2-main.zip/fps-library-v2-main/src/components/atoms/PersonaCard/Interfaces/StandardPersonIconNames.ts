
export const SiteAdminGroupName = 'SiteAdmins';
export const SiteAdminIconName = 'HeadsetSolid';

export const GuestsGroupName = 'Guests';
export const GuestsIconName = 'UserWarning';
