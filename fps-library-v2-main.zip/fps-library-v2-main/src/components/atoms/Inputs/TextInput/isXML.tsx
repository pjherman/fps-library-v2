
export function isXML(str: string): boolean {
  const parser = new DOMParser();
  const doc = parser.parseFromString(str, "text/xml");
  return doc.getElementsByTagName("parsererror").length === 0;
}

export function isHTML(str: string): boolean {
  const parser = new DOMParser();
  const doc = parser.parseFromString(str, "text/html");
  return doc.body.innerHTML !== "";
}
