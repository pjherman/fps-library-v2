
export function isValidJSON(str: string): boolean {
  try {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const jsonObject = JSON.parse(str);
    return true;
  } catch (e) {
    console.log('Invalid JSON string:', e);
    return false;
  }
}
