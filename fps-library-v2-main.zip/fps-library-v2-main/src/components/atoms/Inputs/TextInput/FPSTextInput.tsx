
/**
 * Credit where credit is due... 
 * I created this component with the VERY helpful Bing Chat and some iterations.
 * Great Help and shout out to Bing Chat!
 */

import { Icon } from 'office-ui-fabric-react/lib/Icon';
import * as React from 'react';
import { useState, useEffect } from 'react';
import { isXML } from './isXML';
import { formatXml } from './formatXml';
import { formatJSONString } from './formatJSONString';
import { ITextValidationType } from './ITextValidationType';
import { isValidJSON } from './isValidJSON';

const lineFeedRegex = /\n/g;

export function countLineFeeds( str: string ): number {
  const lineFeedCount = ( str.match(lineFeedRegex) || [] ).length;
  return lineFeedCount;
}

export function formatStringLike( str: string, format: ITextValidationType ) : string {
  let result: string = str;
  if ( format === 'json' ) {
    result = formatJSONString( str.replace( lineFeedRegex, '' ) );
  } else if ( format === 'html' || format === 'xml' ) {
    result = formatXml( str.replace( lineFeedRegex, '' ) );
  }
  return result;
}

export type ITextBackground = 'transparent' | 'yellow' | 'red';

function determineBGColor( text: string , format: ITextValidationType ): ITextBackground {
  let bgColor: ITextBackground = 'transparent';
  if ( typeof text !== 'string' ) return 'red';
  if ( text === null || text === undefined ) bgColor = 'transparent';
  if ( format === 'json' ) {
    if ( isValidJSON( text ) === false ) { bgColor = 'yellow' }
  } else if ( format === 'html' || format === 'xml' ) {
    if ( isXML( text ) === false ) { bgColor = 'yellow' }
  } else if ( format === 'spo' || format === 'spo-page' ) {
    const textLC = text.toLocaleLowerCase();
    if ( textLC.indexOf( '/sites/' ) !== 0 && textLC.indexOf( window.location.origin ) !== 0 ) bgColor = 'yellow';
    if ( format === 'spo-page' && bgColor === 'transparent' && textLC.indexOf( '.aspx' ) < 0 ) bgColor = 'yellow';
  }
  return bgColor;
}

function getCodeIconName( format: ITextValidationType  ): string {
  let iconName = '';
  if ( format === 'json' ) {
    iconName = 'Code';
  } else if ( format === 'xml' ) {
    iconName = 'Embed';
  } else if ( format === 'html' ) {
    iconName = 'FileCode';
  }
  return iconName;
}

export interface IFPSTextInput {
  title?: string;
  titleStyles?: React.CSSProperties;
  placeholder?: string;
  onTextChange?: (text: string) => void;
  defaultValue?: string; // Add a new prop for the default text value
  reactCSS?: React.CSSProperties;
  className?: string;
  description?: string; // Smaller text below input box
  validationType?: ITextValidationType;
  multiLine?: boolean;
}

/**
 * Your typical text input but with some common validations like JSON, XML, HTML, SPO (urls)
 * @param props 
 * @returns 
 */
const FPSTextInput: React.FC<IFPSTextInput> = ( props ) => {

  const { title, description, placeholder, onTextChange, defaultValue, validationType, multiLine } = props;
  const [ text, setText ] = useState<string> ( typeof defaultValue === 'string' ? formatStringLike( defaultValue , validationType ) : '' ); // Use the defaultValue prop as the initial state

  const handleTextChange = (event: React.ChangeEvent<HTMLTextAreaElement> | React.ChangeEvent<HTMLInputElement> ): void => {
    const newValue: string = event.target.value;
    setText( newValue );
    if (onTextChange) {
      onTextChange( newValue );
    }
  };

  // const background = validationType === 'json' && isValidJSON( text ) === false ? 'yellow' : 'transparent' ;
  const background = determineBGColor( text, validationType ) ;
  const height = multiLine === true ? `${countLineFeeds( text ) + 7 }em` : '2em';
  const titleStyles: React.CSSProperties = { fontSize: 'larger', fontWeight: '600', ... props.titleStyles };
  const descStyles: React.CSSProperties = { fontSize: 'smaller', };
  const iconName = getCodeIconName( validationType );
  const ReFormatIcon: JSX.Element = !iconName ? undefined :
    <span style={{ fontSize: 'larger', fontWeight: 600, padding: '5px', marginLeft: '3em', cursor: 'pointer' }} 
      onClick={ () => setText( formatStringLike( text , validationType ) ) }
      title = { `Reformat string as ${ validationType }`}>
      <Icon iconName={ iconName }/>
    </span>;
  return (
    <div style={ { width: '100%', ... props.reactCSS }} className={ props.className }>
      {/* The expression title && <h2>{title}</h2> is a shorthand way of conditionally rendering an <h2> element based on the value of the title variable. */}
      { title && <div style={ titleStyles }>{title} { ReFormatIcon } </div> }
      { multiLine === true ?
        <textarea style={{ width: '100%', height: height, background: background, transition: 'all 0.4s ease' }} value={text} onChange={handleTextChange} placeholder={placeholder} /> :
        <input type='text' style={{ width: '100%', height: height, background: background, transition: 'all 0.4s ease' }} value={text} onChange={handleTextChange} placeholder={placeholder} />
      }


      { description && <div style={ descStyles }>{description}</div> }
    </div>
  );
}

export default FPSTextInput;
