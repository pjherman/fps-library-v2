
export function formatJSONString(jsonString: string): string {
  try {
    // const jsonObject = JSON.parse( jsonString.replace( lineFeedRegex, '' ) );
    // return [ true, jsonString ];
    const jsonObject = JSON.parse(jsonString);
    return JSON.stringify(jsonObject, null, 2);
  } catch (e) {
    console.log('Invalid JSON string:', e);
    return jsonString;
  }
}
