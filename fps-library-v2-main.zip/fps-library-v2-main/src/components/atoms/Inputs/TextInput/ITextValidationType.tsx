
export type ITextValidationType = 'json' | 'html' | 'xml' | 'spo' | 'spo-page';
