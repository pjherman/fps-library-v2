
export const jiraIcon = 'https://cdn.onlinewebfonts.com/svg/img_117214.png';
