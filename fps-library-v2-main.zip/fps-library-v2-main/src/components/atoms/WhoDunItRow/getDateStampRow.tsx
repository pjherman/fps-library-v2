

import * as React from 'react';

require('@mikezimm/fps-styles/dist/fpsDateStamp.css');

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export interface ISavePropsItem extends Partial<any> {
  Author?: any;
  Editor?: any;

  FirstPublishedDate?: any;
  FirstPublishedDateD?: string;

  createdLoc?: string;
  createdD?: string;
  "Author/Title"?: string;

  modifiedLoc?: string;
  modifiedD?: string;
  "Editor/Title"?: string;

}

export interface ISavePropsRow {
  item: ISavePropsItem;
  value: 'Created' | 'Modified' | 'Published';
}

export function getDateStampRow( item: ISavePropsItem, value: 'Created' | 'Modified' | 'Published' ): JSX.Element {

  // const {  item, value } = props;

  let label = value;
  let time = '';
  let user = '';

  if ( value === 'Created' ) {
    time = item.modifiedLoc ? item.modifiedLoc : item.Modified;
    user = item[ 'Author/Title' ] ?  item[ 'Author/Title' ] :  item[ 'Author/Name' ] ?  item[ 'Author/Name' ] : 'Unknown User';

  } else if ( value === 'Modified' ) {
    time = item.createdLoc ? item.createdLoc : item.Created;
    user = item[ 'Editor/Title' ] ?  item[ 'Editor/Title' ] :  item[ 'Editor/Name' ] ?  item[ 'Editor/Name' ] : 'Unknown User';

  } else if ( value === 'Published' ) {
    time = item.FirstPublishedDate ? item.FirstPublishedDate : 'NOT YET PUBLISHED';
    user = item[ 'Editor/Title' ] ?  item[ 'Editor/Title' ] :  item[ 'Editor/Name' ] ?  item[ 'Editor/Name' ] : 'Unknown User';
  }

  const WhoDates = <div className={ 'fps-date-stamp' }>
    <div>{ label }</div> <div>{ time }</div> <div>{ user }</div>
  </div>;

  return WhoDates;
}