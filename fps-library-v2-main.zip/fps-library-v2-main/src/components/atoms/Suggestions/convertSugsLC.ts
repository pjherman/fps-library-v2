
import { ISuggestion } from "./ISuggestion";

/**
 * Originally copied from Compliance web part 2023-03-28
 * 
 * @param suggestions 
 * @param lowerCaseSuggestions - true will also convert the suggestions to suggestionsLC ( so buttons would show in lc )
 * @returns 
 */
export function convertSugsLC(suggestions: ISuggestion[], lowerCaseSuggestions: boolean, addSuggsToFinds: boolean ): ISuggestion[] {
  suggestions.map(suggestion => {

    if ( addSuggsToFinds === true ) {
      suggestion.finds = [ ...suggestion.finds, ...suggestion.suggestions ];
    }

    suggestion.findsLC = suggestion.finds.map(str => { return str.toLowerCase(); });

    if (suggestion.exclusions)
      suggestion.exclusionsLC = suggestion.exclusions.map(str => { return str.toLowerCase(); });

    if (lowerCaseSuggestions === true)
      suggestion.suggestionsLC = suggestion.suggestions.map(str => { return str.toLowerCase(); });

    // Added this for https://github.com/mikezimm/Compliance/issues/169 to clean up any duplicates
    const finds = suggestion.finds.filter(  (element, index) => { return suggestion.finds.indexOf(element) === index; } );
    suggestion.finds = finds;

    const singleSuggs = suggestion.suggestions.filter(  (element, index) => { return suggestion.suggestions.indexOf(element) === index; } );
    suggestion.suggestions = singleSuggs;

    const findsLC = suggestion.findsLC.filter(  (element, index) => { return suggestion.findsLC.indexOf(element) === index; } );
    suggestion.findsLC = findsLC;

    const suggestionsLC = suggestion.suggestionsLC.filter(  (element, index) => { return suggestion.suggestionsLC.indexOf(element) === index; } );
    suggestion.suggestionsLC = suggestionsLC;

  });
  return suggestions;
}
