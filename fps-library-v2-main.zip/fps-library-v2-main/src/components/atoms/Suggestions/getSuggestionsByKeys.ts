
/**
 *  Originally copied from Compliance web part 2023-03-28
 */

import { check4This } from "@mikezimm/fps-pnp2/lib/services/sp/CheckSearch";
import { getStringArrayBasic } from "../../../logic/Strings/getStringArrayBasic";
import { ISuggestion } from "./ISuggestion";

export function getSuggestionsFromStrings( strings: string[], suggestions: ISuggestion[], max: number = 1000 ): ISuggestion[] {
  const results: ISuggestion[] = getSuggestionsByKeys( { key: strings.join(';') }, ['key'], suggestions );
  return results;
}

export function getSuggestionsByKeys(item: any, keys: string[], suggestions: ISuggestion[], max: number = 1000 ): ISuggestion[] {

  if (!keys || keys.length === 0)
    return [];
  else if (!suggestions || suggestions.length === 0)
    return [];
  else if (max === 0)
    return [];

  const results: ISuggestion[] = [];

  keys.map(key => {
    //Exclude empty keys, if results is more than max, if the item[key] is not a string or is empty
    if ( key && results.length < max && item[key] && typeof item[key] === 'string') {

    /**
     * get array of strings only (aka words) from the item proprty
     * Original code:
     * const keyVals: string[] = item[key].replace(/[0-9]/g, " ").split(/\b([a-z]+)\b/gi);
     *
     * https://github.com/mikezimm/Compliance/issues/138 
     *
     * Test code:  resulting in ["test","i","ng","as","dfasd","asdf"]
      const item = 'test1234~321i~ng as?!_$dfasd. -++[asdf];?~!&^$%...,;'
      const keyVals = item.replace(/[0-9.,;:?~!&^$%+_[\]-]/g, " ").replace(/\s\s+/g, ' ').split(/\b([a-z]+)\b/gi).filter( v => v.trim() !== '' );
      console.log( keyVals )
      */

      // const keyVals: string[] = item[key].replace(/[0-9.,;:?~!&^$%+_[\]-]/g, " ")  // Should now remove any of these characters 0-9.,;?~!&^$%+_-
      //                               .replace(/\s\s+/g, ' ')     // then replace multiple spaces with single space.
      //                               .split(/\b([a-z]+)\b/gi)    // Then split into words,
      //                               .filter( ( v: string ) => v.trim() !== '' ); // then remove spaces and empties

      // Opted to use getStringArrayBasic instead of getArrayOfWordsFromString since it only needs to compare to suggestions.
      const originalWords: string[] = getStringArrayBasic( item[key], true );

      originalWords.map(keyval => {
        let found: boolean = false;
        const keyvalLC = keyval.toLowerCase();
        suggestions.map((suggestion: ISuggestion) => {
          if (results.length < max && found === false ) {

            // for https://github.com/mikezimm/Compliance/issues/132
            const isExcluded = !suggestion.exclusionsLC || suggestion.exclusionsLC.length === 0 ? false : 
              suggestion.exclusionsLC.indexOf( keyvalLC ) > -1 ? true : false;

            if ( isExcluded === false ) {
              suggestion.findsLC.map((find: string) => {
                if ( keyvalLC === find) {
                  results.push(suggestion);
                  found = true;
                }
              });
            }
          }

        });
      });
    }
  });

  if ( check4This( 'suggestions=true' ) === true ) console.log( `getSuggestionsByKeys: item, keys, suggestions, results`, item, keys, suggestions, results );

  return results;

}
