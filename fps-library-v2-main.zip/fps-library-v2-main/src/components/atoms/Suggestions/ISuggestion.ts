
/**
 *  Originally copied from Compliance web part 2023-03-28
 */

export interface ISuggestion {
  title: string; // Suggestion Title / Label
  description: string; // Description of Suggestion
  finds: string[]; // Include if you find any of these
  findsLC?: string[]; // Include if you find any of these
  exclusions?: string[]; // Exclude if you also find any of these
  exclusionsLC?: string[]; // Exclude if you also find any of these
  suggestions: string[]; // Suggestions
  suggestionsLC?: string[]; // Suggestions
}
