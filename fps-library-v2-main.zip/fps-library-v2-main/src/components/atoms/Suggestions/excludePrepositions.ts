import { IFPSDateLanguageObject } from '../../../logic/Time/IFPSDateLanguageObject';

export const PrepositionWords : IFPSDateLanguageObject = {
  'en-us': [ 'has', 'been', 'for', 'the', 'you', 'about', 'with', 'not', 'and', 'was', 'before', 'from', 'this' ],
  'es': [ '', '', '', '', '', '', '', '', '', '', '', '' ], //Should start on Monday
  'de-de': [ '', '', 'för', '', '', '', '', '', '', '', '', '' ], //Should start on Monday
  'fr-fr': [ '', '', '', '', '', '', '', '', '', '', '', '' ], //Should start on Monday
  'ja': [ '', '', '', '', '', '', '', '', '', '', '', '' ],
  'ch': [ '', '', '', '', '', '', '', '', '', '', '', '' ],
  'ko': [ '', '', '', '', '', '', '', '', '', '', '', '' ],
  'thai': [ '', '', '', '', '', '', '', '', '', '', '', '' ],
  'swe': [ '', '', '', '', '', '', '', '', '', '', '', '' ], //Should start on Monday
  'ro-ro': [ '', '', '', '', '', '', '', '', '', '', '', '' ], //Should start on Monday
};

export function globalPrepositionList( ) : string[] {

  const allPreps: string[] = [];
  const keys = Object.keys( PrepositionWords );
  keys.map( key => {
    const anyPrepositionWords : any = PrepositionWords;
    anyPrepositionWords[key].map( ( prep: string ) => {
      if ( prep && allPreps.indexOf( prep ) < 0 ) allPreps.push( prep );
    });
  });

  return allPreps;
}

export function cleanGlobalPrepositionObj( ) : string[] {

  const CleanPrepositionWords: any = PrepositionWords;
  const keys = Object.keys( PrepositionWords );
  keys.map( key => {
    const anyPrepositionWords : any = PrepositionWords;
    const allPreps: string[] = [];
    anyPrepositionWords[key].map( ( prep: string ) => {
      if ( prep && allPreps.indexOf( prep ) < 0 ) allPreps.push( prep );
    });
    CleanPrepositionWords[ key] = allPreps;
  });

  return CleanPrepositionWords;
}