import { IEasyIcons } from '../interfaces/eiTypes';
import { IMinStandardIconObject } from '../interfaces/IMinStandardIconObject';
import { commonDefaultIcons, getEasyIcon } from './getEasyIcon';

/**
 * DEPRECATED - NOW THIS IS Included directly in addEasyIcons
 * replaceDefaultIcons will test to see if the current imageUrl value is a default image.
 * If it is found to be a default image already, it will then look for a replacement
 *
 * https://github.com/mikezimm/fps-library-v2/issues/59
 * https://github.com/mikezimm/pivottiles7/issues/261
 *
 * @param EasyIconsObject
 * @param item
 * @param current
 * @returns
 */

export function replaceDefaultIcons(EasyIconsObject: IEasyIcons, item: IMinStandardIconObject, current: string): string {
  let result: string = `${current}`;
  let isCommon: any = false;
  commonDefaultIcons.map((partial: string) => {
    if (current.indexOf(partial) > -1) isCommon = true;
  });

  if (isCommon === true) {
    const originalImageUrl = `${current}`; // If an easyIcon is not found, use the default one
    result = getEasyIcon(EasyIconsObject, item, originalImageUrl);
  }
  return result;
}
