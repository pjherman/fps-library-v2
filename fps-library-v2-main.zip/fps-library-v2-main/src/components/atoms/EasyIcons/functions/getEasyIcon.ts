
import { EasyPagesCCSPages, EasyPagesSysPages, EasyPagesSysTab, ISourcePropsEP } from '../../../../banner/components/EasyPages/interfaces/epTypes';
import { DefaultThumbCCS, DefaultThumbEasyContents, DefaultThumbExtreme, DefaultThumbEarth, DefaultSiteLogo } from '../SystemIcons/DefaultEasyIcons';
import { FileTypeZipName, FileTypesZip, IEasyIcons } from '../interfaces/eiTypes';
import { EasyIconLocation } from "../interfaces/EasyIconLocation";
import { IMinStandardIconObject } from '../interfaces/IMinStandardIconObject';
import { getEasySystemIcon } from '../SystemIcons/getEasySystemIcon';
import { EasySystemLibraryIcons } from '../SystemIcons/EasySystemLibraryIcons';
import { AllEasySystemIcons } from '../SystemIcons/AllSystemEasyIcons';
import { EasyCCSPageIcons } from '../SystemIcons/EasyCCSPageIcons';
import { EasySystemListIcons } from '../SystemIcons/EasySystemListIcons';

export const commonDefaultIcons: string[] = [ '_layouts/15/images/sitepagethumbnail.png' ];

/**
 * Logic order:
 * First checks keywords in the first Prop to test ( Title )
 * Then checks for all the Icons in Title
 * Then repeats for the next Prop - Description
 * @param EasyIcons
 * @param item
 * @param fallbackIcon?  Fallback Icon if one is not found
 * @returns
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any

export function getEasyIcon(EasyIcons: IEasyIcons, item: IMinStandardIconObject, fallbackIcon?: string ): string | null {

  //If this is disabled, then exit
  if (EasyIcons.Enabled !== true)
    return fallbackIcon;

  // https://github.com/mikezimm/pivottiles7/issues/281
  const EasyIgnoresLC: string[] = EasyIcons.Ignore ? EasyIcons.Ignore.map( ignor => { return ignor.toLowerCase() } ) : [];
  const EasyErrors: string[] = [];
  let EasyIconUrl = '';

  EasyIcons.Priority.map(prop => {
    if (item[prop as 'title' ]) {
      EasyIcons.GroupKeys.map(Key => {
        if ( Key === 'SharePoint' || Key === 'FileTypes' ) {
          // Skip this key because it should be gotten previously via getEasySystemIcon and FileTypes is done below
        } else if (EasyIcons.Valid.indexOf(Key) < 0) {
          if (EasyErrors.indexOf(Key) < 0) { EasyErrors.push(Key); }
        } else if (!EasyIconUrl && EasyIcons.Groups[Key].Status === 'Active') {
          EasyIcons.Groups[Key]?.Icons.map((Icon: string) => {
            if (!EasyIconUrl && Icon) { //Only continue if EasyIconUrl is not found and Icon is a non-empty string
              if ( EasyIgnoresLC.indexOf( Icon.toLowerCase() ) < 0 ) {  // https://github.com/mikezimm/pivottiles7/issues/281
                //Combine all the options into regex as optional qualifiers
                const KeyOptions = EasyIcons.Groups[Key]; // Added this to remove type error in line below where its' possibly undefined
                const Options: string = KeyOptions.Options ? `(${KeyOptions?.Options.join(')?(')})?` : '';
                // eslint-disable-next-line @rushstack/security/no-unsafe-regexp
                const IconRegex = new RegExp(`(\\b)${Icon}${Options}(\\b)`, 'i');
                if (item[prop as 'title' ].match(IconRegex)) {
                  EasyIconUrl = `${EasyIconLocation}${Key}/${Icon}.png`;
                }
              }
            }
          });
        }
      });
    }
  });

  // https://github.com/mikezimm/pivottiles7/issues/314
  const ItemFileName = !item.File ? '' : item.File.Name ? item.File.Name : item.File.ServerRelativeUrl ? item.File.ServerRelativeUrl.substring(item.File.ServerRelativeUrl.lastIndexOf('/') + 1) : ``;

  // https://github.com/mikezimm/fps-library-v2/issues/70
  if ( EasyIcons.GroupKeys.indexOf( 'FileTypes' ) > -1 && !EasyIconUrl && item.File ) {
    // https://github.com/mikezimm/pivottiles7/issues/275
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let isAnArchive: any = false;
    FileTypesZip.map( zip => {

      if ( isAnArchive === false && ItemFileName.toLowerCase().indexOf( zip ) > 0 ) isAnArchive = true;
    });

    if ( isAnArchive === true ) {
      EasyIconUrl = `${EasyIconLocation}${`FileTypes`}/${FileTypeZipName}.png`;
    } else {
      // Eventually add other file types... NOTE this is more complex than other types of icons.
    }
  }

  return EasyIconUrl ? EasyIconUrl : fallbackIcon;

}

export function getStandardEasyIcon( item: IMinStandardIconObject, ){

}

export function addEasyIcons( items: any[], sourceProps: ISourcePropsEP, EasyIcons: IEasyIcons, ) {

  items.map( item => {
    let { searchTextLC, } = item.FPSItem.Search;
    item.tabs = [];
    item.title = item.Title;
    item.description = item.Description;
    item.url = item.File?.ServerRelativeUrl;
    item.imageUrl =  item.BannerImageUrl?.Url;
    item.imageDesc = item.BannerImageUrl?.Description;

    // https://github.com/mikezimm/fps-library-v2/issues/59:  Gracefully support if imageUrl is OOTB

    let fallbackIcon: string = ``;
    commonDefaultIcons.map( ( thumb: string ) => {
      if ( item.imageUrl && item.imageUrl.indexOf( thumb ) > -1 ) {
        // The current thumbnail is a default one.  
        // Place in temp storage and then put it back later it does not find a better one.
        fallbackIcon = `${item.imageUrl}`;
        item.imageUrl = ``;
      }
    });

    // https://github.com/mikezimm/drilldown7/issues/280
    EasyPagesCCSPages.map( ccs => {
      if ( item.url?.toLocaleLowerCase().indexOf( `/${ccs.toLocaleLowerCase()}.aspx`  ) > -1 ) { item.imageUrl = DefaultThumbCCS; }
    });

    if ( !item.imageUrl || item.imageUrl.indexOf( DefaultSiteLogo ) > - 1 ) {
      if ( item.title?.indexOf( 'Contents' ) > -1 ) { item.imageUrl = DefaultThumbEasyContents; }
      else if ( item.title?.toLocaleLowerCase().indexOf( 'extreme' ) > -1 ) { item.imageUrl = DefaultThumbExtreme; }
      else if ( item.title === 'Home' ) { item.imageUrl = DefaultThumbEarth; }
      else {

        // Added here for https://github.com/mikezimm/pivottiles7/issues/262; https://github.com/mikezimm/fps-library-v2/issues/60

        // 2023-07-06:  First do Page level icons, do Lists and Libraries after looking for other icons
        const EasySystemIcon1 = getEasySystemIcon( EasyCCSPageIcons, item, );
        if ( EasySystemIcon1 ) {
          item.imageUrl = EasySystemIcon1;
          item.imageDesc = `Using EasySystemIcon:) ${ EasySystemIcon1.replace( EasyIconLocation, '' )}`;
        } else {
          const EasyIconUrl = getEasyIcon( EasyIcons, item, fallbackIcon );
          if ( EasyIconUrl ) item.imageUrl = EasyIconUrl ? EasyIconUrl : item.imageUrl; // If one is found, then use it, else use the defaul sitepagelogo
          if ( EasyIconUrl ) item.imageDesc = EasyIconUrl ? `Using EasyIcon:) ${ EasyIconUrl.replace( EasyIconLocation, '' )}` : item.imageDesc; // If one is found, then use it, else use the defaul sitepagelogo
        }
      }

    }

    // 2023-07-06:  First do Page level icons, do Lists and Libraries after looking for other icons
    if ( !item.imageUrl ) { // Look on List/Library name level
      const EasySystemIcon2 = getEasySystemIcon( [ ...EasySystemLibraryIcons, ...EasySystemListIcons ], item, );
      if ( EasySystemIcon2 ) {
        item.imageUrl = EasySystemIcon2;
        item.imageDesc = `Using EasySystemIcon:) ${ EasySystemIcon2.replace( EasyIconLocation, '' )}`;
      }
    }

    // 2023-02-16:  Added ternary here for cases where searchTextLC is already set
    searchTextLC = searchTextLC ? searchTextLC : `${item.Title} || ${item.Description}`.toLocaleLowerCase();

    // https://github.com/mikezimm/drilldown7/issues/280
    EasyPagesSysPages.map( sysPage => {
      if ( item.url?.toLocaleLowerCase().indexOf( `/${sysPage.toLocaleLowerCase()}.aspx`  ) > -1 ) { item.tabs.push( EasyPagesSysTab ); }
    });

    //Only add to user tabs if it's NOT a known System page
    if ( sourceProps.meta1 && item.tabs.indexOf( EasyPagesSysTab ) < 0 ) {
      sourceProps.meta1.map( ( tab : string ) => {
        if ( item.FPSItem.Search.searchTextLC.indexOf( tab.toLocaleLowerCase() ) > -1 ) item.tabs.push( tab );
      } );
    }

  });

  items.map( item => {
    if ( item.tabs.length === 0 ) {
      //2023-016:  Added check for if there isn't an EasyPages overflow tab on the sourceProps
      if ( sourceProps.EasyPageOverflowTab  ) {
        item.tabs.push( sourceProps.EasyPageOverflowTab ) ;
      } else if ( sourceProps.OverflowTab ) {
        item.tabs.push( sourceProps.OverflowTab ) ;
      }
    }
  });

  return items;

}
