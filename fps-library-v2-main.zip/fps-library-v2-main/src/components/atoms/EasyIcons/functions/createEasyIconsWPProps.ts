import { EasyIconObjectDefault, IEasyIcons, IEasyIconsWPProps } from '../interfaces/eiTypes';
import { getStringArrayFromStringNoDups } from '../../../../logic/Strings/arraysFromString';

export function createEasyIconsWPProps(easyIconWPProps: IEasyIconsWPProps): IEasyIcons {

  const EasyIcons: IEasyIcons = EasyIconObjectDefault;

  const GroupKeys: any[] | null = getStringArrayFromStringNoDups(easyIconWPProps.easyIconKeys, ';', true, null, true);
  const Ignore: any[] | null = getStringArrayFromStringNoDups(easyIconWPProps.easyIconIgnore, ';', true, null, true);

  if (easyIconWPProps)
    EasyIcons.Enabled = easyIconWPProps.easyIconEnable === false ? false : true;
  if (easyIconWPProps)
    EasyIcons.GroupKeys = GroupKeys ? GroupKeys : [];
  if (easyIconWPProps)
    EasyIcons.Ignore = Ignore ? Ignore : [];

  return EasyIcons;
}
