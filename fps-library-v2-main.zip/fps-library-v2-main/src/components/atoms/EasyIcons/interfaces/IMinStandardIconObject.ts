import { IFpsFileProperty } from "../../../../logic/Links/IFpsFileProperty";

export interface IMinStandardIconObject {
  title?: string;
  Title?: string;
  description?: string;
  Description?: string;
  url?: string;
  Url?: string;
  href?: string;
  imageUrl: string;
  File?: IFpsFileProperty;
}
