//Default Library Url for all EasyIcons

export const EasyIconLibrary = `/Branding/EasyIcons`;
export const EasyIconLocation = `${window.location.origin}/sites${EasyIconLibrary}/`;
