import { ISystemEasyIcon } from "./ISystemEasyIcon";

import { EasyCCSPageIcons } from "./EasyCCSPageIcons";
import { EasySystemListIcons } from "./EasySystemListIcons";
import { EasySystemLibraryIcons } from "./EasySystemLibraryIcons";

/**
 * NOTE:  using AllEasySystemIcons in addEasyIcons will take first priority... so be cautions.
 * If you notice all Items are like 'Site Pages', it's because of this
 */
export const AllEasySystemIcons: ISystemEasyIcon[] = [ 
  ...EasySystemLibraryIcons, 
  ...EasySystemListIcons, 
  ...EasyCCSPageIcons, 
];
