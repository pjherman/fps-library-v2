
import { EasyPagesCCSPages } from "../../../../banner/components/EasyPages/interfaces/epTypes";
import { DefaultThumbCCS } from "./DefaultEasyIcons";
import { ISystemEasyIcon } from "./ISystemEasyIcon";

export const EasyCCSPageIcons: ISystemEasyIcon[] = [{
  titles: [],
  urls: EasyPagesCCSPages.map(ccs => { return `/${ccs.toLocaleLowerCase()}.aspx`; }),
  imageUrl: DefaultThumbCCS,
}];
