
import { EasyIconLocation } from "../interfaces/EasyIconLocation";

export interface ISystemEasyIcon {
  titles: string[]; // Look for exact match
  urls: string[];
  imageUrl: string;
}

export const BrandingSharePointFolder: string = `${EasyIconLocation}SharePoint/`;