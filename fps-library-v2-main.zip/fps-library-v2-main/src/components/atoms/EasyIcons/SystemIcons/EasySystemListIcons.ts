import { BrandingSharePointFolder, ISystemEasyIcon } from "./ISystemEasyIcon";

export const ListTitlesWithNoSpaceUrls: string[] = ['OurTiles', `Reusable Content` ];

export const EasySystemListIcons: ISystemEasyIcon[] = [
  ...ListTitlesWithNoSpaceUrls.map((title: string) => {
    return { titles: [title.toLowerCase()], urls: [`/${title.toLowerCase().replace(' ', '')}`], imageUrl: `${BrandingSharePointFolder}${title}.png` };
  }),
  {
    titles: [`MicroFeed`.toLowerCase()],
    urls: [`/lists/publishedfeed`],
    imageUrl: `${BrandingSharePointFolder}MicroFeed.png`,
  },
  //  {
  //   titles: [ `Style Library` ],
  //   urls: [ `/style%20library/` ],
  //   // urls: [ `/Style%20Library/` ],
  //   imageUrl: ``,
  // },
];
