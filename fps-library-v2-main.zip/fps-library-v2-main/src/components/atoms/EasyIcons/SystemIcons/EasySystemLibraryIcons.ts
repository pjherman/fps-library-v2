import { ISystemEasyIcon } from "./ISystemEasyIcon";
import { BrandingSharePointFolder } from "./ISystemEasyIcon";

export const LibraryTitlesWithNoSpaceUrls: string[] = [
  'Site Assets', 'Site Pages', `Pages`,
  `Documents`,
  `Site Collection Documents`, `Site Collection Images`,
  'Workflow Tasks',
];

export const EasySystemLibraryIcons: ISystemEasyIcon[] = [
  ...LibraryTitlesWithNoSpaceUrls.map((title: string) => {
    return { titles: [title.toLowerCase()], urls: [`/${title.toLowerCase().replace(' ', '')}`], imageUrl: `${BrandingSharePointFolder}${title}.png` };
  }),
  {
    titles: [`Content and Structure Reports`.toLowerCase()],
    urls: [`/reports%20list`],
    imageUrl: `${BrandingSharePointFolder}Content and Structure Reports.png`,
  }, {
    titles: [`Images`.toLowerCase()],
    urls: [`/PublishingImages`.toLowerCase()],
    imageUrl: `${BrandingSharePointFolder}Images.png`,
  }, {
    titles: [`Style Library`.toLowerCase()],
    urls: [`/style%20library`, `/style library`],
    imageUrl: `${BrandingSharePointFolder}Style Library.png`,
  },
];
