import { IMinStandardIconObject } from "../interfaces/IMinStandardIconObject";
import { ISystemEasyIcon } from "./ISystemEasyIcon";

/**
 * getEasySystemIcon:  Pass in an array of ISystemEasyIcon and it will try to get the imageUrl based on
 *    the titles ( exact match )
 *    the urls ( partial match )
 * @param EasySysIcons constants:  AllEasySystemIcons, EasyCCSPageIcons, EasySystemListIcons, EasySystemLibraryIcons
 * @param item
 * @returns
 */

export function getEasySystemIcon( EasySysIcons: ISystemEasyIcon[], item: IMinStandardIconObject ): string {

  let foundIcon: string = '';
  EasySysIcons.map((SysIcon: ISystemEasyIcon) => {
    if (!foundIcon) {
      SysIcon.titles.map((title: string) => {
        if (!foundIcon) {
          if (item.title && item.title.toLowerCase() === title) { foundIcon = SysIcon.imageUrl; }
          else if (item.Title && item.Title.toLowerCase() === title) { foundIcon = SysIcon.imageUrl; }
          else if (item.description && item.description.toLowerCase() === title) { foundIcon = SysIcon.imageUrl; }
          else if (item.Description && item.Description.toLowerCase() === title) { foundIcon = SysIcon.imageUrl; }
        };
      });
    };

    if (!foundIcon) {
      SysIcon.urls.map((url: string) => {
        if (!foundIcon) {
          if (item.href && item.href.toLowerCase().indexOf(url) > -1) { foundIcon = SysIcon.imageUrl; }
          else if (item.url && item.url.toLowerCase().indexOf(url) > -1) { foundIcon = SysIcon.imageUrl; }
        };
      });
    }
  });

  return foundIcon;

}
