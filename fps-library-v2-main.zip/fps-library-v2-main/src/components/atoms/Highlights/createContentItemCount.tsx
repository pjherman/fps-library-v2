
import * as React from 'react';
import { IAnySourceItem } from '../../molecules/AnyContent/IAnyContent';

export type IItemCountType = 'H' | 'V';
export function createContentItemCount(item: IAnySourceItem, CountType: IItemCountType, thickPx: number = 25 ): JSX.Element {

  const BaseStyles: React.CSSProperties = {
    position: 'absolute', opacity: '.4', zIndex: '1',
    background: item.ItemCount > 4000 ? 'red' : item.ItemCount > 2000 ? 'yellow' : 'green',
  }
  const barSize =  `${item.ItemCount / 5000 * 100}%`;
  const TypeStyles: React.CSSProperties = CountType === 'V' ?
    { height: barSize, bottom: '0px', left: '0px', width: `${thickPx}px` } :
    { width: barSize, bottom: '0px', left: '0px', height: `${thickPx}px` }

  const ActualStyles: React.CSSProperties = { ...TypeStyles, ...BaseStyles }
  const itemCountBar = !item.ItemCount ? null : <div title={`${item.ItemCount} Items`} style={ ActualStyles }> </div>;

  return itemCountBar;
}
