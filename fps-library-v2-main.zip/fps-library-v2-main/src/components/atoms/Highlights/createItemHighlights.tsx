import * as React from 'react';
import { IAnySourceItem } from '../../molecules/AnyContent/IAnyContent';
// import { UniversalIconsPTAny } from './BuildContentElements';
import { UniversalIconsPT } from '../Icons/standardUniversalFPS';
import { IItemIsAKeys } from '../../molecules/AnyContent/IsA/IFPSItemIsA';
const UniversalIconsPTAny: any = UniversalIconsPT;

export function createItemHighlights(item: IAnySourceItem, style: React.CSSProperties , surpressIsAKeys: IItemIsAKeys[] ): JSX.Element {
  const highlights: JSX.Element[] = [];

  if (item.FPSItem && Object.keys(item.FPSItem.IsA).length > 1) {
    Object.keys(item.FPSItem.IsA).map(( key: IItemIsAKeys ) => {
      if ( key !== `allIsAKeys` as 'File' && surpressIsAKeys.indexOf( key ) < 0 ) {
        highlights.push(UniversalIconsPTAny[key]);
      }
    });
  }

  return highlights.length === 0 ? undefined : <div style={style}> {highlights} </div>;
}
