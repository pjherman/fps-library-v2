import * as React from 'react';
import { IAnySourceItem } from '../../molecules/AnyContent/IAnyContent';
require('@mikezimm/fps-styles/dist/pubDate.css');

export function createContentViewsRecent(item: IAnySourceItem): JSX.Element {
  // https://github.com/mikezimm/pivottiles7/issues/285
  const views = !item.ViewsLifeTime ? null : <div className={'pubDate'} title={`Recent Views: ${item.ViewsRecent} LifeTime: ${item.ViewsLifeTime}`} style={{
    position: 'absolute', top: '10px', left: '10px',
    color: '#b0b0b0',
  }}>{`Views: ${item.ViewsRecent}`}</div>;

  return views;
}
