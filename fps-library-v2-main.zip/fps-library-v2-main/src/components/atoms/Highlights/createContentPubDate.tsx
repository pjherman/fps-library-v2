import * as React from 'react';
import { IAnySourceItem } from '../../molecules/AnyContent/IAnyContent';

require ('@mikezimm/fps-styles/dist/pubDate.css');

export function createContentPubDate(item: IAnySourceItem): JSX.Element {
  const pubDate = !item.FirstPublishedDate ? null : <div className={'pubDate'} title={`Published on ${item.FirstPublishedDate}`} style={{
    position: 'absolute', top: !item.ViewsLifeTime ? '10px' : '24px', left: '10px', 
    color: '#b0b0b0',
  }}>{`${item.FirstPublishedDate?.substring(0, 10)}`}</div>;

  return pubDate;
}
