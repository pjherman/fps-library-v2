
import { buildAppWarnIcon, IFPSApps } from './stdIconsBuildersV02';

import * as StdIcons from './iconNames';

const thisApp: IFPSApps = "eXTremeStorage";

export const NoItems = buildAppWarnIcon(thisApp, StdIcons.NoItems, "No items", 'black' ); //

export const UniquePerms =  buildAppWarnIcon( thisApp, StdIcons.UniquePerms, "Unique Permissions", 'black' );
export const ShareThisItem =  buildAppWarnIcon( thisApp, StdIcons.Share, "Share this item", 'rgb(70, 97, 213)' );
export const SharedItem =  buildAppWarnIcon( thisApp, StdIcons.Share, "Item was shared", 'black' );

export const ImageSearchRed =  buildAppWarnIcon( thisApp, StdIcons.ImageSearch, "See Image Details", 'red' );
export const ImageSearchBlack =  buildAppWarnIcon( thisApp, StdIcons.ImageSearch, "See Image Details", 'black' );

export const DocumentSearch =  buildAppWarnIcon( thisApp, StdIcons.DocumentSearch, "See Item Details", 'black' );

export const GoToFolder =  buildAppWarnIcon( thisApp, StdIcons.FabricMovetoFolder, "Go to folder", 'black' );

export const CheckOutByOther =  buildAppWarnIcon( thisApp, StdIcons.CheckedOutByOther, "Checked out by someome else", 'black' );
export const CheckedOutByYou =  buildAppWarnIcon( thisApp, StdIcons.CheckedOutByYou, "Checked out by you", 'black' );
export const PageCheckedOut =  buildAppWarnIcon( thisApp, StdIcons.PageCheckedOut, "Page checked in", 'black' );
export const PageCheckedin =  buildAppWarnIcon( thisApp, StdIcons.PageCheckedin, "Page checked out", 'black' );