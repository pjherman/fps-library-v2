
import { buildAppWarnIcon, IFPSApps } from './stdIconsBuildersV02';

import * as StdIcons from './iconNames';

const thisApp: IFPSApps = "EasyContents";

/**
 * For EasyContext Rail Functions
 */
export const CreateGroups =  buildAppWarnIcon( thisApp, StdIcons.GroupsAdd, "Create Groups", 'black' );
export const ResetPermissions =  buildAppWarnIcon( thisApp, StdIcons.ShieldAlert, "Reset Permissions", 'red' );
export const RemoveItems =  buildAppWarnIcon( thisApp, StdIcons.Sweep, "Remove Items", 'red' );
export const Delete =  buildAppWarnIcon( thisApp, StdIcons.Delete, "Delete", 'red' );
export const Warning =  buildAppWarnIcon( thisApp, StdIcons.Warning, "Warning", 'darkred' );
export const WarningSolid =  buildAppWarnIcon( thisApp, StdIcons.WarningSolid, "WarningSolid", 'red' );

/**
 * For Lists and Libraries
 */

export const NoItems = buildAppWarnIcon(thisApp, StdIcons.NoItems, "No items", 'black' ); //

export const LotsItems = buildAppWarnIcon( thisApp, StdIcons.LotsItems, "Lots of items", 'black' );
export const ToManyItems = buildAppWarnIcon( thisApp, StdIcons.ToManyItems, "More than 5k items", 'red' );
export const RequiresCheckout = buildAppWarnIcon( thisApp, StdIcons.RequiresCheckout, "Requires checkout", 'red' );
export const NOEnableVersioning = buildAppWarnIcon( thisApp, StdIcons.NOEnableVersioning, "NO Versioning", 'red' );
export const Attachments =  buildAppWarnIcon( thisApp, StdIcons.Attachments, "Attachments disabled", 'red' );
export const UniquePerms =  buildAppWarnIcon( thisApp, StdIcons.UniquePerms, "Unique Permissions", 'black' );

export const NotApplicable =  buildAppWarnIcon( thisApp, StdIcons.NotApplicable, "Not Applicable", 'black' );
export const InheritedPerms =  buildAppWarnIcon( thisApp, StdIcons.NotApplicable, "Not Applicable", 'black' );


/**
 * For Subsites
 */
export const MinDownload = buildAppWarnIcon( thisApp, StdIcons.MinDownload, "Minimum Download enabled", 'red' );

/**
 * For News and Pages
 */
// import { NewsLink, CheckedOut, UnPublished, MinorVersion } from '../Pages/PageFunctions';

export const NewsLink = buildAppWarnIcon( thisApp, StdIcons.NewsLink, "News Link", 'black' );
export const CheckedOut = buildAppWarnIcon( thisApp, StdIcons.CheckedOut, "Checked Out", 'red' );
export const UnPublished = buildAppWarnIcon( thisApp, StdIcons.UnPublished, "UnPublished", 'black' );
export const MinorVersion = buildAppWarnIcon( thisApp, StdIcons.MinorVersion, "Draft Version", 'red' );

