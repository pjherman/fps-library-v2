
import { buildAppWarnIcon, IFPSApps } from './stdIconsBuildersV02';

import * as StdIcons from './iconNames';

const thisApp: IFPSApps = "PivotTiles";

/**
 * For Lists and Libraries
 */
export const NoItems = buildAppWarnIcon( thisApp, StdIcons.NoItems, "No items", 'black' ); //

export const LotsItems = buildAppWarnIcon( thisApp, StdIcons.LotsItems, "Lots of items", 'black' );
export const ToManyItems = buildAppWarnIcon( thisApp, StdIcons.ToManyItems, "More than 5k items", 'red' );
export const RequiresCheckout = buildAppWarnIcon( thisApp, StdIcons.RequiresCheckout, "Requires checkout", 'red' );
export const NOEnableVersioning = buildAppWarnIcon( thisApp, StdIcons.NOEnableVersioning, "NO Versioning", 'red' );
export const Attachments =  buildAppWarnIcon( thisApp, StdIcons.Attachments, "Attachments disabled", 'red' );
export const UniquePerms =  buildAppWarnIcon( thisApp, StdIcons.UniquePerms, "Unique Permissions", 'black' );

export const InheritedPerms =  buildAppWarnIcon( thisApp, StdIcons.NotApplicable, "Not Applicable", 'black' );

/**
 * For Subsites
 */
export const MinDownload = buildAppWarnIcon( thisApp, StdIcons.MinDownload, "Minimum Download enabled", 'red' );
export const NoRecentViews = buildAppWarnIcon( thisApp, StdIcons.NoRecentViews, "No Recent Views", 'red' );
export const PopularRecent = buildAppWarnIcon( thisApp, StdIcons.PopularRecent, "Popular Recently", 'darkgreen' );
export const PopularLifeTime = buildAppWarnIcon( thisApp, StdIcons.PopularLifeTime, "Popular over LifeTime", 'blue' );

export const MSTeam = buildAppWarnIcon( thisApp, StdIcons.MSTeam, "Microsoft Group/Team", 'blue' );
export const STSSite = buildAppWarnIcon( thisApp, StdIcons.STSSite, "SharePoint Site", '#036C70' );
export const STSWeb = buildAppWarnIcon( thisApp, StdIcons.STSWeb, "SharePoint Subsite", 'black' );


/**
 * For News and Pages
 */

export const NewsLink = buildAppWarnIcon( thisApp, StdIcons.NewsLink, "News Link", 'black' );
export const CheckedOut = buildAppWarnIcon( thisApp, StdIcons.CheckedOut, "Checked Out", 'red' );
export const UnPublished = buildAppWarnIcon( thisApp, StdIcons.UnPublished, "UnPublished", 'black' );
export const MinorVersion = buildAppWarnIcon( thisApp, StdIcons.MinorVersion, "Draft Version", 'red' );

