
import { buildAppWarnIcon, IFPSApps } from './stdIconsBuildersV02';

import * as StdIcons from './iconNames';

export interface IFPSHighlights {

  /**
   * WARNING
   * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
   */
  // 2023-03-19: added in addSearchMeta1 - Only added IF TRUE
  DocSet: JSX.Element;
  FileObject: JSX.Element;
  File: JSX.Element;
  FolderContent: JSX.Element;
  Page: JSX.Element;
  News: JSX.Element;
  NewsPost: JSX.Element;
  NewsLink: JSX.Element;

  // 2023-03-19: added in addOtherIsAMeta - Only added IF TRUE
  Draft: JSX.Element;
  Major: JSX.Element;
  Published: JSX.Element;
  UnPublished: JSX.Element;
  CheckedOut: JSX.Element; // Added to highlight code in libraries...

  //'CodeContent' | 'OfficeContent' | 'DataContent' | 'MediaContent' | 'SharePoint' ;
  CodeContent: JSX.Element; // Added to highlight code in libraries...
  OfficeContent: JSX.Element; // Added to highlight code in libraries...
  DataContent: JSX.Element; // Added to highlight code in libraries...
  MediaContent: JSX.Element; // Added to highlight code in libraries...
  SharePoint: JSX.Element; // Added to highlight code in libraries...

  OtherContent: JSX.Element; // Added to highlight code in libraries...
  DescIsHTML: JSX.Element; // Added to highlight code in libraries... // linked to sescIsHTML in IFPSItemSearch

  // Item/Web/List/Library related
  UniquePerms: JSX.Element; // Added to highlight code in libraries...

  // List/Library related
  RequiresCheckout: JSX.Element; // Added to highlight code in libraries...
  VersionsDisabled: JSX.Element; // Added to highlight code in libraries...
  MinorVersionsEnabled: JSX.Element; // Added to highlight code in libraries...
  AttachmentsDisabled: JSX.Element; // Added to highlight code in libraries...

  HasMinimalDownload: JSX.Element; // Added to highlight code in libraries...

  ToManyItems: JSX.Element;
  LotsOfItems: JSX.Element;
  NoItems: JSX.Element;

  // Search Related
  NoRecentViews: JSX.Element;
  PopularRecently: JSX.Element;
  PopularLifeTime: JSX.Element;

  MSTeam: JSX.Element;
  STSSite: JSX.Element;
  STSWeb: JSX.Element;


}

// What to do about inherited permissions:  InheritedPerms
// export const InheritedPerms =  buildAppWarnIcon( thisApp, StdIcons.NotApplicable, "Not Applicable", 'black' );

export function createUniversalIcons( thisApp: IFPSApps ) :IFPSHighlights {

  const Result:IFPSHighlights = {

    // 2023-03-19: added in addSearchMeta1 - Only added IF TRUE
    DocSet: buildAppWarnIcon( thisApp, StdIcons.DocSet, 'Doc Set' , 'black' ),
    FileObject: buildAppWarnIcon( thisApp, StdIcons.FileObject, 'File' , 'black' ),
    File: buildAppWarnIcon( thisApp, StdIcons.FileIcon, 'File' , 'black' ),
    FolderContent: buildAppWarnIcon( thisApp, StdIcons.FolderContent, 'Folder' , 'black' ),
    Page: buildAppWarnIcon( thisApp, StdIcons.Pages, 'Page' , 'black' ),
    News: buildAppWarnIcon( thisApp, StdIcons.News, 'News' , 'black' ),
    NewsPost: buildAppWarnIcon( thisApp, StdIcons.NewsPost, 'News Post' , 'black' ),
    NewsLink: buildAppWarnIcon( thisApp, StdIcons.NewsLink, "News Link" , 'black' ),

    // 2023-03-19: added in addOtherIsAMeta - Only added IF TRUE
    Draft: buildAppWarnIcon( thisApp, StdIcons.MinorVersion, "Draft Version" , 'red' ),
    Major: buildAppWarnIcon( thisApp, StdIcons.Major, 'Major Version' , 'black' ),
    Published: buildAppWarnIcon( thisApp, StdIcons.Published, 'Published' , 'black' ),
    UnPublished: buildAppWarnIcon( thisApp, StdIcons.UnPublished, "UnPublished" , 'black' ),
    CheckedOut: buildAppWarnIcon( thisApp, StdIcons.CheckedOut, "Checked Out" , 'red' ), // Added to highlight code in libraries...

    //'CodeContent' | 'OfficeContent' | 'DataContent' | 'MediaContent' | 'SharePoint' ;
    CodeContent: buildAppWarnIcon( thisApp, StdIcons.CodeIcon, 'Code' , 'black' ), // Added to highlight code in libraries... 
    OfficeContent: buildAppWarnIcon( thisApp, StdIcons.OfficeIcon, 'Office' , 'black' ), // Added to highlight code in libraries...
    DataContent: buildAppWarnIcon( thisApp, StdIcons.OfflineStorage, 'Data' , 'black' ), // Added to highlight code in libraries...
    MediaContent: buildAppWarnIcon( thisApp, StdIcons.PhotoVideoMedia, 'Media' , 'black' ), // Added to highlight code in libraries...
    SharePoint: buildAppWarnIcon( thisApp, StdIcons.SharepointLogo, 'SharePoint' , 'black' ), // Added to highlight code in libraries...

    OtherContent: buildAppWarnIcon( thisApp, StdIcons.Album, 'Other Content' , 'black' ), // Added to highlight code in libraries...
    DescIsHTML: buildAppWarnIcon( thisApp, StdIcons.HTMLIcon, 'HTML' , 'black' ), // Added to highlight code in libraries... // linked to sescIsHTML in IFPSItemSearch

    // Item/Web/List/Library related
    UniquePerms: buildAppWarnIcon( thisApp, StdIcons.UniquePerms, "Unique Permissions" , 'black' ), // Added to highlight code in libraries...

    // List/Library related
    RequiresCheckout: buildAppWarnIcon( thisApp, StdIcons.RequiresCheckout, "Requires checkout" , 'red' ), // Added to highlight code in libraries...
    VersionsDisabled: buildAppWarnIcon( thisApp, StdIcons.NOEnableVersioning, "NO Versioning" , 'red' ), // Added to highlight code in libraries...
    MinorVersionsEnabled: buildAppWarnIcon( thisApp, StdIcons.MinorVersionsEnabled, 'Has Minor Versions' , 'black' ), // Added to highlight code in libraries...
    AttachmentsDisabled: buildAppWarnIcon( thisApp, StdIcons.Attachments, "Attachments disabled" , 'red' ), // Added to highlight code in libraries...

    HasMinimalDownload: buildAppWarnIcon( thisApp, StdIcons.MinDownload, "Minimum Download enabled" , 'red' ), // Added to highlight code in libraries...

    ToManyItems: buildAppWarnIcon( thisApp, StdIcons.ToManyItems, "More than 5k items" , 'red' ),
    LotsOfItems: buildAppWarnIcon( thisApp, StdIcons.LotsItems, "Lots of items" , 'black' ),
    NoItems: buildAppWarnIcon( thisApp, StdIcons.NoItems, "No items", 'black' ),

    // Search Related
    NoRecentViews: buildAppWarnIcon( thisApp, StdIcons.NoRecentViews, "No Recent Views" , 'red' ),
    PopularRecently: buildAppWarnIcon( thisApp, StdIcons.PopularRecent, "Popular Recently" , 'darkgreen' ),
    PopularLifeTime: buildAppWarnIcon( thisApp, StdIcons.PopularLifeTime, "Popular over LifeTime" , 'blue' ),

    MSTeam: buildAppWarnIcon( thisApp, StdIcons.MSTeam, "Microsoft Team/Group" , 'blue' ),

    STSSite: buildAppWarnIcon( thisApp, StdIcons.STSSite, "SharePoint Site", '#036C70' ),
    STSWeb: buildAppWarnIcon( thisApp, StdIcons.STSWeb, "SharePoint Subsite", 'black' ),

  }

  return Result;
}

export const UniversalIconsPT:IFPSHighlights = createUniversalIcons( 'PivotTiles' );