/**
 * List of constant icon names used in FPS webparts for various info/warnings
 * 
 
 import * as StdIcons from './iconNames';

 */
export const NoItems = 'CircleRing';
export const LotsItems = 'CircleHalfFull';
export const ToManyItems = 'CircleFill';
export const RequiresCheckout = 'CheckedOutByOther12'; // Replaced with ArrowTallDownRight
export const Attachments = 'Attach';
export const UniquePerms = 'Shield';
export const MinDownload = 'Download';
export const NewsLink = 'Link';
export const CheckedOut = 'PageCheckedOut';
export const UnPublished = 'UnpublishContent';
export const MinorVersion = 'UnpublishContent';
export const NOEnableVersioning = 'History';

export const NoRecentViews = 'VisuallyImpaired';
export const PopularRecent = 'RibbonSolid';
export const PopularLifeTime = 'Ribbon';
export const MSTeam = 'TeamsLogo';
export const STSSite = 'SharepointLogo';
export const STSWeb = 'Org';

export const Groups = 'Group';
export const Pages = 'Page';
export const News = 'News';
export const Edit = 'Edit';

export const GroupsAdd = 'AddGroup';
export const ShieldAlert = 'ShieldAlert';
export const Sweep = 'Broom';
export const Delete = 'Delete';
export const Warning = 'Warning12';
export const WarningSolid = 'WarningSolid';
export const Remove = 'Remove';

export const EnableModeration = 'Signin';  // Added for EasyContents
export const DraftVersionVisibility = 'VisuallyImpaired';  // Added for EasyContents

export const NotApplicable = 'Remove';

export const ChevronUp = 'ChevronUp';
export const ChevronDown = 'ChevronDown';

export const Blocked = 'Blocked';
export const Error = 'Error';
export const History = 'History';
export const Permissions = 'Permissions';

export const AnalyticsLogo = 'AnalyticsLogo';
export const AnalyticsQuery = 'AnalyticsQuery';

//For eXTremeStorage
export const Share = 'Share';
export const ImageSearch = 'ImageSearch';
export const DocumentSearch = 'DocumentSearch';
export const FabricMovetoFolder = 'FabricMovetoFolder';

export const CheckedOutByOther = 'CheckedOutByOther12';
export const CheckedOutByYou = 'CheckedOutByYou12';

export const PageCheckedin = 'PageCheckedin';
export const PageCheckedOut = 'PageCheckedOut';


export const MinorVersionsEnabled = 'MoreVertical';
export const DocSet = 'DocumentSet';
export const FileObject = 'FormLibrary';
export const FileIcon = 'Page';
export const FolderContent = 'FabricOpenFolderHorizontal';
export const NewsPost = 'WebPublish';
export const Major = 'FavoriteStar';
export const Published = 'WebPublish';

export const CodeIcon = 'Code';
export const OfficeIcon = 'ExcelDocument';
export const SharepointLogo = 'SharepointLogo';
export const OfflineStorage = 'OfflineStorage';
export const PhotoVideoMedia = 'PhotoVideoMedia';
export const Album = 'Album';
export const HTMLIcon = 'CodeEdit';


