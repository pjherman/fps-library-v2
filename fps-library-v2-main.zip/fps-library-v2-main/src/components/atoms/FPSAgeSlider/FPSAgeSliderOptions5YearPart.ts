import { IFPSAgeSliderItem, FPSAgeSliderOptionsPast2Year } from "./FPSAgeTypes";

// This is the array the hook uses for text IF the column is Modified or Created to better match SharePoint OOTB

export const FPSAgeSliderOptions5YearPart: IFPSAgeSliderItem[] = [
  ...FPSAgeSliderOptionsPast2Year,
  { key: 6, maxAge: 365 * 3, text: 'The past 3 years', },
  { key: 7, maxAge: 365 * 4, text: 'The past 4 years', },
  { key: 8, maxAge: 365 * 5, text: 'The past 5 years', },
];

export const FPSAgeSliderOptions5Years: IFPSAgeSliderItem[] = [
  ...FPSAgeSliderOptions5YearPart,
  { key: 9, maxAge: 365 * 100, text: 'All ages', },
];
