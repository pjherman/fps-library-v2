import { FPSAgeSliderOptions5YearPart } from "./FPSAgeSliderOptions5YearPart";
import { IFPSAgeSliderItem } from "./FPSAgeTypes";


export const FPSAgeSliderOptions7YearPart: IFPSAgeSliderItem[] = [
  ...FPSAgeSliderOptions5YearPart,
  { key: 9, maxAge: 365 * 6, text: 'The past 6 years', },
  { key: 10, maxAge: 365 * 7, text: 'The past 7 years', },
];

export const FPSAgeSliderOptions7Years: IFPSAgeSliderItem[] = [
  ...FPSAgeSliderOptions7YearPart,
  { key: 11, maxAge: 365 * 100, text: 'All ages', },
];
