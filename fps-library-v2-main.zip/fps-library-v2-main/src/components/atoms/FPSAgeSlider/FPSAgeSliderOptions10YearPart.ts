import { FPSAgeSliderOptions7YearPart } from "./FPSAgeSliderOptions7YearPart";
import { IFPSAgeSliderItem } from "./FPSAgeTypes";


export const FPSAgeSliderOptions10YearPart: IFPSAgeSliderItem[] = [
  ...FPSAgeSliderOptions7YearPart,
  { key: 11, maxAge: 365 * 8, text: 'The past 8 years', },
  { key: 12, maxAge: 365 * 9, text: 'The past 9 years', },
  { key: 13, maxAge: 365 * 10, text: 'The past 10 years', },
];

export const FPSAgeSliderOptions10Years: IFPSAgeSliderItem[] = [
  ...FPSAgeSliderOptions10YearPart,
  { key: 14, maxAge: 365 * 100, text: 'All ages', },
];
