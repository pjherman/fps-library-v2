// import { IAnySourceItem, sortObjectArrayByNumberKey } from '../../../fpsReferences';
// import { getArrayOfWordsFromString } from './getWordsFromString';
// import { startPerformOpV2, updatePerformanceEndV2 } from '@mikezimm/fps-library-v2/lib/components/molecules/Performance/functions';
import { sortObjectArrayByNumberKey } from "../../../logic/indexes/ArraySortingNumbers";
import { sortObjectArrayByChildNumberKey } from "../../../logic/indexes/ArraySortingObjects";
import { getArrayOfWordsFromString } from "../../../logic/Strings/getWordsFromString";
import { startPerformOpV2, updatePerformanceEndV2 } from "../../molecules/Performance/functions";
import { IAnySourceItem, IAnySourceItemAny } from "../../molecules/AnyContent/IAnyContent";
import { IWordSummary, IWordObject } from "./IWordSummary";


export function buildWordSummary(items: IAnySourceItem[], findWordsProp: string[], splitWords: boolean, sortKey: string, minLength: number, exclusionsLC: string[], sumProp: string = ''): IWordSummary {

  const processOp = startPerformOpV2({ label: 'buildWordCount', includeMsStr: true });
  let skippedWords: number = 0;

  const wordSummary: IWordSummary = {
    words: [], wordObjs: [], searchTextLC: [], skipped: [], performance: processOp
  };

  items.map((item: IAnySourceItemAny, itemIdx) => {
    const itemSourceString: string[] = findWordsProp.map(prop => { return item[prop] ? item[prop] : ''; });
    const testString = itemSourceString.filter(item => { return item && item.length > 0; }).join(` `);

    // https://github.com/mikezimm/Compliance/issues/177
    // if (testString.indexOf('(') > -1) {
    //   console.log(`buildWordSummary`, testString);
    // }

    const itemWords: string[] = splitWords === true ? getArrayOfWordsFromString(testString, true, true, true, 'asis') : [testString];
    itemWords.map(word => {

      const searchTextLC = word.toLocaleLowerCase();

      // for https://github.com/mikezimm/Compliance/issues/132
      const isExcluded = !exclusionsLC || exclusionsLC.length === 0 ? false : 
        exclusionsLC.indexOf( searchTextLC ) > -1 ? true : false;

      if ( isExcluded === false && word.length >= minLength) {

        let wordIdx = wordSummary.searchTextLC.indexOf(searchTextLC);

        // Add new words to summary
        if (wordIdx === -1) {
          wordSummary.words.push(word);
          wordSummary.searchTextLC.push(searchTextLC);
          const wordObj: IWordObject = {
            word: word,
            searchTextLC: searchTextLC,
            count: 0,
            sum: 0,
            avg: 0,
            sourceIndexes: [],
            sourceStrings: [],
            originalIndex: wordSummary.words.length,
          };
          wordSummary.wordObjs.push(wordObj);
          wordIdx = wordSummary.words.length - 1;
        }

        // Now update count, sum and avg
        wordSummary.wordObjs[wordIdx].count++;
        wordSummary.wordObjs[wordIdx].sourceIndexes.push(itemIdx);
        wordSummary.wordObjs[wordIdx].sourceStrings.push(itemSourceString.join('; '));

        wordSummary.wordObjs[wordIdx].sum += sumProp && item[sumProp] ? item[sumProp] : 0;
        wordSummary.wordObjs[wordIdx].avg = wordSummary.wordObjs[wordIdx].sum / wordSummary.wordObjs[wordIdx].count;
      } else {
        skippedWords++;
        if (wordSummary.skipped.indexOf(word) === -1)
          wordSummary.skipped.push(word);
      }

    });
  });


  wordSummary.wordObjs = sortObjectArrayByChildNumberKey(wordSummary.wordObjs, 'dec', sortKey);

  // Resort the words by the given sort
  wordSummary.words = wordSummary.wordObjs.map( wordOb => { return wordOb.word });

  wordSummary.performance = updatePerformanceEndV2({ op: processOp, updateMiliseconds: true, count: items.length });

  console.log('Skipped words:', skippedWords, wordSummary.performance);


  return wordSummary;
}

export function updateWordSort(wordSummary: IWordSummary, sortKey: string): IWordSummary {
  wordSummary.wordObjs = sortObjectArrayByNumberKey(wordSummary.wordObjs, 'dec', sortKey);
  return wordSummary;
}
