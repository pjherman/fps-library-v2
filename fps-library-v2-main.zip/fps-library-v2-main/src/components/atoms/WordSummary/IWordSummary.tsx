
import { IPerformanceOp } from "../../molecules/Performance/IPerformance";
import { IAnySourceItem } from "../../molecules/AnyContent/IAnyContent";

export interface IWordSummary {
  words: string[];
  searchTextLC: string[]; // Used for comparison when case does not matter
  wordObjs: IWordObject[];
  performance: IPerformanceOp;
  skipped: string[];
}

export interface IWordObject {
  word: string;
  searchTextLC: string;
  count: number;
  sum: number;
  sourceIndexes: number[];
  sourceStrings: string[];
  avg?: number;
  originalIndex?: number;
}

// Same as above except it allows for passing in arrays of items related to the word for easier reuse
export interface IExtendedWordSummary extends IWordSummary {
  wordObjs: IExtendedWordObject[];
  performanceR: IPerformanceOp;
}

// Same as above except it allows for passing in arrays of items related to the word for easier reuse
export interface IExtendedWordObject extends IWordObject {
  related1?: IAnySourceItem[];
  related2?: IAnySourceItem[];
  related3?: IAnySourceItem[];
}
