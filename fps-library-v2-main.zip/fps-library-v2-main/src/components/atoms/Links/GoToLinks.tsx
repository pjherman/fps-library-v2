import * as React from 'react';

import { Icon } from 'office-ui-fabric-react/lib/Icon';

import { ISourceProps } from '../../../pnpjs/SourceItems/Interface';

import { IAnySourceItem } from "../../molecules/AnyContent/IAnyContent";

require('@mikezimm/fps-styles/dist/fpsGeneralCSS.css');

const CommonClasses: string[] = [ 'fps-gen-inBlockNoWrap', 'fps-gen-goToLink' ];
const CommonLinkCSS: React.CSSProperties = { fontWeight: 600 }

export interface IGoToListLink {
  primarySource: ISourceProps;
  showListLink?: boolean;
  listLinkCSS?: React.CSSProperties;
}

export function GetGoToListLink( props: IGoToListLink ): JSX.Element {

  const { primarySource, showListLink, listLinkCSS } = props;
  const { webUrl, webRelativeLink, listTitle, } = primarySource;

  const linkCSS: React.CSSProperties = listLinkCSS ? { ...CommonLinkCSS, ...listLinkCSS } : CommonLinkCSS;

  const gotoListLink: JSX.Element = showListLink === false || !webRelativeLink ? undefined : <div className={ CommonClasses.join(' ')} 
    onClick={ () => { window.open( `${webUrl}/${webRelativeLink}`,'_blank' ) ; } }
    style={ linkCSS }>
    { !listTitle ? `Open list ` : `Open ${listTitle}`} <Icon iconName='OpenInNewTab'/>
  </div>;

  return gotoListLink;

}

export function getGoToItemLinkUrl( item: IAnySourceItem, primarySource: ISourceProps ): string {

  const { FileRef, ID, } = item;
  const { searchHref } = item.FPSItem.Search;

  let viewItemLink = FileRef;
  if ( !viewItemLink && primarySource.viewItemLink) viewItemLink = primarySource.viewItemLink.replace('{{item.ID}}', ID);
  if ( !viewItemLink && searchHref ) viewItemLink = searchHref;

  return viewItemLink;

}

export interface IGoToItemLink extends IGoToListLink {
  altText?: string; // shows up before Icon and says 'Open List' by default
  showItemLink?: boolean; // Over-ride to hide link element all together
  item: IAnySourceItem;
  itemLinkCSS?: React.CSSProperties;
}

export function GetGoToItemLink( props: IGoToItemLink ): JSX.Element {

  const { primarySource, showItemLink, item, altText, itemLinkCSS } = props;

  const viewItemLink: string = getGoToItemLinkUrl( item, primarySource )
  const linkCSS: React.CSSProperties = itemLinkCSS ? { ...CommonLinkCSS, ...itemLinkCSS } : CommonLinkCSS;

  const gotoItemLink: JSX.Element = showItemLink === false || !viewItemLink ? undefined : <div className={ CommonClasses.join(' ')}
    onClick={ () => { window.open( viewItemLink, '_blank' ) ; } }
    style={ linkCSS }>
    { altText ? altText : `Open item` } <Icon iconName='OpenInNewTab'/>
  </div>;

  return gotoItemLink;

}

export interface IGetGoToLinks extends IGoToItemLink, IGoToListLink {
  layout?:  'h3' | 'div';  // default is adding to h3 row
  // altText?: string; // Longer OpenItem text
  // item: IAnySourceItem;
  // showListLink?: boolean;
  // showItemLink?: boolean;
  // // source: ISourceInfo;
  // primarySource: ISourceProps;

}

export function getGoToLinks( props: IGetGoToLinks ) : JSX.Element {

  const gotoItemLink: JSX.Element = GetGoToItemLink( props );

  const gotoListLink: JSX.Element = GetGoToListLink( props );

  const eleStyles: React.CSSProperties = { display: 'flex', justifyContent: 'flex-start', alignItems: 'center', paddingBottom: '20px' }

  let returnElement = undefined;
  if ( props.layout === 'div' ) {

    returnElement = <div style = { eleStyles }>
      {  props.item.ID ? <div style={{ marginRight: '30px' }}>{ props.item.ID }</div> : undefined }
      { gotoItemLink }
      { gotoListLink }
    </div>;

  } else {

    returnElement = <h3 style = { eleStyles }>
      <div style={{ marginRight: '30px' }}>{ props.item.ID }</div>
      { gotoItemLink }
      { gotoListLink }
    </h3>;

  }

  return returnElement;

}

export interface IGoToWebLink {
  primarySource: ISourceProps;
  showWebLink?: boolean; // Over-ride to hide link element all together
  altWebText?: string;  // default:  `Site Url: `
  webLinkCSS?: React.CSSProperties;
  showWebIcon?: boolean; // default: true

}

export function GetGoToWebLink( props: IGoToWebLink ) : JSX.Element {

  const { primarySource, showWebLink, webLinkCSS, showWebIcon, altWebText } = props;
  const { webUrl, } = primarySource;

  // Copied from SourcePages in Compliance
  const defaultWebCSS: React.CSSProperties = { color: 'black', fontSize: 'large', paddingBottom: '10px' };
  const linkCSS: React.CSSProperties = webLinkCSS ? { ...CommonLinkCSS, ...defaultWebCSS, ...webLinkCSS } : { ...CommonLinkCSS, ...defaultWebCSS };

  const gotoWebLink: JSX.Element = showWebLink === false || !webUrl ? undefined : <div className={ CommonClasses.join(' ')}
    onClick={ () => { window.open( primarySource.webUrl, '_blank' ) ; } }
    style={ linkCSS }>
    { altWebText ? altWebText :`Site Url: ` } { primarySource.webUrl } { showWebIcon === true ? <Icon iconName='OpenInNewTab'/> : undefined }
  </div>;

  return gotoWebLink;
}

