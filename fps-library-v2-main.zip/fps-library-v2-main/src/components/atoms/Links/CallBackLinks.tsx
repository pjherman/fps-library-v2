import * as React from 'react';
import { Icon,} from 'office-ui-fabric-react/lib/Icon';
import { ICallbackAddParamToUrl } from '../../../banner/FPSWebPartClass/IThisFPSWebPartClass';

const LinkStyles: React.CSSProperties = { padding: '3px 0px', margin: '5px 8px', color: 'darkblue', cursor: 'pointer', whiteSpace: 'nowrap' };

/**
 * createParamLink will create a paramter link like:  setLayout=Layout2 
 *    that will be clickable to call function on class level to update Url and re-render the web part
 *    This will let you both update the page url with the parameter, open the current page with new paramter in a new tab and also rerender the web part
 * @param param 
 * @param onClick 
 * @param newTab 
 * @returns 
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function createParamLink( param: string, onClick: ICallbackAddParamToUrl, newTab: boolean = false ): JSX.Element {
  const iconName: string = window.location.search.toLowerCase().indexOf( param.toLowerCase() ) > -1 ? 'CheckboxComposite' : 'Checkbox' ;
  const iconColor: string = iconName === 'Checkbox' ? 'darkgreen' : 'darkred';
  const linky: JSX.Element = <a style={{ ...LinkStyles, ...{ color: iconColor }}} 
      onClick={() => { onClick( param, newTab === true ? false : true, newTab, ); }}
    ><Icon style={{ paddingRight: '5px'}} iconName={ iconName } />?{param}</a>;
  return linky;
}

export function paramLinks( showParams: string[], addParamToUrl: ICallbackAddParamToUrl ): JSX.Element {
  const paramLinks: JSX.Element = <div>
    { showParams.map( param =>  { return createParamLink( param, addParamToUrl, ) } ) }
  </div>;
  return paramLinks;
}
