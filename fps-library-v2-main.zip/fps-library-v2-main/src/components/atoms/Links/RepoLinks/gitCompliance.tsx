import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';


export const gitCompliance: IRepoLinks = createRepoLinks(baseMyRepos + 'Compliance', '_blank', 'Compliance Ops', SmallStyle);
