import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';

// export const gitRepoTrackMyTime: IRepoLinks = createRepoLinks( baseMyRepos + 'TrackMyTime7v2021', '_blank', 'TrackMyTime-7', SmallStyle );
// export const gitRepoPivotTiles: IRepoLinks = createRepoLinks( baseMyRepos + 'pivottiles7','_blank', 'Pivot-Tiles-7', SmallStyle );
// export const gitRepoDrillDown: IRepoLinks = createRepoLinks( baseMyRepos + 'drilldown7','_blank', 'Drilldown-7', SmallStyle );
// export const gitRepoSocialiis: IRepoLinks = createRepoLinks( baseMyRepos + 'Social-iis-7','_blank', 'Social-iis-7', SmallStyle );
// export const gitRepoGridCharts: IRepoLinks = createRepoLinks( baseMyRepos + 'gridcharts','_blank', 'GridCharts', SmallStyle );
// export const gitRepoCarrotCharts: IRepoLinks = createRepoLinks( baseMyRepos + 'carrotcharts','_blank', 'Carrot charts', SmallStyle );
// export const gitRepoEasyContnets: IRepoLinks = createRepoLinks( baseMyRepos + 'generic-solution', '_blank', 'Easy Contents', SmallStyle );
// export const gitRepoActionNews: IRepoLinks = createRepoLinks( baseMyRepos + 'actionnews','_blank', 'ActionNews', SmallStyle );
// export const gitRepoImageMapper: IRepoLinks = createRepoLinks( baseMyRepos + 'imagemapper','_blank', 'Image Mapper', SmallStyle);
// export const gitRepoEasyStorage: IRepoLinks = createRepoLinks( baseMyRepos + 'ECStorage','_blank', 'Extreme Storage', SmallStyle );
/**
 *  My repos - For Banner component in Panel
 */
// export const baseMyRepos = 'https://github.com/mikezimm/';

export const gitPivotTiles: IRepoLinks = createRepoLinks(baseMyRepos + 'pivottiles7', '_blank', 'Pivot-Tiles-7', SmallStyle);
