import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseFPSRepos, baseMyRepos, SmallStyle } from './LinksCommon';

export const gitCoreFPS1173: IRepoLinks = createRepoLinks(baseFPSRepos + 'CoreFPS1173', '_blank', 'Core-FPS-1.17.3', SmallStyle);
export const gitCoreFPS118x: IRepoLinks = createRepoLinks(baseFPSRepos + 'CoreFPS118x', '_blank', 'Core-FPS-1.18.x', SmallStyle);
export const gitCoreFPS119x: IRepoLinks = createRepoLinks(baseFPSRepos + 'CoreFPS119x', '_blank', 'Core-FPS-1.19.x', SmallStyle);
export const gitCoreFPS1XXX: IRepoLinks = createRepoLinks(baseFPSRepos + 'CoreFPS1XXX', '_blank', 'Core-FPS-1.XX.X', SmallStyle);
export const gitCoreFPS114: IRepoLinks = createRepoLinks(baseMyRepos + 'CoreFPS114', '_blank', 'Core-FPS-1.14', SmallStyle);
export const gitCoreFPS115: IRepoLinks = createRepoLinks(baseMyRepos + 'CoreFPS115', '_blank', 'Core-FPS-1.15', SmallStyle);
export const gitCoreFPS1152: IRepoLinks = createRepoLinks(baseMyRepos + 'CoreFPS1152', '_blank', 'Core-FPS-1.15.2', SmallStyle);
