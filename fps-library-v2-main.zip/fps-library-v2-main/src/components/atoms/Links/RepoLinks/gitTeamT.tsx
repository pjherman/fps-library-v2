import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';


export const gitTeamT: IRepoLinks = createRepoLinks(baseMyRepos + 'TT-script-editor-1.15.2', '_blank', 'TT-Script Editor', SmallStyle);
