import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';


export const gitALVFinMan: IRepoLinks = createRepoLinks(baseMyRepos + 'ALVFinMan', '_blank', 'ALV Financial Manual', SmallStyle);
