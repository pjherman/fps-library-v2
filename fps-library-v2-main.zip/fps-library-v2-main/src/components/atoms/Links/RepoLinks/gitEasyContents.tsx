import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';


export const gitEasyContents: IRepoLinks = createRepoLinks(baseMyRepos + 'generic-solution', '_blank', 'Easy Contents', SmallStyle);
