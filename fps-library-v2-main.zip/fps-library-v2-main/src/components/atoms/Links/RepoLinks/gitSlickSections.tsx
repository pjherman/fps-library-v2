import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';


export const gitSlickSections: IRepoLinks = createRepoLinks(baseMyRepos + 'Slick-Sections', '_blank', 'Slick Sections', SmallStyle);
