import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { SmallStyle, baseFPSRepos } from './LinksCommon';


export const gitHubConnections: IRepoLinks = createRepoLinks(baseFPSRepos + 'HubCon', '_blank', 'Hub Connections', SmallStyle);
