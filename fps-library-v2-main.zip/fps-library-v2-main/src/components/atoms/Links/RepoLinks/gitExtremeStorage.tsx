import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';


export const gitExtremeStorage: IRepoLinks = createRepoLinks(baseMyRepos + 'ECStorage', '_blank', 'Extreme Storage', SmallStyle);
