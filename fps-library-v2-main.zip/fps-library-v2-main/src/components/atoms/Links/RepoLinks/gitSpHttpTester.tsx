import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { SmallStyle, baseFPSRepos } from './LinksCommon';


export const gitSpHttpTester: IRepoLinks = createRepoLinks(baseFPSRepos + 'SpHttpTester', '_blank', 'SpHttpTester', SmallStyle);
