import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';


export const gitPowerSearch: IRepoLinks = createRepoLinks(baseMyRepos + 'PowerSearch', '_blank', 'Power Search', SmallStyle);
