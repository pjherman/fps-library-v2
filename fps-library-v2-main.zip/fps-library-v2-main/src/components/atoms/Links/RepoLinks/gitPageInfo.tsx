import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';


export const gitPageInfo: IRepoLinks = createRepoLinks(baseMyRepos + 'PageInfo', '_blank', 'FPS PageInfo', SmallStyle);
