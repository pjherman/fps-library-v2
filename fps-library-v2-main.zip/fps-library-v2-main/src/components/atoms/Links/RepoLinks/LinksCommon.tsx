import { alwaysTricky } from '../../../../banner/features/Tricky/constants';
import { createLink, createRepoLinks, IRepoLinks } from '../CreateLinks';

/**
 *  My repos - Legacy Early Access Banner style
 */

export const baseMyRepos = 'https://github.com/mikezimm/';
export const baseFPSRepos = 'https://github.com/fps-solutions/';

export const SmallStyle = `small`;
export const LegacyStyle = `legacy`;

export const trickyEmails = alwaysTricky;
/**
 *  Github Repos
 */

export const baseGitContReact = 'https://github.com/SharePoint/sp-dev-fx-controls-react/';
export const gitSPFxContReact = createLink(baseGitContReact, '_blank', 'controls-react');
export const gitPnpJSsp = createLink('https://pnp.github.io/pnpjs/', '_blank', 'pnpjs');

export const gitFpsLibraryV2: IRepoLinks = createRepoLinks(baseMyRepos + 'fps-library-v2', '_blank', 'fps-library-v2', LegacyStyle);
export const gitFpsStyles: IRepoLinks = createRepoLinks(baseMyRepos + 'fps-styles', '_blank', 'fps-styles', LegacyStyle);
export const gitFpsPnp2: IRepoLinks = createRepoLinks(baseMyRepos + 'fps-pnp2', '_blank', 'fps-pnp2', LegacyStyle);
export const gitPnpjsV2: IRepoLinks = createRepoLinks(baseMyRepos + 'Pnpjs-v2-Upgrade-sample', '_blank', 'Pnpjs-v2-Upgrade-sample', LegacyStyle);


