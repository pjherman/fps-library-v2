import { createLink, createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';

/**
 * Track My Time links
 */

export const gitTrackMyTime: IRepoLinks = createRepoLinks(baseMyRepos + 'TrackMyTime7v2021', '_blank', 'TrackMyTime-7', SmallStyle);
export const gitTMTActivityTypeWiki = createLink(baseMyRepos + 'TrackMyTime7v2021/wiki/ActivityURL%5E-calculated-column-example', '_blank', 'ActivityType examples');
export const gitTMTActivityURLWiki = createLink(baseMyRepos + 'TrackMyTime7v2021/wiki/ActivityURL%5E-calculated-column-example', '_blank', 'ActivityURL^ Formula examples');
export const gitTMTOptionsWiki = createLink(baseMyRepos + 'TrackMyTime7v2021/wiki/Options%5E-calculated-column-example', '_blank', 'Options^ Formula examples');
