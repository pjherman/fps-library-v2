import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseFPSRepos, SmallStyle } from './LinksCommon';

/**
 *  My repos - For Banner component in Panel
 */
// export const baseMyRepos = 'https://github.com/mikezimm/';

export const gitRtfFixer: IRepoLinks = createRepoLinks(baseFPSRepos + 'Rtf-Fixer', '_blank', 'FPS-Rtf-Fixer', SmallStyle);
