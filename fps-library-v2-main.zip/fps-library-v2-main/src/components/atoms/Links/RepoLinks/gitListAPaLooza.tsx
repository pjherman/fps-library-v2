import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';

export const gitListAPaLooza: IRepoLinks = createRepoLinks(baseMyRepos + 'ListAPaLooza', '_blank', 'List-A-Pa-Looza', SmallStyle);
