

import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';

export const gitSocialiis: IRepoLinks = createRepoLinks( baseMyRepos + 'Social-iis-7','_blank', 'Social-iis-7', SmallStyle );
export const gitGridCharts: IRepoLinks = createRepoLinks( baseMyRepos + 'gridcharts','_blank', 'GridCharts', SmallStyle );
export const gitCarrotCharts: IRepoLinks = createRepoLinks( baseMyRepos + 'carrotcharts','_blank', 'Carrot charts', SmallStyle );

export const gitActionNews: IRepoLinks = createRepoLinks( baseMyRepos + 'actionnews','_blank', 'ActionNews', SmallStyle );
export const gitImageMapper: IRepoLinks = createRepoLinks( baseMyRepos + 'imagemapper','_blank', 'Image Mapper', SmallStyle );


