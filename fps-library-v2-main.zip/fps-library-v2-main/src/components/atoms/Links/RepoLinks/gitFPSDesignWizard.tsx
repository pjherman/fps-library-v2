import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseFPSRepos, SmallStyle } from './LinksCommon';

export const gitFPSDesignWizard: IRepoLinks = createRepoLinks(baseFPSRepos + 'FPS-Design-Wizard', '_blank', 'FPS-Design-Wizard', SmallStyle);
