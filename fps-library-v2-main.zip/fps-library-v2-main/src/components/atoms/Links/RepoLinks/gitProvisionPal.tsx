import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseFPSRepos, SmallStyle } from './LinksCommon';

/**
 *  My repos - For Banner component in Panel
 */
// export const baseMyRepos = 'https://github.com/mikezimm/';

export const gitProvisionPal: IRepoLinks = createRepoLinks(baseFPSRepos + 'Provision-Pal', '_blank', 'FPS-Provision-Pal', SmallStyle);
