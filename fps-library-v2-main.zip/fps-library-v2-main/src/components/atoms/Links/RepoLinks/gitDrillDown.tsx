import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';

export const gitDrillDown: IRepoLinks = createRepoLinks(baseMyRepos + 'drilldown7', '_blank', 'Drilldown-7', SmallStyle);
