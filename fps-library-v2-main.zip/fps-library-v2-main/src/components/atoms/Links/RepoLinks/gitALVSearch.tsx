import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';


export const gitALVSearch: IRepoLinks = createRepoLinks(baseMyRepos + 'ALVSearchV2', '_blank', 'ALV Search', SmallStyle);
