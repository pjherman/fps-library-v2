import { createRepoLinks, IRepoLinks } from '../CreateLinks';
import { baseMyRepos, SmallStyle } from './LinksCommon';


export const gitSecureScript7: IRepoLinks = createRepoLinks(baseMyRepos + 'SecureScript7', '_blank', 'Secure Script', SmallStyle);
