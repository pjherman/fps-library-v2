import * as React from 'react';

import { Icon } from 'office-ui-fabric-react/lib/Icon';

import { ISourceProps } from '../../../pnpjs/SourceItems/Interface';

import { IAnySourceItem } from "../../molecules/AnyContent/IAnyContent";

require('@mikezimm/fps-styles/dist/fpsGeneralCSS.css');

export interface IGetGoToLinks {
  layout?:  'h3' | 'div';  // default is adding to h3 row
  altOpenItem?: string; // Longer OpenItem text
  item: IAnySourceItem;
  showListLink?: boolean;
  showItemLink?: boolean;
  // source: ISourceInfo;
  primarySource: ISourceProps;

}

export function getGoToLinks( props: IGetGoToLinks ) : JSX.Element {

  const { item, primarySource } = props;

  //Go directly to file if it's a file, else go to list item
  // const viewItemLink = props.showItemLink === false ? undefined : 
  // `${props.item.FileRef ? props.item.FileRef : primarySource.viewItemLink ? primarySource.viewItemLink.replace('{{item.ID}}', props.item.ID) : '' } `;searchHref

  let viewItemLink = props.item.FileRef;
  if ( !viewItemLink && primarySource.viewItemLink) viewItemLink = primarySource.viewItemLink.replace('{{item.ID}}', props.item.ID);
  if ( !viewItemLink && item.FPSItem.Search.searchHref ) viewItemLink = item.FPSItem.Search.searchHref;

  const gotoItemLink: JSX.Element = props.showItemLink === false || !viewItemLink ? undefined : <div style={{ marginRight: '30px' }}  className={ [ 'fps-gen-inBlockNoWrap', 'fps-gen-goToLink' ].join(' ')}
    onClick={ () => { window.open( viewItemLink, '_blank' ) ; } }>
    { props.altOpenItem ? props.altOpenItem : `Open item` } <Icon iconName='OpenInNewTab'/>
  </div>;

  const gotoListLink: JSX.Element = props.showListLink === false || !primarySource.webRelativeLink ? undefined : <div className={ [ 'fps-gen-inBlockNoWrap', 'fps-gen-goToLink' ].join(' ')} 
    onClick={ () => { window.open( `${primarySource.webUrl}${primarySource.webRelativeLink}`,'_blank' ) ; } }>
    Open list <Icon iconName='OpenInNewTab'/>
  </div>;

  const eleStyles: React.CSSProperties = { display: 'flex', justifyContent: 'flex-start', alignItems: 'center', paddingBottom: '20px' }

  let returnElement = undefined;
  if ( props.layout === 'div' ) {

    returnElement = <div style = { eleStyles }>
      {  props.item.ID ? <div style={{ marginRight: '30px' }}>{ props.item.ID }</div> : undefined }
      { gotoItemLink }
      { gotoListLink }
    </div>;

  } else {

    returnElement = <h3 style = { eleStyles }>
      <div style={{ marginRight: '30px' }}>{ props.item.ID }</div>
      { gotoItemLink }
      { gotoListLink }
    </h3>;

  }

  return returnElement;

}