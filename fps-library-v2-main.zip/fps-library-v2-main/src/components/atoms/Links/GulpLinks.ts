
export const gulpParam1 = 'debug=true&noredir=true&debugManifestsFile=https://localhost:4321/temp/manifests.js';
export const gulpParam2 = 'debug=true&noredir=true&debugManifestsFile=https%3A%2F%2Flocalhost%3A4321%2Ftemp%2Fmanifests.js';

export function addGulpParam( current: string, ): string {
  const hasGulp1: boolean = current.indexOf( gulpParam1 ) > 0 ? true : false;
  const hasGulp2: boolean = current.indexOf( gulpParam2 ) > 0 ? true : false;

  if ( hasGulp1 === true || hasGulp2 === true ) return current;
  const final: string = current.indexOf('?') > 0 ? `${current}&${gulpParam1}` : `${current}?${gulpParam1}` ;
  return final;
}

export function removeGulpParam( current: string, ): string {
  return !current ? '' : current.replace( gulpParam1, '' ).replace( gulpParam2, '' );
}