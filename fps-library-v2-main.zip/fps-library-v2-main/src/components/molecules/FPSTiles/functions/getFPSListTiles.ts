
import { IFPSItem } from '../../AnyContent/IAnyContent';
import { ISourceProps } from '../../../../pnpjs/SourceItems/Interface';
import { ISourceSearch } from '../../SearchPage/Interfaces/ISourceSearch';
import { IWebpartBannerProps } from '../../../../banner/mainReact/IWebpartBannerProps';
import { createErrorFPSTileItem } from './Any/createErrorFPSTileItem';
import { IStateSource } from '../../../../pnpjs/Common/IStateSource';
import { MAXSearchTypes } from '../../SearchPage/Interfaces/ProgrammingFileKeys';
import { IMinFetchListProps, getWebLists } from '../../../../pnpjs/Lists/getList/getWebLists';
import { makeFPSListTiles } from './Lists/makeFPSListTiles';
import { addPopularityToItems } from '../../SearchPage/functions/markPopular';
import { addSearchMeta2 } from '../../SearchPage/functions/addSearchMeta2';
import { addSearchMeta1 } from '../../SearchPage/functions/addSearchMeta1';
import { addListIsAMeta } from '../../SearchPage/functions/addListIsAMeta';
import { EmptyFPSItemSearch } from '../../AnyContent/IFPSItemSearch';
// import { makeFPSFileTileItems } from './Lists/makeFPSTileItems';

/**
 * getFPSHubTiles was built for Hub Connection's web part to fetch both sites and webs.
 *    Use the depth property to specify either sites or webs.
 * 
 * Be sure to filter for Lists/Libraries/SystemLists etc in the parent component
 * 
 * @param bannerProps
 * @param sourceProps
 * @param search
 * @param WPFPSItem - use buildFpsTileWPProps
 * @param departmentId - if for current site, leave empty, will get from bannerProps
 * @returns
 */
export async function getFPSListTiles( bannerProps: IWebpartBannerProps, ListProps: IMinFetchListProps, search: ISourceSearch, webPartFPSItem: IFPSItem, ): Promise<IStateSource> { // surpressKeys: IItemIsAKeys[] = CommonSuppressKeys

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let results: IStateSource = await getWebLists( ListProps , true, true) as any;
  if ( !results.index ) results.index = []; // Adding because I cast results as any 

  if (results.status !== 'Success') {
    results.itemsY = [ createErrorFPSTileItem( results, webPartFPSItem ) ];

  } else {

    // HAVE TO ADD THIS AHEAD OF addSearchMeta1 because addSearchMeta1 does some search processing
    results.itemsY = results.items.map( item => {
      item.FPSItem = {
        IsA: { allIsAKeys: [] },
        File: { valid: false, fileDisplayName: '' },
        Search: JSON.parse(JSON.stringify( EmptyFPSItemSearch )),
      };
      item = addListIsAMeta( item );
      return item;
    });

    // doing addSearchMetaAllV2 but without the
    // results.itemsY = addSearchMetaAllV2(results.items, ListProps as ISourceProps, search, MAXSearchTypes, .2);

    results.itemsY = addSearchMeta1( results.items, ListProps as ISourceProps, search );

    results.itemsY = addSearchMeta2( results.itemsY, MAXSearchTypes );
    results.itemsY = addPopularityToItems( results.itemsY, .2 );

    results = makeFPSListTiles( results, bannerProps, webPartFPSItem );

  }

  return results;

}
