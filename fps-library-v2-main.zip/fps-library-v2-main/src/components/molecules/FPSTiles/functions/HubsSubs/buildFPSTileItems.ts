
import { IAnySourceItem, IFPSItem } from '../../../AnyContent/IAnyContent';
import { IStateSourceHubSubs } from '../../../SpHttp/HubsSubs/getHubAssocSites';
import { IAnyWeb } from '../../../AnyContent/IAnyWeb';
import { getEasyIcon } from '../../../../atoms/EasyIcons/functions/getEasyIcon';
import { IWebpartBannerProps } from '../../../../../banner/mainReact/IWebpartBannerProps';
import { gulpParam1 } from '../../../../atoms/Links/GulpLinks';
import { createContentViewsRecent } from '../../../../atoms/Highlights/createContentViewsRecent';
import { createItemHighlights } from '../../../../atoms/Highlights/createItemHighlights';
import { CommonSuppressKeys, IItemIsAKeys } from '../../../AnyContent/IsA/IFPSItemIsA';

/**
 * DEPRECATED... USE makeFPSSubHubTileItemsV2
 * @param bannerProps
 * @param sourceProps
 * @param search
 * @param WPFPSItem
 * @param departmentId - if for current site, leave empty, will get from bannerProps
 * @returns
 */
export function buildFPSSubHubTileItems( results: IStateSourceHubSubs, bannerProps: IWebpartBannerProps, webPartFPSItem: IFPSItem, surpressKeys: IItemIsAKeys[] = CommonSuppressKeys ): IStateSourceHubSubs {

  results.itemsY.map(( item: IAnySourceItem ) => {
    const SubHubItem: IAnyWeb = item;
    const imageUrl: string = SubHubItem.SiteLogoUrl ? SubHubItem.SiteLogoUrl : // Sometimes comes across as SiteLogoUrl
      SubHubItem.SiteLogo ? SubHubItem.SiteLogo :  // NOTE:  SiteLogo seems to be used if Site is a Team
      SubHubItem.PictureThumbnailURL ? SubHubItem.PictureThumbnailURL :
      getEasyIcon( bannerProps.EasyIconsObject, item as any, undefined );

    item.FPSItem.Image = {
      src: imageUrl,
      fabric: {
        imgCover: webPartFPSItem.Image.fabric.imgCover,
        imgFit: webPartFPSItem.Image.fabric.imgFit,
      },
      css: {
        height: `${webPartFPSItem.Image.css.height}`,
        width: `${webPartFPSItem.Image.css.width}`,
        background: webPartFPSItem.Image.css.background,
      }
    }

    item.FPSItem.Icon = {
      name: !imageUrl ? 'SharePointLogo' : '',
    }

    const href: string = item.ServerRelativeUrl;
    item.FPSItem.Link = {
      href: href,
      altUrl: href,
      ctrlUrl: href,
      shiftUrl: href,
      metaUrl: `${href}?${gulpParam1}`,
      key3Url: href,
      title: `${ item.Title ? item.Title : '' }`,
      description: `${ item.Description ? item.Description : '' }`,
    }
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  // results.itemsY = addPopularityToItems( results.itemsY );
  // console.log('MockHubTiles', results.itemsY );

  results.itemsY.map((item: IAnySourceItem ) => {
    item.FPSItem.Elements = {
      content1: undefined, // Showing as undefined in order to reduce console.logs
      content2: undefined, // Showing as undefined in order to reduce console.logs
      content3: createContentViewsRecent(item),
      content4: createItemHighlights(item, { position: 'absolute', top: '10px', right: '10px', zIndex: 1 }, surpressKeys ),
    };
  });

  return results;

}
