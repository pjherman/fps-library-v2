
import { IAnySourceItem, IFPSItem } from '../../../AnyContent/IAnyContent';
import { IStateSourceHubSubs } from '../../../SpHttp/HubsSubs/getHubAssocSites';
import { IWebpartBannerProps } from '../../../../../banner/mainReact/IWebpartBannerProps';
import { CommonSuppressKeys, IItemIsAKeys } from '../../../AnyContent/IsA/IFPSItemIsA';
import { buildFPSAnyTileItems } from '../Any/buildFPSAnyTileItems';
import { addFPSViewHighlightElements } from '../Any/addViewHighlightElements';

/**
 * makeFPSSubHubTiles creates Tile elements including Highlights and others for Subs and Sites
 * @param bannerProps
 * @param sourceProps
 * @param search
 * @param WPFPSItem
 * @param departmentId - if for current site, leave empty, will get from bannerProps
 * @returns
 */

export function  makeFPSSubHubTiles( results: IStateSourceHubSubs, bannerProps: IWebpartBannerProps, 
    webPartFPSItem: IFPSItem, surpressKeys: IItemIsAKeys[] = CommonSuppressKeys ): IStateSourceHubSubs {

  results = buildFPSAnyTileItems( results, bannerProps, webPartFPSItem, ) as IStateSourceHubSubs;
  results = addFPSViewHighlightElements( results, surpressKeys ) as IStateSourceHubSubs;
  results.itemsY.map((item: IAnySourceItem ) => {
    if ( !item.FPSItem.Icon.name ) item.FPSItem.Icon.name = 'SharePointLogo';
  });

  return results;

}
