
import { IFPSItem, } from '../../AnyContent/IAnyContent';
import { IFpsTileComponentWPProps } from '../webPart/IFpsTileComponentWPProps';
import { getImgCover, getImgFit } from '../../../../common/Images/imgFit';
import { mergeDeep } from './mergeDeep';

/**
 * This will take WP Props and create a shell FpsItem object which can be added to the item later on or passed in to some components
 * @param wpProps 
 * @returns 
 * 
 */
export function buildFpsTileWPProps ( wpProps: IFpsTileComponentWPProps, hUnit: string = 'px', wUnit: string = 'px' ) : IFPSItem {
  const tileImgWidth : number = wpProps.tileLayout === 'small' || wpProps.tileLayout === 'med' ? Math.max( wpProps.tileImgWidth, 250 ) : wpProps.tileImgWidth;
  const FpsItem: IFPSItem = {
    Image: {
      src: ``,
      css: {
        height: `${wpProps.tileImgHeight}${hUnit}`,
        width: `${tileImgWidth}${wUnit}`,
        background: wpProps.tileImgBackground,
      },
      fabric: {
        imgCover: getImgCover( wpProps.tileImgCover ),
        imgFit: getImgFit( wpProps.tileImgFit ),
      }
    },
    Link: {
      href: ``,
    },
    Icon: {
      name: ``,
    },
    IsA: { allIsAKeys: [] }
  }

  return FpsItem;

}

/**
 * mergeFPSItemProps will take the wpProps and create FPSItem.
 *   Then, if there is a previousFpsItem, it will merge those into the ones based on current props.
 *   This means that if you run this type of function twice, the second time will take precedence on the same object.
 * 
 * @param wpProps 
 * @param previousFpsItem 
 * @returns 
 */
export function mergeFPSItemProps ( wpProps: IFpsTileComponentWPProps, previousFpsItem?: IFPSItem ): IFPSItem {

  const thisFPSItem: IFPSItem = buildFpsTileWPProps( wpProps );
  if ( !previousFpsItem ) return thisFPSItem;

  const mergedFPSItem: IFPSItem = mergeDeep( thisFPSItem, previousFpsItem, [ 'Elements', ] );
  return mergedFPSItem;

}