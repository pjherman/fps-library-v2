
import { IFPSItem } from '../../AnyContent/IAnyContent';
import { ISourceProps } from '../../../../pnpjs/SourceItems/Interface';
import { ISourceSearch } from '../../SearchPage/Interfaces/ISourceSearch';
import { IWebpartBannerProps } from '../../../../banner/mainReact/IWebpartBannerProps';
import { createErrorFPSTileItem } from './Any/createErrorFPSTileItem';
import { IStateSource } from '../../../../pnpjs/Common/IStateSource';
import { getSourceItems } from '../../../../pnpjs/SourceItems/getSourceItems';
import { addSearchMetaAllV2 } from '../../SearchPage/functions/addSearchAllV2';
import { MAXSearchTypes } from '../../SearchPage/Interfaces/ProgrammingFileKeys';
import { CommonSuppressKeys, IItemIsAKeys } from '../../AnyContent/IsA/IFPSItemIsA';
import { makeFPSItemTiles } from './Items/makeFPSItemTiles';
// import { makeFPSFileTileItems } from './Lists/makeFPSTileItems';

/**
 * getFPSHubTiles was built for Hub Connection's web part to fetch both sites and webs.
 *    Use the depth property to specify either sites or webs.
 * @param bannerProps
 * @param sourceProps
 * @param search
 * @param WPFPSItem - use buildFpsTileWPProps
 * @param departmentId - if for current site, leave empty, will get from bannerProps
 * @returns
 */
export async function getFPSItemTiles( bannerProps: IWebpartBannerProps, sourceProps: ISourceProps, search: ISourceSearch, webPartFPSItem: IFPSItem, surpressKeys: IItemIsAKeys[] = CommonSuppressKeys): Promise<IStateSource> {

  let results: IStateSource = await getSourceItems(sourceProps, false, true ) as IStateSource;

  if (results.status !== 'Success') {
    results.itemsY = [ createErrorFPSTileItem( results, webPartFPSItem ) ];

  } else {
    results.itemsY = addSearchMetaAllV2(results.items, sourceProps, search, MAXSearchTypes, .2);

    // moved below function directly into this one.
    results = makeFPSItemTiles( results, bannerProps, webPartFPSItem );

    // results = buildFPSAnyTileItems( results, bannerProps, webPartFPSItem, ) as IStateSource;
    // results = addFPSViewHighlightElements( results, surpressKeys ) as IStateSource;

  }

  return results;

}
