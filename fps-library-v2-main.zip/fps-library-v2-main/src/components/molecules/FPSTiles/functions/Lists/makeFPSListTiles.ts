
import { IAnySourceItem, IFPSItem } from '../../../AnyContent/IAnyContent';
import { IWebpartBannerProps } from '../../../../../banner/mainReact/IWebpartBannerProps';
import { createContentViewsRecent } from '../../../../atoms/Highlights/createContentViewsRecent';
import { createItemHighlights } from '../../../../atoms/Highlights/createItemHighlights';
import { CommonSuppressKeys, IItemIsAKeys } from '../../../AnyContent/IsA/IFPSItemIsA';
import { buildFPSAnyTileItems } from '../Any/buildFPSAnyTileItems';
import { IStateSource } from '../../../../../pnpjs/Common/IStateSource';
import { createContentPubDate } from '../../../../atoms/Highlights/createContentPubDate';
import { createContentItemCount } from '../../../../atoms/Highlights/createContentItemCount';

/**
 *
 * @param bannerProps
 * @param sourceProps
 * @param search
 * @param WPFPSItem
 * @param departmentId - if for current site, leave empty, will get from bannerProps
 * @returns
 */

export function  makeFPSListTiles( results: IStateSource, bannerProps: IWebpartBannerProps, 
    webPartFPSItem: IFPSItem, surpressKeys: IItemIsAKeys[] = CommonSuppressKeys ): IStateSource {

  results = buildFPSAnyTileItems( results, bannerProps, webPartFPSItem, ) as IStateSource;
  results.itemsY.map((item: IAnySourceItem ) => {
    if ( !item.FPSItem.Elements ) {
      item.FPSItem.Elements = {
        content1: createContentPubDate( item as IAnySourceItem ), // Currently nothing but could be LastModifiedDate?
        content2: createContentItemCount( item as IAnySourceItem, 'V' ),
        content3: createContentViewsRecent( item as IAnySourceItem ), // Currently nothing because it may not be available
        content4: createItemHighlights( item as IAnySourceItem, {position: 'absolute', top: '10px', right: '10px', zIndex: 1,  }, surpressKeys ),

      };
    }
  });

  return results;

}
