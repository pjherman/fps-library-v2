
import { IFPSItem } from '../../../AnyContent/IAnyContent';
import { IWebpartBannerProps } from '../../../../../banner/mainReact/IWebpartBannerProps';
import { CommonSuppressKeys, IItemIsAKeys } from '../../../AnyContent/IsA/IFPSItemIsA';
import { buildFPSAnyTileItems } from '../Any/buildFPSAnyTileItems';
import { IStateSource } from '../../../../../pnpjs/Common/IStateSource';
import { addFPSViewHighlightElements } from '../Any/addViewHighlightElements';

/**
 *  DEPRECTED:  USE getFPSListItemTiles which has the Get and this
 * @param bannerProps
 * @param sourceProps
 * @param search
 * @param WPFPSItem
 * @param departmentId - if for current site, leave empty, will get from bannerProps
 * @returns
 */

export function  makeFPSItemTiles( results: IStateSource, bannerProps: IWebpartBannerProps, 
    webPartFPSItem: IFPSItem, surpressKeys: IItemIsAKeys[] = CommonSuppressKeys ): IStateSource {

  results = buildFPSAnyTileItems( results, bannerProps, webPartFPSItem, ) as IStateSource;
  results = addFPSViewHighlightElements( results, surpressKeys ) as IStateSource;

  return results;

}
