
import { IFPSItem } from '../../AnyContent/IAnyContent';
import { IFetchHubDepth, fetchMyHubsites } from '../../SpHttp/HubsSubs/fetches/fetchMyHubsites';
import { ISourceProps } from '../../../../pnpjs/SourceItems/Interface';
import { ISourceSearch } from '../../SearchPage/Interfaces/ISourceSearch';
import { IStateSourceHubSubs } from '../../SpHttp/HubsSubs/getHubAssocSites';
import { processHubSubResults } from '../../SpHttp/HubsSubs/functions/processHubSubResults';
import { IWebpartBannerProps } from '../../../../banner/mainReact/IWebpartBannerProps';
import { createErrorFPSTileItem } from './Any/createErrorFPSTileItem';
import { makeFPSSubHubTiles } from './HubsSubs/makeFPSSubHubTiles';
import { CommonSuppressKeys, IItemIsAKeys } from '../../AnyContent/IsA/IFPSItemIsA';

/**
 * getFPSHubTiles was built for Hub Connection's web part to fetch both sites and webs.
 *    Use the depth property to specify either sites or webs.
 * @param bannerProps
 * @param sourceProps
 * @param search
 * @param WPFPSItem - use buildFpsTileWPProps
 * @param departmentId - if for current site, leave empty, will get from bannerProps
 * @returns
 */
export async function getFPSHubTiles( bannerProps: IWebpartBannerProps, sourceProps: ISourceProps, search: ISourceSearch, 
      webPartFPSItem: IFPSItem, departmentId?: string, depth: IFetchHubDepth = 'site', 
      surpressKeys: IItemIsAKeys[] = CommonSuppressKeys ): Promise<IStateSourceHubSubs> {

  const useDepartmentId = departmentId ? departmentId : bannerProps.context.pageContext.legacyPageContext.departmentId;
  let results: IStateSourceHubSubs = await fetchMyHubsites( bannerProps.context.pageContext.web.absoluteUrl, depth, useDepartmentId,  ) as any;

  if (results.status !== 'Success') {
    results.itemsY = [ createErrorFPSTileItem( results, webPartFPSItem ) ];

  } else {
    results = processHubSubResults(results, sourceProps, search, departmentId );
    // moved code from makeFPSSubHubTileItemsV2 directly into here
    results = makeFPSSubHubTiles( results, bannerProps, webPartFPSItem, surpressKeys );

    // results = buildFPSAnyTileItems( results, bannerProps, webPartFPSItem, ) as IStateSourceHubSubs;
    // results = addFPSViewHighlightElements( results, surpressKeys ) as IStateSourceHubSubs;
    // results.itemsY.map((item: IAnySourceItem ) => {
    //   if ( !item.FPSItem.Icon.name ) item.FPSItem.Icon.name = 'SharePointLogo';
    // });

  }

  return results;

}
