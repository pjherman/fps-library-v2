import { IAnySourceItem } from "../../../molecules/AnyContent/IAnyContent";

export function onFPSClick(  event: React.MouseEvent<HTMLDivElement | HTMLButtonElement | HTMLAnchorElement | HTMLSpanElement | HTMLLinkElement >, tile: IAnySourceItem, ): void {

  const { altKey, ctrlKey, shiftKey, metaKey } = event;
  const { FPSItem } = tile;
  const { href, altUrl, ctrlUrl, shiftUrl, key3Url } = FPSItem ? FPSItem.Link : null;

  console.log( 'event', event );
  console.log( 'tile', tile );

  if ( metaKey ) {
    const metaClick = `${href}${ href.indexOf('?') > -1 ? '&' : '?' }debug=true&noredir=true&debugManifestsFile=https://localhost:4321/temp/manifests.js`;
    window.open( metaClick, '_none' ); // For SPO Link, _blank opens in new tab

  } else if ( altKey && shiftKey && ctrlKey ) {
    window.open( key3Url, '_none' );

  } else if ( ctrlKey ) {
    window.open( ctrlUrl, '_none' ); // For SPO Link, _none opens in new tab BUT DOES NOT jump to it

  } else if ( altKey ) {
    window.open( altUrl, '_blank' ); // For SPO Link, _blank opens in new tab AND Jumps to it

  } else if ( shiftKey ) {
    window.open( shiftUrl, '_none' );

  } else if ( href ) {
    window.open( href, '_self' ); // For SPO Link, _self opens in the CURRENT tab
  }


}