
import { IStateSource } from "../../../../../pnpjs/Common/IStateSource";
import { createContentViewsRecent } from "../../../../atoms/Highlights/createContentViewsRecent";
import { createItemHighlights } from "../../../../atoms/Highlights/createItemHighlights";
import { IAnySourceItem } from "../../../AnyContent/IAnyContent";
import { CommonSuppressKeys, IItemIsAKeys } from "../../../AnyContent/IsA/IFPSItemIsA";

export function addFPSViewHighlightElements( results: IStateSource, surpressKeys: IItemIsAKeys[] = CommonSuppressKeys ): IStateSource {

  results.itemsY.map((item: IAnySourceItem ) => {

    if ( !item.FPSItem.Elements ) {
      item.FPSItem.Elements = {
        content1: undefined, // Showing as undefined in order to reduce console.logs
        content2: undefined, // Showing as undefined in order to reduce console.logs
      };
    }

    const content3: JSX.Element = createContentViewsRecent(item);
    const content4: JSX.Element = createItemHighlights(item, { position: 'absolute', top: '10px', right: '10px', zIndex: 1 }, surpressKeys );

    item.FPSItem.Elements.content3 = content3;
    item.FPSItem.Elements.content4 = content4;

  });

  return results;

}