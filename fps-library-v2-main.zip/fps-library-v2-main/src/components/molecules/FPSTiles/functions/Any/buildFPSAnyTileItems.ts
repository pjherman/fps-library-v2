
import { IAnySourceItem, IFPSItem } from '../../../AnyContent/IAnyContent';
import { getEasyIcon } from '../../../../atoms/EasyIcons/functions/getEasyIcon';
import { IWebpartBannerProps } from '../../../../../banner/mainReact/IWebpartBannerProps';
import { gulpParam1 } from '../../../../atoms/Links/GulpLinks';
import { IStateSource } from '../../../../../pnpjs/Common/IStateSource';
import { ISearchType } from '../../../SearchPage/Interfaces/ISearchTypes';

/**
 *
 * @param bannerProps
 * @param sourceProps
 * @param search
 * @param WPFPSItem
 * @param departmentId - if for current site, leave empty, will get from bannerProps
 * @returns
 */

export function buildFPSAnyTileItems( results: IStateSource, bannerProps: IWebpartBannerProps, 
    webPartFPSItem: IFPSItem, ): IStateSource {

  // NOTE:  FILES SHOULD HAVE PREVIOUSLY RUN addSearchMetaAllV2 which includes:  addSearchFileDataItemsV2 and addSearchMeta2

  results.itemsY.map(( item: IAnySourceItem ) => {

    const TypicalItem: IAnySourceItem = item;

    const itemSearch : ISearchType[] = item?.FPSItem?.Search?.searchTypes;  // returns undefined if it does not exist at depth

    const searchType: ISearchType = itemSearch && itemSearch.length > 0 ? itemSearch[0] : null;
    const iconName = searchType ? searchType.icon :  '';  // TypicalFileItem.FileSystemObjectType === 1 ? 'FabricFolder' :

    const imageUrl: string = TypicalItem.SiteLogoUrl ? TypicalItem.SiteLogoUrl : // Sometimes comes across as SiteLogoUrl
      TypicalItem.SiteLogo ? TypicalItem.SiteLogo :  // NOTE:  SiteLogo seems to be used if Site is a Team
      TypicalItem.PictureThumbnailURL ? TypicalItem.PictureThumbnailURL :
      getEasyIcon( bannerProps.EasyIconsObject, item as any, undefined );

    const bestTitle = item.Title ? item.Title : item.FileLeafRef ? item.FileLeafRef : 'Unknown Title';
    let bestDesc = item.Description ? item.Description : item.FileRef ? item.FileRef : item.ServerRelativeUrl ? item.ServerRelativeUrl : '';
    if ( bestDesc === bestTitle ) bestDesc = ``;
    const bestHref = item.ServerRelativeUrl ? item.ServerRelativeUrl : item.FileRef ? item.FileRef : 'Unknown Link';
    const metaClick = `${bestHref}?${gulpParam1}`;

    item.FPSItem.Image = {
      src: imageUrl,
      fabric: {
        imgCover: webPartFPSItem.Image.fabric.imgCover,
        imgFit: webPartFPSItem.Image.fabric.imgFit,
      },
      css: {
        height: `${webPartFPSItem.Image.css.height}`,
        width: `${webPartFPSItem.Image.css.width}`,
        background: webPartFPSItem.Image.css.background,
      }
    }

    item.FPSItem.Icon = {
      name: `${iconName}`,
      css: {
        color: searchType ? searchType.color : '',
      }
    }

    item.FPSItem.Link = {
      href: bestHref,
      altUrl: bestHref,
      ctrlUrl: bestHref,
      shiftUrl: bestHref,
      metaUrl: metaClick,
      key3Url: bestHref,
      title: `${ bestTitle }`,
      description: `${ bestDesc }`,
    }
    if ( webPartFPSItem.Link.altClick ) item.FPSItem.Link.altClick = webPartFPSItem.Link.altClick;
  });

  return results;

}
