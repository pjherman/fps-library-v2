
import { IStateSource } from '../../../../../pnpjs/Common/IStateSource';
import { IAnySourceItem, IFPSItem } from '../../../AnyContent/IAnyContent';
import { EmptyFPSItemSearch } from '../../../AnyContent/IFPSItemSearch';
import { IStateSourceHubSubs } from '../../../SpHttp/HubsSubs/getHubAssocSites';

/**
 * createErrorFPSTileItem will build an item: IAnySourceItem with the correct FPSItem object which can be used in FPSTileComponent and FPSTileElement
 *  
 * @param results 
 * @param webPartFPSItem 
 * @param newTitle 
 * @param background 
  //  * @param hUnit These should be set right in FPSTileElement and not needed here.
  //  * @param wUnit These should be set right in FPSTileElement and not needed here.
 * @returns 
 */

export function createErrorFPSTileItem( results: IStateSource, webPartFPSItem: IFPSItem, newTitle: string = ``, background: string = `` ): IAnySourceItem {

  const Title: string= `${ newTitle ? newTitle : results.status }`;
  const Description: string= `${results.errorInfo?.friendly}`;

  const FPSItem: IFPSItem = {
    Search: JSON.parse(JSON.stringify( EmptyFPSItemSearch )),
    Image: {
      src: '',
      css: {
        height: !webPartFPSItem ? '18px' : webPartFPSItem.Image.css.height,
        width: !webPartFPSItem ? '18px' : webPartFPSItem.Image.css.width,
        background: background ? background : `yellow`,
      }
    },
    Icon: {
      name: 'StatusErrorFull',
      css: {
        // size:  `${tileHeight * .8 }${hUnit}`,
        color: `red`,
      },
      // react: { paddingTop: `${ ( tileHeight * .2 ) /2 }${hUnit}` }
    },
    Link: {
      href: ``,
      title: Title,
      description: Description,
    },
    IsA: { allIsAKeys: [] }
  }

  const item: IAnySourceItem = {
    Title: Title,
    Description: Description,
    FPSItem: FPSItem,
  }

  return item;

}


// export function NoListFound (parentProps: IPivotTiles20Props,parentState: IPivotTiles20State): JSX.Element  {
// //  console.log('NoListFound');
// //  console.log(parentProps);
//   let noListFound = null;

//   if ( parentState.loadStatus !== "ListNotFound" ) {
//     // console.log('parentState.loadStatus !== "ListNotFound" >> NoListFound');
//   } else {

//     const fixedURL = fixURLs(parentProps.tileList.listWebURL, parentProps.bannerProps.context.pageContext);

//     const errMessage = SanitizeErrorMessage(parentState.loadError);

//     const listExt = parentProps.tileList.listDefinition.indexOf("Library") === -1 ? "lists/" : "" ;

//     noListFound = 
//     <div className={styles.rowNoPad}>
//       <div className={parentState.loadStatus === "ListNotFound" ? styles.showErrorMessage : styles.hideMe }>
//           <h1>We had a problem getting your data: {parentProps.tileList.listTitle}</h1>
//           {errMessage}
//           Check your site contents for list:  <Link href={fixedURL + "_layouts/15/viewlsts.aspx"} target="_blank">{fixedURL}</Link>

//           <h2>Other common causes for this message</h2>
//           <h3>1) You do not have a Tile Category set for a visible tile:</h3>
//           <p><Link href={fixedURL + listExt + parentProps.tileList.listTitle} 
//               target="_blank">
//               {fixedURL + listExt + parentProps.tileList.listTitle}
//             </Link></p>
//           <h3>2) You do not have permissions to the list :(</h3>
//           <p>Please contact your site admin for assistance!</p>
//       </div>
//     </div>;

//   }

//   return noListFound;

// }

// export function NoItemsFound (parentProps: IPivotTiles20Props,parentState: IPivotTiles20State): JSX.Element  {
// //  console.log('NoListFound');
// //  console.log(parentProps);

// let noItemsFound = null;

// if ( parentState.loadStatus !== "ListNotFound" && parentState.loadStatus !== "NoItemsFound" ) {
//   // console.log('Did NOT find NoItemsFound - aka found something?' );

// } else if ( check4This ( 'fpsShowFetchResults=true' ) !== true ) {
//   // Skip warning if not showing this parameter https://github.com/mikezimm/pivottiles7/issues/267

// } else {

//     const fixedURL = fixURLs(parentProps.tileList.listWebURL, parentProps.bannerProps.context.pageContext);

//     const errMessage = SanitizeErrorMessage(parentState.loadError);

//     const listExt = parentProps.tileList.listDefinition.indexOf("Library") === -1 ? "lists/" : "" ;

//     noItemsFound = 
//     <div className={styles.rowNoPad}>
//       <div className={parentState.loadStatus === "NoItemsFound" ? styles.showErrorMessage : styles.hideMe }>
//         <p>{parentState.loadError}</p>
//         <h1>No items were found in your tile list: {parentProps.tileList.listTitle}</h1>
//         {errMessage}
//         <p>This is the filter we are using: <b>{parentProps.tileList.setFilter}</b></p>
//         <p>Looking here:</p>
//         <p><Link href={fixedURL + listExt + parentProps.tileList.listTitle} 
//             target="_blank">
//             {fixedURL + listExt + parentProps.tileList.listTitle}
//           </Link></p>
//         <p>You can also get this message if you do not have permissions to the list.</p>
//       </div>
//     </div>;
//   }

//   return noItemsFound;
// }

// // eslint-disable-next-line @typescript-eslint/no-explicit-any
// export function SanitizeErrorMessage(errIn: any): JSX.Element  {

//   const err = JSON.stringify(errIn);
//   if (errIn === "") {
//     return undefined;
//   }

//   let errType = "";
//   if (err.indexOf("[400]") > 0 ) {
//     errType = "[400] Bad Request?";

//   } else if  (err.indexOf("[403]") > 0 ) {
//     errType = "[403] Insufficient Permissions?";

//   } else if  (err.indexOf("[500]") > 0 ) {
//     errType = "[500] Internal Server Error?";

//   } else if  (err.indexOf("[503]") > 0 ) {
//     errType = "[503] Server Busy?";

//   } 

//   const messStart = err.indexOf('message');
//   let errValue = "";
//   if (messStart > 0 ) {
//     const valueStart = err.indexOf('value',messStart);
//     if (err.indexOf('value',valueStart) > 0 ) {
//       errValue = err.slice(valueStart + 9, valueStart + 1000);
//       errValue = errValue.replace(/[}]/g,'').replace(/[/]/g,'').replace(/["\\]/g,'');
//     } else {
//       errValue = err;
//     }
//   }

//   const thisError = 
//     <div>
//       <h2>{errType}</h2>
//       <p><mark>{errValue}</mark></p>
//       <p/>
//     </div>;

//     return thisError;

// }


// export const LoadErrorIcon = 'ErrorBadge';
// export const LoadErrorCategory = 'ErrorMessage';

// export function createErrorTile( sourceType: string, errTitle: string, errDetails: string, pivotProps: IPivotTiles20Props ): IPivotTileItemProps {

//   const tile : IPivotTileItemProps = {

//     system: '',
//     themeVariant: pivotProps.themeVariant,

//     //Custom image properties
//     imageWidth: pivotProps.images.imageWidth,
//     imageHeight: pivotProps.images.imageHeight,
//     textPadding: pivotProps.images.textPadding,

//     sourceType: sourceType,
//     sortValue: '',

//     id: '666',

//     title: errTitle,

//     description: errDetails,

//     href: null,

//     // https://github.com/mikezimm/pivottiles7/issues/274
//     // category: [ sourceType, 'LoadError', LoadErrorIcon, pivotProps.tabs.otherTab ],
//     category: [ sourceType, LoadErrorCategory, pivotProps.tabs.otherTab ],

//     setTab: pivotProps.tabs.setTab,
//     setSize: pivotProps.images.setSize,
//     heroType: pivotProps.hero.heroType,
//     heroCategory: 'currentHero',

//     Id: '666',

//     //ifNotExistsReturnNull
//     options: ifNotExistsReturnNull( pivotProps.tileCols.colTileStyle ),

//     color: 'yellow',

//     imgSize: ifNotExistsReturnNull( pivotProps.tileCols.colSize ),

//     listWebURL: '',
//     listTitle: '',

//     target:  'blank',

//     setRatio: pivotProps.images.setRatio,
//     setImgFit: pivotProps.images.setImgFit,
//     setImgCover: pivotProps.images.setImgCover,
//     onHoverZoom: pivotProps.images.onHoverZoom,

//     // imageMaxWidth: null,
//     imageUrl: null,

//     modifiedTime: null,
//     createdTime: null,
//     isNewsLink: false,
//     modifiedByTitle: '',
//     createdByTitle: '',
//     createdNote: '',
//     modifiedNote: '',

//   } as IPivotTileItemProps;

//   // eslint-disable-next-line @typescript-eslint/no-explicit-any
//   const tileAny: any = tile;
//   tileAny.SiteLogoUrl = LoadErrorCategory;
//   tileAny.Title = errTitle;
//   tileAny.Description = errDetails;
//   tileAny.SiteDescription = errDetails;
//   tileAny.TitleDescription = errDetails;
//   tileAny.modified = '';
//   tileAny.created = '';

//   return tile;

// }