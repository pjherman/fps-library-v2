import * as React from 'react';
import { IFPSTileElementExtras, IFPSTileElementProps } from './FPSTile/IFPSTileElementProps';

import { FPSTileElement } from './FPSTile/FpsTileElement';
import { IAnySourceItem } from '../../AnyContent/IAnyContent';

import { checkDeepProperty } from '../../../../logic/Objects/deep';
import { IWebpartBannerProps } from '../../../../banner/mainReact/IWebpartBannerProps';
import { IFPSTileLayout } from '../webPart/IFpsTileComponentWPProps';
import { FpsCompactTile } from './FPSTile/FpsCompactTile';

export interface IFpsTileComponentProps {
  eleExtras?: IFPSTileElementExtras;
  eleProps?: IFPSTileElementProps;
  tiles: IAnySourceItem[];
  header?: JSX.Element; // Optional header
  componentClassName?: string; // ONLY Used if there is a header and this wraps the header and tiles
  refreshId?: string;
  bannerProps?: IWebpartBannerProps;  // Added for potential future updates such as BackGround things
  tilesClassName?: string; // ONLY ACCEPTS class and react
  reactStyles?: React.CSSProperties;
}

require ('@mikezimm/fps-styles/dist/fps-tile-component.css');

export default class FpsTileComponent extends React.Component<IFpsTileComponentProps, {}> {
  private count: number = 0;

  public componentDidUpdate(prevProps: Readonly<IFpsTileComponentProps>, prevState: Readonly<{}>, snapshot?: any): void {
    if ( prevProps.refreshId !== this.props.refreshId ) this.setState({});
  }

  public render(): React.ReactElement<IFpsTileComponentProps> {
    this.count ++;
    const tileLayout: IFPSTileLayout = this.props.eleExtras && this.props.eleExtras.tileLayout ? this.props.eleExtras.tileLayout : 'hover';
    console.log( 'rendering', this.count );
    const propsImageWidth = checkDeepProperty( this.props, `eleProps.Image.css.width`.split('.'), 'EmptyString'  );
    const imageWidth = propsImageWidth ? tileLayout === 'small' || tileLayout === 'med' ? `${Math.max( parseInt(propsImageWidth), 250 )}px` : propsImageWidth : '200px';
    const tiles : JSX.Element[] = this.props.tiles.map( ( newTile: IAnySourceItem ) => {
      const tile = tileLayout === 'hover' ? FPSTileElement( newTile as IAnySourceItem, this.props.eleExtras, this.props.eleProps ) :
      tileLayout === 'small' || tileLayout === 'med' ? FpsCompactTile( newTile as IAnySourceItem, this.props.eleExtras, tileLayout ) : undefined;
      return tile;
    });

    const gridClasses = [ 'tileGrid' ];

    // Add optional className
    if ( this.props.tilesClassName ) gridClasses.push( this.props.tilesClassName );

    // Merge optional reactStyles
    const baseGridWidth: React.CSSProperties = { gridTemplateColumns: `repeat( auto-fill, minmax(${ imageWidth }, 1fr) )` };
    const gridWidth = this.props.reactStyles ? { ...baseGridWidth, ...this.props.reactStyles } : baseGridWidth;

    const tileBuild = <div className={ gridClasses.join(' ') } style={ gridWidth }> { tiles } </div>;

    const thisComponent = !this.props.header ? tileBuild : <div className={ this.props.componentClassName }>
      { this.props.header }
      { tileBuild }
    </div>

    return ( thisComponent );
  }

}
