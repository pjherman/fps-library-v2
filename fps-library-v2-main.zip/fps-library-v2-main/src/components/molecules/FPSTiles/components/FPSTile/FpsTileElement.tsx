
import * as React from 'react';
// import styles from '../FpsTileComponent.module.scss';
import { Image, } from 'office-ui-fabric-react/lib/Image';
import { Icon, } from 'office-ui-fabric-react/lib/Icon';

import { IAnySourceItem, IFPSItem } from '../../../../../components/molecules/AnyContent/IAnyContent';

import { onFPSClick } from '../../functions/onFPSClick';
import { mergeDeep } from '../../functions/mergeDeep';
import { IFPSTileElementProps, IFPSTileElementExtras } from './IFPSTileElementProps';
import { getSrcAndIconBasedOnPriority } from './getImageOrIconPriority';

require ('@mikezimm/fps-styles/dist/fps-h-color.css');

/**
 * If props is passed in ( as in from web part props ), then the item.FPSItem props will be merged into them.
 *    Therefore, any item.FPSItem props will be considered the tie-breaker of both objects have the same keys.
 *
 * This way you can either pre-merge the FPSItem props in the initial data set or merge right here depending on needs.
 *    If you have a lot of items but only show a few need the FPSTileElement, it may not make sense to do up front.
 *
 * @param item
 * @param props
 * @returns
 */
export function FPSTileElement( item: IAnySourceItem, extras?: IFPSTileElementExtras, props?: IFPSTileElementProps ): JSX.Element {

  const titleWrap = extras ? extras.titleWrap : true ;
  const tileHighlightColor = extras ? extras.tileHighlightColor : 'yellow';
  const { content1, content2, content3, content4 } = item.FPSItem.Elements;
  const FPSItem: IFPSItem = props ? mergeDeep( props , item.FPSItem, [ 'Elements' ] ) : item.FPSItem;
  const { css, fabric, } = FPSItem.Image;

  const altClick = FPSItem.Link.altClick ? FPSItem.Link.altClick : null;

  const { src, iconName } = getSrcAndIconBasedOnPriority( FPSItem, extras.tileFileImagePriority );
  const iconColor = FPSItem.Icon && FPSItem.Icon.css ? FPSItem.Icon.css.color : null;

  const { href, title, description } = FPSItem.Link;

  const tileHeight = parseInt(css.height);

  const tallClass = tileHeight >= 250 ? 'tallTile250' : tileHeight >= 200 ? 'tallTile200' : '';
  const tileStyle: React.CSSProperties = { height: css.height }

  if ( css.background ) tileStyle.background = css.background;
  if ( iconName ) tileStyle.textAlign = 'center';
  // if ( iconName ) tileStyle.paddingTop = `16px` ;

  const iconStyle: React.CSSProperties = { fontSize: `calc( ${css.height} - 2em)`, paddingTop: '16px', color: iconColor };

  const ItemOrIcon : JSX.Element =  !src ? <Icon 
    iconName={ iconName }
    style={ iconStyle }
    /> : <Image
      style={ {} }
      className={[ 'reactImage'
      ].join(' ')}
      src={ src }
      shouldFadeIn={true}
      imageFit={ fabric.imgFit }
      coverStyle={ fabric.imgCover }
  />

  const tile = <div className = { [ 'fpsTile', href ? 'fpsPointer' : '' ].join(' ') } style={ tileStyle }
    onClick={ (e) => {
      altClick && e.altKey === true ?
      altClick( e, item ) :
      onFPSClick(e, item)
    }}>

    { content1 }
    { content2 }
    { content3 }
    { content4 }

    { ItemOrIcon }
    <div className={ [ 'textBox', tallClass, 'fps-h'  ].join( ' ' ) }>
      <div className={ [ 'tileTitle', titleWrap === true || !description ? 'fpsPreWrap'  : 'fpsNoWrap' ].join( ' ' ) }>
        { title }
      </div>
      { description ? <div className={ [ 'tileDesc', `fps-h-color-${tileHighlightColor}`].join(' ') } style={ {  } }>
        { description }
      </div> : undefined }
    </div>
  </div>;
  return tile;
}
