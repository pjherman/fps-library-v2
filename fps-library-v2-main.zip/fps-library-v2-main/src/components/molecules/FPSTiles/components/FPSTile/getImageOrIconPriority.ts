import { IAnySourceItem, IFPSItem } from "../../../AnyContent/IAnyContent";
import { IFPSFileImagePriority } from "../../webPart/IFpsTileComponentWPProps";

export interface ISrcOrIcon {
  src: string;
  iconName: string;
}

/**
 * getSrcAndIconBasedOnPriority
 * @param FPSItem 
 * @param tileFileImagePriority 
 * @returns 
 */
export function getSrcAndIconBasedOnPriority( FPSItem: IFPSItem, tileFileImagePriority?: IFPSFileImagePriority ) : ISrcOrIcon {

  let iconName = ``;
  let src = ``;
  let useTileFileImagePriority: IFPSFileImagePriority = `${ tileFileImagePriority }`;

  /**
   *  General default logic for files should be:
   *  If it's in SitePages library, then use Image.src
   *  If it's a file in another library, then use Icon.name
   */

  // Added if then so that if the web part properties say use a specific way, it will totally skip this.
  if ( !useTileFileImagePriority || useTileFileImagePriority === 'code' ) {
    if ( ( FPSItem.IsA.FileObject !== true || FPSItem.IsA.Page === true  || FPSItem.IsA.News === true ) ) {
      useTileFileImagePriority = 'default';

    } else if ( FPSItem.Link.href && FPSItem.Link.href.toLowerCase().indexOf('/sitepages/' ) > -1 ) { useTileFileImagePriority = 'default'; }
  }

  if ( useTileFileImagePriority === 'icon' ) {
    // Set to Icon Name if it's available.  Then if there isn't an iconName value, set src to the original src
    iconName = FPSItem.Icon && FPSItem.Icon.name ? `${FPSItem.Icon.name}` : '' ;
    src = !iconName ? `${ FPSItem.Image.src }` : '';

  } else if ( useTileFileImagePriority === 'preview' || useTileFileImagePriority === 'default' ) {
    // Replace src in this loop with FPSItem.Image.src.... https://github.com/fps-solutions/HubCon/issues/20
    // image src is available, use it.. else if there is an icon, use it.
    src = FPSItem.Image.src ? FPSItem.Image.src : '';
    iconName = !src && FPSItem.Icon ? `${FPSItem.Icon.name}` : '' ;

  }

  return { src: src, iconName: iconName };

}