import { IFPSItemIcon, IFPSItemImage, IFPSItemLink } from '../../../../molecules/AnyContent/IAnyContent';
import { IFPSFileImagePriority, IFPSTileLayout } from '../../webPart/IFpsTileComponentWPProps';

export interface IFPSTileElementProps {
  Image: IFPSItemImage;
  Link: IFPSItemLink;
  Icon: IFPSItemIcon;
}

export interface IFPSItemContent {
  content1?: JSX.Element;  // In PivotTiles:  Top Left Views / pubDate
  content2?: JSX.Element;  // In PivotTiles:  Top Right highlights
  content3?: JSX.Element;  // In PivotTiles:  Bottom Left itemBar
  content4?: JSX.Element;  // In PivotTiles:  Bottom Right have not used
}

// Subset of IFpsTileComponentWPProps used to define properties of the Tile Element
export interface IFPSTileElementExtras {
  titleWrap?: boolean;
  tileHighlightColor?: string;
  tileLayout?: IFPSTileLayout;
  tileFileImagePriority?: IFPSFileImagePriority;
}