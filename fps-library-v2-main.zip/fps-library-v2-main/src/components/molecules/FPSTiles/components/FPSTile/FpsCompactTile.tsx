
import * as React from 'react';
// import styles from '../FpsTileComponent.module.scss';
import { Image, } from 'office-ui-fabric-react/lib/Image';
import { Icon, } from 'office-ui-fabric-react/lib/Icon';
import { IAnySourceItem } from '../../../AnyContent/IAnyContent';
import { onFPSClick } from '../../functions/onFPSClick';
import { IFPSCompactTileSize } from '../../webPart/IFpsTileComponentWPProps';
import { IFPSTileElementExtras } from './IFPSTileElementProps';
import { getSrcAndIconBasedOnPriority } from './getImageOrIconPriority';

require ( '@mikezimm/fps-styles/dist/fps-compact-tile.css' );

/**
 * FpsCompactTile is a compact version of tile, like QuickLinks compact layout
 * @param item 
 * @param size 'small' or 'med'.  'small' does not show description
 * @param farContent  is additional content that goes on far right.  Can be used for adding highlight things
 * @returns 
 */

export function FpsCompactTile( item: IAnySourceItem, extras: IFPSTileElementExtras, size: IFPSCompactTileSize = 'med', farContent?: JSX.Element ): JSX.Element {
  const { FPSItem } = item;
  const { tileFileImagePriority } = extras;
  const { fabric, } = FPSItem.Image;

  const { src, iconName } = getSrcAndIconBasedOnPriority( FPSItem, tileFileImagePriority );
  const iconColor = FPSItem.Icon && FPSItem.Icon.css ? FPSItem.Icon.css.color : null;

  const { href, title, description } = FPSItem.Link;

  const altClick = FPSItem.Link.altClick ? FPSItem.Link.altClick : null;

  const imageIsDefault = src && src.indexOf('_layouts/15/images/sitepagethumbnail.png') > -1 ? true : false;

  // If there is not a src based on the above logic, then go with Icon.
  // Above logic should look at priority from web part props and show Icon if that's priority and the icon is available.
  const ItemOrIcon : JSX.Element = !src ? <Icon 
    className={ [ 'fps-compact-icon' ].join(' ') }
    iconName={ iconName }
    style={ { color: iconColor } }
    /> : <Image
      style={{ height: imageIsDefault === true ? '20px' : '50px' }}
      className={[ 'fps-compact-tile-image'
      ].join(' ')}
      src={ src }
      shouldFadeIn={true}
      imageFit={ fabric.imgFit }
      coverStyle={ fabric.imgCover }
      title={ description }
  />
  const newClass = [ 'fps-compact-tile' ];

  const showAsSize: IFPSCompactTileSize = size === 'small' || !description ? 'small' : 'med';
  
  // Added !description to force compact so that Title is more vertically centered.
  // Unfortunately this only applies when all tiles in the row do not have a description.
  // If one has a description, then all are treated as being taller
  // if ( size === 'small' )
  if ( showAsSize === 'small' ) newClass.push( 'is-small-compact' );
  if ( farContent ) newClass.push( 'hasFarContent' );

  const isCurrent = window.location.pathname.toLocaleLowerCase().indexOf( href?.replace(window.location.origin, '').toLocaleLowerCase()  )  > -1 ? true : false;
  const titleStyle: React.CSSProperties = { fontSize: title ? '' : 'smaller', fontWeight: title ? '' : 400 };
  const titleClass: string[] = [ 'fps-compact-tile-title', 'text-ellipse' ];

  // https://github.com/mikezimm/drilldown7/issues/264
  if ( isCurrent === true ) titleClass.push( 'fps-compact-tile-current-title' );

  const currentPageIcon = isCurrent !== true ? null : <span title='You are currently on this site' style={{ }}><Icon iconName='SkypeCheck' /></span>;
  const medium: JSX.Element = <div className = { newClass.join( ' ' ) } 
    onClick={ (e) => {
      altClick && e.altKey === true ?
      altClick( e, item ) :
      onFPSClick(e, item)
    }}>

    { ItemOrIcon }
    <div className={ titleClass.join(' ') } style={ titleStyle } title={  href }>
        { currentPageIcon } { title }</div>
    { farContent ? <div className={ 'fps-tile-far-content' } >{ farContent }</div> : undefined }
    {/* previously did not have this part:  showAsSize === 'med' ? */}
    { showAsSize === 'med' ? <div className={ size === 'med' ? 'fps-compact-tile-desc text-ellipse' : 'text-hidden' } >{ description }</div> : undefined }
  </div>;

  return medium;
}
