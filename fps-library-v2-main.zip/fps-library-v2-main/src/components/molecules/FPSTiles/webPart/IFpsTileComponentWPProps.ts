import { IImageFit, IImageCover, } from '../../../../common/Images/imgFit';

export const changesFpsTileComp : string[] = [ 'tileLayout', 'tileImgWidth', 'tileImgHeight' , 'tileImgCover' , 
  'tileImgFit' , 'tileImgBackground', 'tileTitleWrap', 'tileHighlightColor', 'tileFileImagePriority' ];

/**
 * Sample usage of PreConfigProps
 * 
 export const WPPresetEverywhere : IPreConfigSettings = {
    source: 'WPPresetEverywhere',
    location: '*',
    props: { ...PreConfigFpsTileCompProps, ...{
        bannerTitle: "FPS Hub Connections",
        defPinState: 'disabled',
    }},
  };

*/
export const PreConfigFpsTileCompProps: IFpsTileComponentWPProps = {
  tileImgWidth: 200,
  tileImgHeight: 125,
  tileImgCover: 'landscape',
  tileImgFit: 'centerContain',
  tileImgBackground: "lightgray",
  tileTitleWrap: false,
  tileHighlightColor: "yellow",
  tileLayout: 'hover',
  tileFileImagePriority: 'icon',
}

// This can be used for toggling layout
export const FPSTileLayoutValues: IFPSTileLayout[] = [ 'small', 'med', 'hover', 'card'];

export type IFPSCompactTileSize = 'small' | 'med';
export type IFPSTileLayout = 'small' | 'med' | 'hover' | 'card';  // 'small' and 'med' must match IFPSCompactTileSize
export type IFPSFileImagePriority = 'icon' | 'preview' | 'default' | 'code' ;

// This can be used for toggling layout
export const FPSFileImagePriorityValues: IFPSFileImagePriority[] = [ 'icon', 'preview', 'default', 'code' ];

// These WPProps are used for FPSTile component
export interface IFpsTileComponentWPProps {
  tileImgWidth: number;
  tileImgHeight: number;
  tileImgCover: IImageCover;
  tileImgFit: IImageFit;
  tileImgBackground: string;
  tileTitleWrap: boolean;
  tileHighlightColor: string;
  tileLayout: IFPSTileLayout;
  tileFileImagePriority: IFPSFileImagePriority;
}

