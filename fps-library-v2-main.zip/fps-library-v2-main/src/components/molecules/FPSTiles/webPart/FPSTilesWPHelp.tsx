import * as React from 'react';
import { Icon } from 'office-ui-fabric-react/lib/Icon';
// import ReactJson from "react-json-view";
import {  PivotItem, } from 'office-ui-fabric-react/lib/Pivot';

/**
 * FPS Slick Sections Notes:
 * 
 * ForceWhite does NOT work on collapsible sections.... might at first but if you collapse then expand, no go because web part does not re-apply the classes to the web parts.
 * @returns 
 */
// White text refresh label
export const LinkStyles: React.CSSProperties = { padding: '8px 15px', marginBottom: '12px', color: 'darkblue', cursor: 'pointer' };

export function getFPSTileWPHelp ( ): JSX.Element {

  const WebPartHelpElement = <PivotItem headerText={ 'Tile Styles' } itemIcon='PictureFill' > 
    <div className={ 'fps-pph-content' }>

      <div className={ 'fps-pph-topic' }>Tile Layout - Small, Medium, Hover Tile, Card</div>
      <div>This determines the overall size/type of icon.</div>
      <div>Small and Medium have simple Logo or Image</div>
      <div>Small has smaller Logo and only displays the site Title - based on the source object like Site Title</div>
      <div>Medium has slightly larger logo but also includes the Description - based on the source object like Site Description</div>
      <div>Hover Tile will give a larger customizable size Tile with hover overlay.</div>
      <div>Hover Tile shows the Image and Title, when hovering, the description will be displayed</div>
      <div><b>Card is not working as of the writing of this documentation.</b></div>

      <div className={ 'fps-pph-topic' }>Image Height and Width</div>
      <div>Only applies when you select Hover Tile or possibly Card Tile Layouts</div>
      <div>Use the sliders to adjust the default Height and Width of the Tile.</div>


      <div className={ 'fps-pph-topic' }>Image Fit - CenterCover, CenterContain, Center, Contain etc...</div>
      <div>Do not adjust from the defaults unless you know CSS and want to experiment.</div>
      <div>This leverages CSS Image Fit property and can impage how Image Cover works.</div>
      <div>Feel free to experiment but be warned it can impact other CSS properties like Image Cover.</div>

      <div className={ 'fps-pph-topic' }>Image Cover</div>
      <div>Be sure to use Image Fit = CenterCover for this to work properly.</div>

      <div className={ 'fps-pph-topic' }>Image Background color</div>
      <div>Set the default tile/image background color for cases where</div>
      <ul>
        <li>Your Images have transparancy</li>
        <li>Your Image Fit/Image Conver does not fully cover the entire tile</li>
      </ul>
      
      <div className={ 'fps-pph-topic' }>Tile Title Wrap</div>
      <div>Determines how to handle long title.  May also impact the Description behaviour.</div>
      <div>Only impacts Hover Tile and Card layout.</div>

      <div className={ 'fps-pph-topic' }>Highlighted color</div>
      <div>Used in Hover Tile layout only.</div>
      <div>Default highlights the Description text in yellow which makes it easier to read on the dark hover card.</div>

      <div className={ 'fps-pph-topic' }>File Image Priority</div>
      <div>Depending on the web part you are using, this provides flexibility to force web part to use certain properties for the Tile image</div>
      <div>Suggest to just use web part Default, particularly for a web part that uses Sites or Pages since those typically have thumbnail properties from the object - like Site Logo or Page Thumbnail.</div>
      <div><b>Icon</b> will first look for an actual icon - such as file type icon like Excel or PowerPoint which is easier to recognize in small or medium tiles.</div>
      <div><b>Preview Image</b> will first look if the item has a preview image - such as a Power Point might show the first slide.</div>
    </div>
  </PivotItem>;

  return WebPartHelpElement;

}