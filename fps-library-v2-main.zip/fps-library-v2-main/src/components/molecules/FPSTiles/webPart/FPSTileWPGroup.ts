import {
   IPropertyPaneGroup,
  PropertyPaneDropdown, IPropertyPaneDropdownProps,
  IPropertyPaneField, PropertyPaneTextField, PropertyPaneSlider, PropertyPaneToggle,
  PropertyPaneLabel, IPropertyPaneLabelProps
} from '@microsoft/sp-property-pane';

import { imgFitChoices, imgCoverChoices, } from '../../../../common/Images/imgFit';
import {  } from '../../../../common/Images/hoverZoom';

export const highlightColorChoices = [
  { index: 0, key: 'yellow', text: "Yellow" },
  { index: 1, key: 'white', text: "White" },
  { index: 1, key: 'lightblue', text: "Light Blue" },
  { index: 1, key: 'lime', text: "Lime" },
  { index: 1, key: 'orange', text: "Orange" },
  { index: 1, key: 'pink', text: "Pink" },
  { index: 1, key: 'coral', text: "Coral" },
  { index: 1, key: 'lightgray', text: "Light Gray" },
];

// Should match:  IFPSTileLayout = 'small' | 'med' | 'hover' | 'card'
export const fpsTileLayoutChoices = [
  { index: 0, key: 'small', text: "Small" },
  { index: 1, key: 'med', text: "Medium" },
  { index: 1, key: 'hover', text: "Hover Tile" },
  { index: 1, key: 'card', text: "Card" },

];

// Should match:  IFPSFileImagePriority = 'icon' | 'preview' | 'default' ;
export const fpsTileFileImagePriorityChoices = [
  { index: 0, key: 'icon', text: "Icon" },
  { index: 1, key: 'preview', text: "Preview Image" },
  { index: 1, key: 'default', text: "Default" },
  { index: 1, key: 'code', text: "Predetermined Logic" },
];

// This constant can be reused in case of using 'Simple' mode instead of entire prop pane group.
export const FPSTileLayoutChoiceProperty: IPropertyPaneField<any> = PropertyPaneDropdown('tileLayout', <IPropertyPaneDropdownProps>{
  label: `Tile Layout`,
  description: `Default Tile layout.  You can toggle layouts live in webpart but this is the default when page loads.`,
  options: fpsTileLayoutChoices,
});

export function FPSTileWPGroup( ): IPropertyPaneGroup {

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const groupFields: IPropertyPaneField<any>[] = [];

  groupFields.push( FPSTileLayoutChoiceProperty );

  groupFields.push(
    PropertyPaneSlider('tileImgHeight', { //hidePageHeader, allSectionMaxWidthEnable, allSectionMaxWidth, allSectionMarginEnable, allSectionMargin
      label: 'Image Height (pixels)',
      min: 100,
      max: 400,
      step: 25,
    }));

  groupFields.push(
    PropertyPaneSlider('tileImgWidth', { //hidePageHeader, allSectionMaxWidthEnable, allSectionMaxWidth, allSectionMarginEnable, allSectionMargin
      label: 'Image width (pixels)',
      min: 100,
      max: 500,
      step: 25,
    }));

    /**
     * 
     * 
     * NOTE WITH tileImgFit and tileImgCover...
     *  per https://github.com/fps-solutions/HubCon/issues/11
     *  It seems like timeImgFit should be CenterCover for the tileImgCover to work as expected.
     * 
     * 
     */
  groupFields.push(
    PropertyPaneDropdown('tileImgFit', <IPropertyPaneDropdownProps>{
      label: `Image Fit`,
      options: imgFitChoices,
    }));

  // https://github.com/fps-solutions/HubCon/issues/11
  groupFields.push(
    PropertyPaneLabel('tileImgCover', <IPropertyPaneLabelProps>{
      text: `Set Image Fit to 'CenterCover' for Image Cover setting to work properly.`,
    }));

  groupFields.push(
    PropertyPaneDropdown('tileImgCover', <IPropertyPaneDropdownProps>{
      label: `Image Cover`,
      options: imgCoverChoices,
    }));

  // https://github.com/mikezimm/pivottiles7/issues/306
  groupFields.push(
    PropertyPaneTextField('tileImgBackground', {
      label: `Image Background color`,
      description: `'theme ; yellow' will set imageBackgrounds to theme and Icon backgrounds to yellow`,
      // disabled: wpProps.ignoreList === true ? true : false,
    }));

  // https://github.com/mikezimm/pivottiles7/issues/306
  groupFields.push(
    PropertyPaneToggle('tileTitleWrap', {
      label: `Tile Title wrap`,
      onText: `pre-wrap`,
      offText: `no-wrap`,
      // disabled: wpProps.ignoreList === true ? true : false,
    }));

  // https://github.com/mikezimm/pivottiles7/issues/306  tileHighlightColor
  groupFields.push(
    PropertyPaneDropdown('tileHighlightColor', <IPropertyPaneDropdownProps>{
      label: `Highlighted color`,
      description: `Any html color code.  'yellow' will set the Tile Description text to be yellow and more readable.`,
      options: highlightColorChoices,
    }));

    
  groupFields.push(
    PropertyPaneDropdown('tileFileImagePriority', <IPropertyPaneDropdownProps>{
      label: `File Image Priority`,
      options: fpsTileFileImagePriorityChoices,
    }));

  const ExportThisGroup: IPropertyPaneGroup = {
    groupName: `Tile styles`,
    isCollapsed: false,
    groupFields: groupFields
  };

  return ExportThisGroup;

}
