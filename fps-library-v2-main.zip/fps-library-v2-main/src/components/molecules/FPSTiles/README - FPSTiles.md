
# Just some notes on usage of this component

# In MAIN WP PROPS FILE:
```typescript
  import { IFpsTileComponentWPProps, changesFpsTileComp } from '@mikezimm/fps-library-v2/lib/components/molecules/FPSTiles/webPart/IFpsTileComponentWPProps';

  // Add to changes object
  export const WebPartAnalyticsChanges : any = {
    fpsTile: changesFpsTileComp,
  }

  // Extend main web part Interface
  export interface IHubConnectionsWebPartProps extends IMinWPBannerProps, IFpsTileComponentWPProps {
  }
```

# In MAIN WP CLASS
```typescript
// Imports required:
import { FPSTileWPGroup } from "@mikezimm/fps-library-v2/lib/components/molecules/FPSTiles/webPart/FPSTileWPGroup";
import { buildFpsTileWPProps } from "@mikezimm/fps-library-v2/lib/components/molecules/FPSTiles/functions/packageFPSTileProps";

protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
  // ... Add to Property Pane
  groups = [ ...groups, FPSTileWPGroup(), ...FPSGroups, ];
```

## build default FPSItem in public render based on Prop Pane Props
```typescript
 public async render(): Promise<void> {
  // ...
    const FPSItem: IFPSItem = buildFpsTileWPProps( this.properties );
 }
```

## Pass down props as needed to main react component... NOT CURRENTLY AUTOMATIC
```typescript

 public async render(): Promise<void> {
  // ...
  const element: React.ReactElement
    // ...
    FPSItem: FPSItem,
    eleProps: {
      // Only updating width because it is needed to auto-refresh the tile width on props change
      Image: { src: ``, css: { width: `${this.properties.tileImgWidth}px` }},
      Link: { href: '' },
      Icon: { name: '' },
    },
    eleExtras: {
      titleWrap: this.properties.tileTitleWrap,
      tileHighlightColor: this.properties.tileHighlightColor,
      tileLayout: this.properties.tileLayout,
      tileFileImagePriority: this.properties.tileFileImagePriority,
    }
 }
```

## REACT COMPONENT usage

```typescript
// Imports
import FpsTileComponent from '@mikezimm/fps-library-v2/lib/components/molecules/FPSTiles/components/FpsTileComponent';
import { FpsCompactTile } from '@mikezimm/fps-library-v2/lib/components/molecules/FPSTiles/components/FPSTile/FpsCompactTile';
import { getFPSTileWPHelp } from '@mikezimm/fps-library-v2/lib/components/molecules/FPSTiles/webPart/FPSTilesWPHelp';
src\components\molecules\FPSTiles\webPart\FPSTilesWPHelp.tsx
// Add Prop Pane Help to react component:
  private _webPartHelpElement = [
    getFPSTileWPHelp( ),
  ];


// Usage of a single FpsCompactTile - small or medium version
  const SiteHeaderElement: JSX.Element = <div style={ headerStyles }>
    { FpsCompactTile( site,  this.props.eleExtras, 'small', site.FPSItem.Elements.content4 ) }
  </div>;

//  Usage of component FpsTileComponent
//  Sample from Hub Connections web part
  HubHiearchy.push( <FpsTileComponent
    reactStyles={ HubConMargins }
    componentClassName={ undefined }
    tilesClassName={ undefined }
    header={ SiteHeaderElement }
    // reactStyles={ { background: 'yellow' } }
    tiles={ SubSites }
    refreshId={ this.state.refreshId }
    // Have to add eleProps in to get width because it is not on the item level but on the tiles component level via grid width
    eleProps= { this.props.eleProps }
    eleExtras={ this.props.eleExtras }
  />);

```