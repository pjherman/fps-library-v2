import { IPerformanceSettings } from "../../Performance/IPerformanceSettings";

export const HTTPApiPerformanceSettings: IPerformanceSettings = {
  label: `HTTPApiHook`,
  updateMiliseconds: true,
  editMode: null,
  includeMsStr: true,
};
