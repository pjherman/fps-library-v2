
import { HttpClient, HttpClientResponse } from '@microsoft/sp-http';  // , httpClient: HttpClient
import { IHttpClientOptions } from '@microsoft/sp-http';
import { IFpsErrorObject } from '../../../../pnpjs/Common/IFpsErrorObject';
import { IFPSResultStatus } from '@mikezimm/fps-pnp2/lib/services/sp/IFPSResultStatus';

import { startPerformOpV2, updatePerformanceEndV2 } from "../../../molecules/Performance/functions";
import { IPerformanceSettings } from "../../../molecules/Performance/IPerformanceSettings";
import { check4Gulp } from '@mikezimm/fps-pnp2/lib/services/sp/CheckGulping';
import { check4This } from '@mikezimm/fps-pnp2/lib/services/sp/CheckSearch';
import { IBlankErrorObj } from '../../../../pnpjs/Common/IFpsErrorObject';
import { IPerformanceOp } from '../../Performance/IPerformance';
// import { IHelpfullInput, IHelpfullOutput } from '../../../../logic/Errors/friendly';
// import { IPerformanceOp } from '../../Performance/IPerformance';


export interface IFpsHttpInfo extends IFpsErrorObject, IBlankErrorObj {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  value: any;
  items: any[];
  item: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  text?: string;
  type?: ResponseType;
  url?: string;
  statusNo?: number;
  ok?: boolean;
  statusText?: string;
  headers?: Headers;
  bodyUsed?: boolean;

  // errorInfo?: IHelpfullOutput;
  // errorInput?: IHelpfullInput; // Used for logging
  // fetchOp?: IPerformanceOp;
  // loaded?: boolean;

}

export async function fetchAPI ( apiEndPoint: string, httpClient: HttpClient, description: string, performanceSettings: IPerformanceSettings, headers?: IHttpClientOptions ): Promise<IFpsHttpInfo>  {

  // Validate approved location
  // const websLocation = this.approvedWebs.filter(loc => loc.key == web)[0];
  // const websQuery = window.location.origin + websLocation.siteRelativeURL + "/_api/Web/Lists?$filter=BaseTemplate eq 101 and Hidden eq false&select=Title";

  const fetchOp = performanceSettings ? startPerformOpV2( performanceSettings ) : null;

  try {
    // const response = await httpClient.get(apiEndPoint, HttpClient.configurations.v1, headers ? headers : undefined );

    const response = await httpClient.get(apiEndPoint, HttpClient.configurations.v1, headers );

    if ( check4This( 'fpsHttpResponse=true' ) === true ) {
      console.log(`fpsHttpResponse=true API Response data_1 ~ 52: ${description} response`, response );
    }

    const result : IFpsHttpInfo = await createFPSHttpResponse( description, response );
    
    result.unifiedPerformanceOps.fetch = performanceSettings ?
      updatePerformanceEndV2( { op: fetchOp, updateMiliseconds: performanceSettings.updateMiliseconds, count: result.value ? result.value.length : -1 })  : null;

    result.fetchOp = result.unifiedPerformanceOps.fetch;

    return result;

  } catch(e) {
    const fetchX: IPerformanceOp = performanceSettings ?
      updatePerformanceEndV2( { op: fetchOp, updateMiliseconds: performanceSettings.updateMiliseconds, count: -1 })  : null;

    const result : IFpsHttpInfo = { 
      value: null, e: e, status: 'Error', statusText: e.message,
      items: [],
      item: null,
      errorInfo: {
        errObj: e,
        friendly: e.message,
        result: null,
        returnMess: e.message,
      },
      errorInput: null, // Used for logging
      fetchOp: fetchX,
      unifiedPerformanceOps: { fetch: fetchX },
      loaded: false,
    };

    return result;

  }


}

export async function createFPSHttpResponse( description: string, response: HttpClientResponse ): Promise<IFpsHttpInfo> {

  const results: IFpsHttpInfo = { value: null, e: null, status: 'Error', items: [], item: null, unifiedPerformanceOps: {} };
  results.statusNo = response ? response.status : null;
  results.statusText = response ? response.statusText : null;
  results.ok = response ? response.ok : false;
  results.url = response ? response.url : null;
  results.type = response ? response.type : null;
  results.bodyUsed = response ? response.bodyUsed : null;
  results.headers = response ? response.headers : null;

  results.status = response ? response.status === 200 ? 'Success' : response.statusText as IFPSResultStatus : 'Error';

  const data_1 = response ? await response.json() : null;

  if ( check4This( 'fpsHttpResponse=true' ) === true ) {
    console.log(`createFPSHttpResponse data_1 ~ 103: ${description} results`, results );
    console.log(`createFPSHttpResponse data_1 ~ 104: ${description} data_1`, data_1 );
    console.log(`createFPSHttpResponse data_1 ~ 105: ${description} data_1.value`, data_1 ? data_1.value : undefined );
  }

  results.value = data_1 && data_1.value ? data_1.value : data_1 ? data_1 : [];

  // Assume results are always an array
  results.items = results.value;

  // Added for https://github.com/mikezimm/Compliance/issues/62
  results.errorInfo = {
    errObj: null,
    friendly: '',
    result: null,
    returnMess: '',
  }

  // if ( check4Gulp() ===  true ) console.log(`API JSON response ~ 108: ${description}`, response ? response: results );
  if ( check4This( 'fpsHttpResponse=true' ) === true ) console.log(`API JSON response ~ 111: ${description}`, response ? response: results );

  return results;

}