
import { IWebpartBannerProps } from '../../../../banner/mainReact/IWebpartBannerProps';
import { IGrouping } from '../../../../common/interfaces/openSource/spfxControlsReact/@3.7.2/IViewField';
import { IUser } from '../../../../logic/Users/IUserInterfaces';
// import { IUser } from '../../../../pnpjs';
import { IDrillItemInfo } from '../../../interfaces/Drilldown/IDrillItem';
import { IPageArrowsParentProps } from '../../Arrows/PageArrows';
import { IQuickCommandsDesign } from '../../FieldPanel/components/command/IAccordion';
import { IViewFieldDD } from '../interfaces/IViewFieldDD';

export interface IReactListItemsProps extends IPageArrowsParentProps {
  title?: string;
  themeClass: string;
  descending?: boolean;
  maxChars?: number;
  items: IDrillItemInfo[];
  richColumns: string[];

  richHeights: number[];  //=>> maxHeight: 55em ; address:  https://github.com/mikezimm/drilldown7/issues/270
  autoRichHeight: string;  //=>> maxQty;maxHeight ; address:  https://github.com/mikezimm/drilldown7/issues/271
  richMarginAuto: boolean; // https://github.com/mikezimm/drilldown7/issues/346
  
  updateRichHeightProps: any;

  resetArrows?: string; //unique Id used to reset arrows to starting position

  webUrl: string; //Used for attachments
  listTitle: string; //Used for attachments
  listUrl: string;
  isLibrary: boolean;

  // Deprecated this in favor of bannerProps so I get other info.  Searched fps-library-v2 and drilldown and do not see this used anywhere.
  // contextUserInfo: IUser; //For site you are on ( aka current page context )
  bannerProps: IWebpartBannerProps;  // Added for getting context props and themes

  sourceUserInfo: IUser; //For site where the list is stored

  blueBar?: any;
  blueBarTitleText?: string;

  showIDs?: boolean;
  showDesc?: boolean;

  // parentListFieldTitles?: string;  2022-12-22:  Does not seem to be used anywhere
  viewFields?: IViewFieldDD[];

  groupByFields?: IGrouping[];
  includeDetails: boolean;
  includeAttach: boolean;
  includeListLink: boolean;
  createItemLink: boolean;

  // Added for custom links:  https://github.com/mikezimm/drilldown7/issues/347
  listNewForm: string;
  listViewForm: string;
  itemLinkSource: string;

  highlightedFields?: string[];

  quickCommands?: IQuickCommandsDesign;

}
