import * as React from 'react';
import { Icon, IIconProps  } from 'office-ui-fabric-react/lib/Icon';

import ReactJson from "react-json-view";

// import { mergeStyles } from 'office-ui-fabric-react/lib/Styling';
import { Stack, IStackTokens } from 'office-ui-fabric-react/lib/Stack';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';

import { NoCommandsInfo } from './noCommandsInfo';
import { IDrillItemInfo } from '../../../interfaces/Drilldown/IDrillItem';
import { getHelpfullError } from '../../../../logic/Errors/friendly';
import { IQuickCommandsDesign } from '../../FieldPanel/components/command/IAccordion';
import { IUser } from '../../../../logic/Users/IUserInterfaces';
import { IQuickButton } from '../../../interfaces/QuickCommands/IQuickCommands';
import { defaultBannerCommandStyles } from '../../../../common/commandStyles/defaults';

/**
 * 
 * @param quickCommands 
 * @param item 
 * @param sourceUserInfo  //This is just passed in in order to allow for user targeted b.showWhenEvalTrue checks
 */
export function createPanelButtonsV2 ( quickCommands: IQuickCommandsDesign, item: IDrillItemInfo , sourceUserInfo: IUser, _panelButtonClicked: any, delim: string, showCommandCode: boolean ) {

    let allButtonRows : any[] = [];

    //Adjusted per:  https://github.com/mikezimm/drilldown7/issues/211
    if ( !quickCommands || !quickCommands.buttons || quickCommands.buttons.length === 0 ) { 
        return NoCommandsInfo;

    } else {

        let buildAllButtonsTest = true;
        if ( quickCommands.showWhenEvalTrue && quickCommands.showWhenEvalTrue.length > 0 ) {

            //2022-01-18:  Added Try catch when testing and found my typed in quick command had error.
            try {
                buildAllButtonsTest = eval( quickCommands.showWhenEvalTrue );

                if ( buildAllButtonsTest === true ) {
                    //build all the buttons ( subject to individual button checks )
                } else { buildAllButtonsTest = false; }
            } catch (e) {
                buildAllButtonsTest = false;
                let errMessage = getHelpfullError(e, false, false);
                console.log(`ERROR:  createPanelButtons: quickCommands.showWhenEvalTrue !!!`, quickCommands.showWhenEvalTrue);
                console.log(`ERROR:  createPanelButtons: quickCommands.showWhenEvalTrue Error Details`, errMessage);

                alert(`createPanelButtons: quickCommands.showWhenEvalTrue error !!! Check the console for details:   ${quickCommands.showWhenEvalTrue}`);
            }

        }

        if ( buildAllButtonsTest === true ) {
            quickCommands.buttons.map( (buttonRow, r) => {

                if ( buttonRow && buttonRow.length > 0 ) {
                  let rowResult : any = null;
                  let rowCode: JSX.Element[] = [];
                  const buttons : any[] = [];

                    buttonRow.map( (b: IQuickButton,i: number) => {

                        let buildThisButton = true;

                        /**
                         * showWhenEvalTrue must be run in the context of this section of code to be valid.
                         */

                        if ( b.showWhenEvalTrue && b.showWhenEvalTrue.length > 0 ) {

                            //2022-01-18:  Added Try catch when testing and found my typed in quick command had error.
                            try {
                              const buildButtonTest = eval( b.showWhenEvalTrue );
                                if ( buildButtonTest === true ) {
                                    //build all the buttons
                                } else { buildThisButton = false; }
                            } catch (e) {
                              const errMessage = getHelpfullError(e, false, false);
                                console.log(`createPanelButtons: b[${i}].showWhenEvalTrue error !!!`, b.showWhenEvalTrue);
                                console.log(`createPanelButtons: b[${i}].showWhenEvalTrue Error Details`, errMessage);

                                alert(`createPanelButtons: quickCommands.showWhenEvalTrue error !!! Check the console for details:   ${quickCommands.showWhenEvalTrue}`);
                            }

                        }

                        if ( buildThisButton === true ) {

                          let buttonStyles: React.CSSProperties = b.styleButton ? b.styleButton as React.CSSProperties :  { minWidth: buttonRow.length === 1 ? '350px' : '', padding: '25px', marginBottom: '10px', fontSize: 'larger' };

                          //Tried adding 
                          // const IconElement = b.icon ? <Icon iconName= { 'Emoji2' } style={ defaultBannerCommandStyles }/> : undefined;
                          const buttonID = ['ButtonID', r, i , item.Id].join(delim);
                          const buttonTitle = b.label;
                          // const iconName: string = b.icon;
                          // https://github.com/mikezimm/drilldown7/issues/219
                          const buttonIcon : IIconProps = b.icon ? { iconName: b.icon, style: { fontSize: 'xx-large', marginRight: '15px' } } : undefined;
                          let thisButton = b.primary === true ?

                            //Tried adding  iconName into Primary Button, does not work,
                            //Tried adding IconElement into icon Props, can't see it.
                            //Tried adding Icon Element into the div next to Primary button and could see it.
                            //
                                <div id={ buttonID } title={ buttonTitle } >
                                  <PrimaryButton style= { buttonStyles } iconProps= { buttonIcon } text={b.label} onClick={ ( event ) => _panelButtonClicked( b, item, event ) } disabled={b.disabled} checked={b.checked} /></div>:

                                <div id={ buttonID } title={ buttonTitle } >
                                  <DefaultButton style= { buttonStyles } iconProps= { buttonIcon } text={b.label} onClick={ ( event ) => _panelButtonClicked( b, item, event ) } disabled={b.disabled} checked={b.checked} /></div>;

                            let dividerIcon = undefined;
                            // https://github.com/mikezimm/drilldown7/issues/237
                            if ( b.icon && ( b.type === 'divider' || b.type === 'label-only' ) ) {
                              dividerIcon = <Icon iconName={ b.icon } styles={{ root: { fontSize: 'xx-large', marginRight: '15px' }}} />
                            }

                            if ( b.type === 'divider' ) {
                              buttonStyles = b.styleButton ? b.styleButton as React.CSSProperties :  { width: '100%', textAlign: 'center', padding: !buttonTitle ? '15px' : '1px', margin: '15px 0px 10px 0px', background: 'lightgray' }
                              thisButton = !buttonTitle ?
                                <div style= { buttonStyles } onClick={ ( event ) => _panelButtonClicked( b, item, event ) } >{ dividerIcon }</div> :
                                <div style= { buttonStyles } onClick={ ( event ) => _panelButtonClicked( b, item, event ) } ><h3>{ dividerIcon }{ buttonTitle }</h3></div>;

                            } else if ( b.type === 'label-only' ) {
                              buttonStyles = b.styleButton ? buttonStyles as React.CSSProperties :  null;
                              thisButton = <h3 style= { buttonStyles } onClick={ ( event ) => _panelButtonClicked( b, item, event ) } >{ dividerIcon } { buttonTitle }</h3>;
                            }

                            buttons.push( thisButton );
                        }

                        // https://github.com/mikezimm/drilldown7/issues/252
                        if ( showCommandCode === true ) {
                          rowCode.push( <ReactJson src={ b } name={ b.label ? b.label : 'Button JSON' } collapsed={ true } displayDataTypes={ true } displayObjectSize={ true } enableClipboard={ true } style={{ padding: '10px 0px' }}/> )
                        }

                    }); //END buttonRow.map( (b,i) => {

                    const stackQuickCommands: IStackTokens = { childrenGap: 10 };
                    rowResult = <Stack horizontal={ true } tokens={stackQuickCommands}>
                        {buttons}
                    </Stack>;

                    const styleRows: any = {paddingBottom: 10};
                    if ( quickCommands.styleRow ) {
                        try {
                            Object.keys(quickCommands.styleRow).map( k => {
                                styleRows[k] = quickCommands.styleRow[k];
                            });
                        } catch (e) {
                            alert( `quickCommands.styleRow is not valid JSON... please fix: ${quickCommands.styleRow}` );
                        }
                    }

                    allButtonRows.push( <div style={ styleRows }> { rowResult } </div> );

                    // https://github.com/mikezimm/drilldown7/issues/252
                    if ( rowCode.length > 0 ) allButtonRows.push( <div style={ styleRows }> 
                      <Stack horizontal={ true } tokens={stackQuickCommands}>
                          {rowCode}
                      </Stack>
                     </div> );


                } //END   if ( buttonRow && buttonRow.length > 0 ) {

            }); //END  quickCommands.buttons.map( (buttonRow, r) => {
            // allButtonRows.push( <Icon iconName= { 'Emoji2' } style={ { fontSize: '24px', } }/> );
            
        } //END   if ( buildAllButtonsTest === true ) {


    }

    return allButtonRows;

}
