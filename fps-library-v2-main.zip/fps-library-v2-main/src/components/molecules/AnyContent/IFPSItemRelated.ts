
export interface IFPSItemRelated {

  linkUrl: string;
  linkAlt: string; //For alt-clicking
  linkText: string;

  images: IUrlPairs[]; //Added this for possible expanding alt-click on item to go to Embed link instead of actual link
  links: IUrlPairs[]; //Added this for possible expanding alt-click on item to go to Embed link instead of actual link

}

export interface IUrlPairs {
  url: string;
  embed: string;
}
