
import { IAnySecurableItem } from "./IAnySecurableItem";

export const TypeCheckKeysAnyWeb : string [ ] = [

];

export interface IAnyWeb extends IAnySecurableItem {
  EnableMinimalDownload?: boolean;
  Title?: string;
  Description?: string;
  Created?: string;
  Language?: number;
  LastItemModifiedDate?: string;
  LastItemUserModifiedDate?: string;
  NoCrawl?: boolean;
  SiteLogoUrl?: string;
  SiteLogo?: string; // NOTE:  SiteLogo seems to be used if Site is a Team
  PictureThumbnailURL?: string;
  ServerRelativeUrl?: string;
  WebTemplate?: string;
  WebTemplateId?: number;
  Id?: any;
  ID?: any;
}
