/**
 * Based on IListInfo from node_modules\@pnp\sp\lists\types.d.ts
 */

import { IAnySecurableItem } from "./IAnySecurableItem";

/**
 * TypeCheckKeysAnyLibrary contains properties that are typically found on LISTS OR LIBRARIES
 */
export interface IAnyListLib extends IAnySecurableItem {

  // Most common props
  Title?: string;
  Description?: string;
  BaseType?: any;
  BaseTemplate?: number;
  ServerRelativeUrl?: string;
  Hidden?: boolean;
  Id?: any;
  ID?: any;

  IsSystemList?: boolean;
  ItemCount?: number;

  NoCrawl?: boolean;

  EnableVersioning?: boolean;
  MajorVersionLimit?: number;

  OnQuickLaunch?: boolean;
  AllowContentTypes?: boolean;

  Created?: string;
  EnableFolderCreation?: boolean;

  LastItemDeletedDate?: string;
  LastItemModifiedDate?: string;
  LastItemUserModifiedDate?: string;

  ImageUrl?: string;
}

/**
 * TypeCheckKeysAnyLibrary contains properties that are typically unique on LISTS OR LIBRARIES
 * If the item has any values in ay of these keys, it is very likely a LIST OR LIBRARY
 */
export const TypeCheckKeysAnyListLib: string[] = [
  'BaseType',
  'BaseTemplate',
  'Hidden',
  'IsSystemList',
  'ItemCount',
  'EnableVersioning',
  'MajorVersionLimit',
  'EnableFolderCreation',
  'OnQuickLaunch',
  'AllowContentTypes',
];

/**
 * IAnyList contains properties that are typically found on LISTs
 */
export interface IAnyList extends IAnyListLib {
  EntityTypeName?: string;
  EnableAttachments?: boolean;
  ListItemEntityTypeFullName?: string;
}

/**
 * TypeCheckKeysAnyList contains properties that are typically unique to just LISTs
 * If the item has any values in ay of these keys, it is very likely a LIST
 */
export const TypeCheckKeysAnyList: string[] = [
  'EntityTypeName',
  'EnableAttachments',
  'ListItemEntityTypeFullName',
];

/**
 * IAnyLibrary contains properties that are typically found on LIBRARIES
 */
export interface IAnyLibrary extends IAnyListLib {
  EnableMinimalDownload?: boolean;

  DraftVersionVisibility?: any;
  ForceCheckout?: boolean;

  EnableMinorVersions?: boolean;
  MajorWithMinorVersionsLimit?: number;

  EnableModeration?: boolean;
  EnableRequestSignOff?: boolean;

  ListItemEntityTypeFullName?: string;
  ExemptFromBlockDownloadOfNonViewableFiles?: boolean;

}

/**
 * TypeCheckKeysAnyLibrary contains properties that are typically unique to just LIBRARIES
 * If the item has any values in ay of these keys, it is very likely a LIBRARY
 */
export const TypeCheckKeysAnyLibrary: string[] = [
  'EnableMinimalDownload',
  'DraftVersionVisibility',
  'ForceCheckout',

  'EnableMinorVersions',
  'MajorWithMinorVersionsLimit',

  'EnableModeration',
  'EnableRequestSignOff',

  'ExemptFromBlockDownloadOfNonViewableFiles',
];
