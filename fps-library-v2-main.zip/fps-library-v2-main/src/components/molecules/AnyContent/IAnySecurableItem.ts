

export interface IAnySecurableItem {
  HasUniqueRoleAssignments?: boolean;
}
