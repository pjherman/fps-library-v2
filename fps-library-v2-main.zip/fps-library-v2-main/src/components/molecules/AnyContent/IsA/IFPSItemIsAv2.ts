
// /**
//  * WARNING
//  * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
//  */

// export type IItemHasACount = 'ItemHasToManyItems' | 'ItemHasLotsOfItems' | 'ItemHasNoItems' ;


// export const ItemHasUniquePerms: IItemIsAValues = `ItemHasUniquePerms`;

// // List-Library type of props
// export const ItemRequiresCheckout: IItemIsAValues = `ItemRequiresCheckout`;
// export const ItemHasNoVersioning: IItemIsAValues = `ItemHasNoVersioning`;
// export const ItemHasMinors: IItemIsAValues = `ItemHasMinors`;
// export const ItemHasNoAttachments: IItemIsAValues = `ItemHasNoAttachments`;

// export const ItemIsCheckedOut: IItemIsAValues = `ItemIsCheckedOut`;

// // Is this a web?
// export const ItemHasMinimalDownload: IItemIsAValues = `ItemHasMinimalDownload`;

// // 'ToManyItems' | 'LotsOfItems' | 'NoItems'
// // 'ItemHasToManyItems' | 'ItemHasLotsOfItems' | 'ItemHasNoItems'
// export const ItemHasToManyItems: IItemHasACount = `ItemHasToManyItems`;
// export const ItemHasLotsOfItems: IItemHasACount = `ItemHasLotsOfItems`;
// export const ItemHasNoItems: IItemHasACount = `ItemHasNoItems`;

// export const ItemHasNoRecentViews: IItemIsAValues = `ItemHasNoRecentViews`;
// export const ItemWasPopularRecently: IItemIsAValues = `ItemWasPopularRecently`;
// export const ItemWasPopularLifeTime: IItemIsAValues = `ItemWasPopularLifeTime`;

// export const ItemIsOtherContent: IItemIsAValues = `ItemIsOtherContent`;

// // HasUniqueRoleAssignments, CheckoutUserId

// /**
//  * WARNING
//  * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
//  */
// export const ItemIsAValues: IItemIsAValues[] = [
//   ItemIsADocSet, ItemIsAFile, ItemIsFolderContent,
//   ItemIsAPage, ItemIsANewsPost, ItemIsANewsLink,
//   ItemIsADraft, ItemIsAMajor, ItemIsPublished, ItemIsUnPublished,
//   ItemIsCodeContent, ItemIsOfficeContent, ItemIsDataContent, ItemIsMediaContent, ItemIsSharePointContent,
//   ItemHasUniquePerms ,
//   ItemRequiresCheckout , ItemHasNoVersioning , ItemHasMinors , ItemHasNoAttachments,
//   ItemIsCheckedOut, ItemHasMinimalDownload,
//   ItemHasToManyItems , ItemHasLotsOfItems , ItemHasNoItems,
//   ItemHasNoRecentViews, ItemWasPopularRecently, ItemWasPopularLifeTime, 
//   ItemIsOtherContent
// ];

// /**
//  * WARNING
//  * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
//  */
// export type IItemIsAKeys = 'DocSet' | 'File' | 'FolderContent' |
//   'Page' | 'NewsPost' | 'NewsLink' |
//   'Draft' | 'Major' | 'Published' | 'UnPublished' |
//   'CodeContent' | 'OfficeContent' | 'DataContent' | 'MediaContent' | 'SharePoint' |
//   'UniquePerms' | 
//   'RequiresCheckout' | 'VersionsDisabled' | 'MinorVersionsEnabled' | 'AttachmentsDisabled' |
//   'CheckedOut' | 'HasMinimalDownload' |
//   'ToManyItems' | 'LotsOfItems' | 'NoItems' |
//   'NoRecentViews' | 'PopularRecently' | 'PopularLifeTime' |
//   'OtherContent';

// /**
//  * WARNING
//  * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
//  */
// export const ItemIsAKeys: IItemIsAKeys[] = [
//   'DocSet', 'File', 'FolderContent',
//   'Page', 'NewsPost', 'NewsLink',
//   'Draft', 'Major', 'Published', 'UnPublished',
//   'CodeContent', 'OfficeContent', 'DataContent', 'MediaContent', 'SharePoint',
//   'UniquePerms',
//   'RequiresCheckout', 'VersionsDisabled', 'MinorVersionsEnabled', 'AttachmentsDisabled', 
//   'CheckedOut', 'HasMinimalDownload',
//   'ToManyItems' , 'LotsOfItems' , 'NoItems' ,
//   'NoRecentViews' , 'PopularRecently' , 'PopularLifeTime',
//   'OtherContent',
// ];
