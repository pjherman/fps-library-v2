// import { IItemIsAValues } from "./IFPSItemIsAv2";

// export interface IFPSItemIsAListObject {

//   VersionsDisabled?: boolean; // Added to highlight code in libraries...
//   AttachmentsDisabled?: boolean; // Added to highlight code in libraries...

//   HasMinimalDownload?: boolean; // Added to highlight code in libraries...

//   ToManyItems?: boolean;
//   LotsOfItems?: boolean;
//   NoItems?: boolean;

//   allIsAKeys?: IItemIsAValues[];
// }
