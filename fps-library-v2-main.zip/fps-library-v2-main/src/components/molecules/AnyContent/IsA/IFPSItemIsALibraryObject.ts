// import { IFPSItemIsASecurableObject, IItemIsASecurableValue } from "./IFPSItemIsASecurable";


// /**
//  * WARNING
//  * Constants, ItemIsAValues, IItemIsALibraryObjectValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
//  */
// export type IItemIsALibraryKeys = 
//   'RequiresCheckout' | 'VersionsDisabled' | 'MinorVersionsEnabled' | 'AttachmentsDisabled' |
//   'CheckedOut' | 'HasMinimalDownload' |
//   'ToManyItems' | 'LotsOfItems' | 'NoItems' ;

// /**
//  * WARNING
//  * Constants, ItemIsAValues, IItemIsALibraryObjectValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
//  */
// export const ItemIsALibraryKeys: IItemIsALibraryKeys[] = [
//   'RequiresCheckout', 'VersionsDisabled', 'MinorVersionsEnabled', 'AttachmentsDisabled', 
//   'CheckedOut', 'HasMinimalDownload',
//   'ToManyItems' , 'LotsOfItems' , 'NoItems' ,
// ];

// export interface IFPSItemIsALibraryObject extends IFPSItemIsASecurableObject {

//   RequiresCheckout?: boolean; // Added to highlight code in libraries...
//   VersionsDisabled?: boolean; // Added to highlight code in libraries...
//   MinorVersionsEnabled?: boolean; // Added to highlight code in libraries...
//   AttachmentsDisabled?: boolean; // Added to highlight code in libraries...

//   CheckedOut?: boolean; // Added to highlight code in libraries...
//   HasMinimalDownload?: boolean; // Added to highlight code in libraries...

//   ToManyItems?: boolean;
//   LotsOfItems?: boolean;
//   NoItems?: boolean;

//   allIsAKeys?: IItemIsALibraryAllValues[];
// }


// export type IItemHasACount = 'ItemHasToManyItems' | 'ItemHasLotsOfItems' | 'ItemHasNoItems' ;

// export type IItemIsALibraryObjectValues = 
//   'ItemRequiresCheckout' | 'ItemHasNoVersioning' | 'ItemHasMinors' | 'ItemHasNoAttachments' |
//   'ItemIsCheckedOut' | 'ItemHasMinimalDownload' ;

// export type IItemIsALibraryAllValues = IItemIsALibraryObjectValues & IItemHasACount & IItemIsASecurableValue

// // List-Library type of props
// export const ItemRequiresCheckout: IItemIsALibraryObjectValues = `ItemRequiresCheckout`;
// export const ItemHasNoVersioning: IItemIsALibraryObjectValues = `ItemHasNoVersioning`;
// export const ItemHasMinors: IItemIsALibraryObjectValues = `ItemHasMinors`;
// export const ItemHasNoAttachments: IItemIsALibraryObjectValues = `ItemHasNoAttachments`;

// export const ItemIsCheckedOut: IItemIsALibraryObjectValues = `ItemIsCheckedOut`;

// export const ItemHasMinimalDownload: IItemIsALibraryObjectValues = `ItemHasMinimalDownload`;

// export const ItemHasToManyItems: IItemHasACount = `ItemHasToManyItems`;
// export const ItemHasLotsOfItems: IItemHasACount = `ItemHasLotsOfItems`;
// export const ItemHasNoItems: IItemHasACount = `ItemHasNoItems`;

// export const ItemIsALibraryObjectValues: IItemIsALibraryAllValues[] = [
//   // ItemRequiresCheckout , ItemHasNoVersioning , ItemHasMinors , ItemHasNoAttachments,
//   // ItemIsCheckedOut, ItemHasMinimalDownload,
//   // ItemHasToManyItems , ItemHasLotsOfItems , ItemHasNoItems,
// ];