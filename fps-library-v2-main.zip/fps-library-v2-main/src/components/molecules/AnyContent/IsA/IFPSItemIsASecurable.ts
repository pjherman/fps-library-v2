

// export type IItemIsASecurableKeys = 'UniquePerms' ;

// export const ItemIsASecurableKeys: IItemIsASecurableKeys[] = [
//   'UniquePerms' ,
// ];

// export interface IFPSItemIsASecurableObject {
//   UniquePerms?: boolean; // Added to highlight code in libraries...
//   allIsAKeys?: IItemIsASecurableValue[];
// }

// export type IItemIsASecurableValue = 'ItemHasUniquePerms' ;

// export const ItemHasUniquePerms: IItemIsASecurableValue = `ItemHasUniquePerms`;

// export const ItemIsAValues: IItemIsASecurableValue[] = [
//   ItemHasUniquePerms,
// ];

