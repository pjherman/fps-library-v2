
/**
 * Comments about IsA Logic:
 * 
 * Where it all began:
 * 
 *  This started with Compliance web part and the CodeContent/OfficeContent etc labels.
 *  In that web part, it was designed to make it easier to create both searchable and clickable labels for filter buttons above the SourceList.
 *  The IsAKeys match the object keys in the IFPSItemIsA object
 *  The IsAValues are the labels that relate to said keys.
 * 
 *  They both of the Keys and Values arrays need to be in the exact same order in order for some of the search logic to work.
 *  So far that was only used in certain Content based props in Compliance, but it could now be used in any File Based use case like Document Sets.
 * 
 *  I'll admit, it's a little cumbersom to maintain given I keep adding more keys.
 *  BUT the goal is to have a standard way for both identifying what items have these labels.
 *  But also be able to then use the same labels for filtering or generating 'highlight' elements like in PivotTiles.
 */

export type IItemIsAKeys =
  'DocSet' | 'FileObject' | 'File' | 'FolderContent' |
  'Page' | 'NewsPost' | 'NewsLink' |
  'Draft' | 'Major' | 'Published' | 'UnPublished' | 'CheckedOut' | 
  'CodeContent' | 'OfficeContent' | 'ArchiveContent' | 'DataContent' | 'MediaContent' | 'SharePoint' |
  'UniquePerms' |
  'RequiresCheckout' | 'VersionsDisabled' | 'MinorVersionsEnabled' | 'AttachmentsDisabled' |
  'HasMinimalDownload' |
  'ToManyItems' | 'LotsOfItems' | 'NoItems' |
  'NoRecentViews' | 'PopularRecently' | 'PopularLifeTime' | 'MSTeam' | 'STSSite' | 'STSWeb' |
  'OtherContent';

export type IItemIsAValues =
  'ItemIsADocSet' |  'ItemIsAFileObject' | 'ItemIsAFile' | 'ItemIsFolderContent' |
  'ItemIsAPage' | 'ItemIsANewsPost' | 'ItemIsANewsLink' |
  'ItemIsADraft' | 'ItemIsAMajor' | 'ItemIsPublished' | 'ItemIsUnPublished' | 'ItemIsCheckedOut' | 
  'ItemIsCodeContent' | 'ItemIsOfficeContent' | 'ItemIsArchiveContent' | 'ItemIsDataContent' | 'ItemIsMediaContent' | 'ItemIsSharePointContent' |
  'ItemHasUniquePerms' | 
  'ItemRequiresCheckout' | 'ItemHasNoVersioning' | 'ItemHasMinors' | 'ItemHasNoAttachments' |
  'ItemHasMinimalDownload' |
  'ItemHasToManyItems' | 'ItemHasLotsOfItems' | 'ItemHasNoItems' |
  'ItemHasNoRecentViews' | 'ItemWasPopularRecently' | 'ItemWasPopularLifeTime' | 'ItemIsATeam' | 'ItemIsASite' | 'ItemIsAWeb' |
  'ItemIsOtherContent';


export interface IFPSItemIsA {

  /**
   * WARNING
   * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
   */
  // 2023-03-19: added in addSearchMeta1 - Only added IF TRUE
  DocSet?: boolean;
  FileObject?: boolean; // This includes if it's a File OR Folder
  File?: boolean;  // Only for Files, NOT Folder
  FolderContent?: boolean;
  Page?: boolean;
  News?: boolean;
  NewsPost?: boolean;
  NewsLink?: boolean;

  // 2023-03-19: added in addOtherIsAMeta - Only added IF TRUE
  Draft?: boolean;
  Major?: boolean;
  Published?: boolean;
  UnPublished?: boolean;
  CheckedOut?: boolean; // Added to highlight code in libraries...

  //'CodeContent' | 'OfficeContent' | 'DataContent' | 'MediaContent' | 'SharePoint' ;
  CodeContent?: boolean; // Added to highlight code in libraries... 
  OfficeContent?: boolean; // Added to highlight code in libraries...
  ArchiveContent?: boolean;
  DataContent?: boolean; // Added to highlight code in libraries...
  MediaContent?: boolean; // Added to highlight code in libraries...
  SharePoint?: boolean; // Added to highlight code in libraries...

  OtherContent?: boolean; // Added to highlight code in libraries...
  DescIsHTML?: boolean; // Added to highlight code in libraries... // linked to sescIsHTML in IFPSItemSearch

  // Item/Web/List/Library related
  UniquePerms?: boolean; // Added to highlight code in libraries...

  // List/Library related
  RequiresCheckout?: boolean; // Added to highlight code in libraries...
  VersionsDisabled?: boolean; // Added to highlight code in libraries...
  MinorVersionsEnabled?: boolean; // Added to highlight code in libraries...
  AttachmentsDisabled?: boolean; // Added to highlight code in libraries...

  HasMinimalDownload?: boolean; // Added to highlight code in libraries...

  ToManyItems?: boolean;
  LotsOfItems?: boolean;
  NoItems?: boolean;

  // Search Related
  NoRecentViews?: boolean;
  PopularRecently?: boolean;
  PopularLifeTime?: boolean;

  MSTeam?: boolean;
  STSSite?: boolean;
  STSWeb?: boolean;

  allIsAKeys: IItemIsAValues[];
}

/**
 * WARNING
 * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
 */


export const ItemIsADocSet: IItemIsAValues = `ItemIsADocSet`;
export const ItemIsAFileObject: IItemIsAValues = `ItemIsAFileObject`;
export const ItemIsAFile: IItemIsAValues = `ItemIsAFile`;
export const ItemIsFolderContent: IItemIsAValues = `ItemIsFolderContent`;

export const ItemIsAPage: IItemIsAValues = `ItemIsAPage`;
export const ItemIsANewsPost: IItemIsAValues = `ItemIsANewsPost`;
export const ItemIsANewsLink: IItemIsAValues = `ItemIsANewsLink`;

export const ItemIsADraft: IItemIsAValues = `ItemIsADraft`;
export const ItemIsAMajor: IItemIsAValues = `ItemIsAMajor`;
export const ItemIsPublished: IItemIsAValues = `ItemIsPublished`;
export const ItemIsUnPublished: IItemIsAValues = `ItemIsUnPublished`;

export const ItemIsCodeContent: IItemIsAValues = `ItemIsCodeContent`;
export const ItemIsOfficeContent: IItemIsAValues = `ItemIsOfficeContent`;
export const ItemIsArchiveContent: IItemIsAValues = `ItemIsArchiveContent`;
export const ItemIsDataContent: IItemIsAValues = `ItemIsDataContent`;
export const ItemIsMediaContent: IItemIsAValues = `ItemIsMediaContent`;
export const ItemIsSharePointContent: IItemIsAValues = `ItemIsSharePointContent`;

export const ItemHasUniquePerms: IItemIsAValues = `ItemHasUniquePerms`;

// List-Library type of props
export const ItemRequiresCheckout: IItemIsAValues = `ItemRequiresCheckout`;
export const ItemHasNoVersioning: IItemIsAValues = `ItemHasNoVersioning`;
export const ItemHasMinors: IItemIsAValues = `ItemHasMinors`;
export const ItemHasNoAttachments: IItemIsAValues = `ItemHasNoAttachments`;

export const ItemIsCheckedOut: IItemIsAValues = `ItemIsCheckedOut`;

// Is this a web?
export const ItemHasMinimalDownload: IItemIsAValues = `ItemHasMinimalDownload`;

// 'ToManyItems' | 'LotsOfItems' | 'NoItems'
// 'ItemHasToManyItems' | 'ItemHasLotsOfItems' | 'ItemHasNoItems'
export const ItemHasToManyItems: IItemIsAValues = `ItemHasToManyItems`;
export const ItemHasLotsOfItems: IItemIsAValues = `ItemHasLotsOfItems`;
export const ItemHasNoItems: IItemIsAValues = `ItemHasNoItems`;

export const ItemHasNoRecentViews: IItemIsAValues = `ItemHasNoRecentViews`;
export const ItemWasPopularRecently: IItemIsAValues = `ItemWasPopularRecently`;
export const ItemWasPopularLifeTime: IItemIsAValues = `ItemWasPopularLifeTime`;

export const ItemIsATeam: IItemIsAValues = `ItemIsATeam`;
export const ItemIsASite: IItemIsAValues = `ItemIsASite`;
export const ItemIsAWeb: IItemIsAValues = `ItemIsAWeb`;


export const ItemIsOtherContent: IItemIsAValues = `ItemIsOtherContent`;

/**
 * WARNING
 * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
 */
export const ItemIsAKeys: IItemIsAKeys[] = [
  'DocSet', 'FileObject', 'File', 'FolderContent',
  'Page', 'NewsPost', 'NewsLink',

  'Draft', 'Major', 'Published', 'UnPublished', 'CheckedOut',
  'CodeContent', 'OfficeContent', 'ArchiveContent', 'DataContent', 'MediaContent', 'SharePoint',

  'UniquePerms',
  'RequiresCheckout', 'VersionsDisabled', 'MinorVersionsEnabled', 'AttachmentsDisabled',

  'HasMinimalDownload',
  'ToManyItems' , 'LotsOfItems' , 'NoItems' ,

  'NoRecentViews' , 'PopularRecently' , 'PopularLifeTime', 'MSTeam', 'STSSite', 'STSWeb',
  'OtherContent',
];

export const CommonSuppressKeys: IItemIsAKeys[] = [
  'FileObject', 'File', 'Major', 'Published',
  'CodeContent', 'OfficeContent', 'ArchiveContent', 'DataContent', 'MediaContent', 'SharePoint',
];


/**
 * WARNING
 * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
 */
export const ItemIsAValues: IItemIsAValues[] = [
  ItemIsADocSet, ItemIsAFileObject, ItemIsAFile, ItemIsFolderContent,
  ItemIsAPage, ItemIsANewsPost, ItemIsANewsLink,
  
  ItemIsADraft, ItemIsAMajor, ItemIsPublished, ItemIsUnPublished, ItemIsCheckedOut, 
  ItemIsCodeContent, ItemIsOfficeContent, ItemIsArchiveContent, ItemIsDataContent, ItemIsMediaContent, ItemIsSharePointContent,
  
  ItemHasUniquePerms ,
  ItemRequiresCheckout , ItemHasNoVersioning , ItemHasMinors , ItemHasNoAttachments,
  
  ItemHasMinimalDownload,
  ItemHasToManyItems , ItemHasLotsOfItems , ItemHasNoItems,
  
  ItemHasNoRecentViews, ItemWasPopularRecently, ItemWasPopularLifeTime, ItemIsATeam, ItemIsASite, ItemIsAWeb,
  ItemIsOtherContent
];
