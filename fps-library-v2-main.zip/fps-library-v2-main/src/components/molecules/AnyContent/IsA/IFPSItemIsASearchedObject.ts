
// export type IItemIsASearchedItemKey = 'NoRecentViews' | 'PopularRecently' | 'PopularLifeTime' ;

// export const ItemIsASearchedItemKeys: IItemIsASearchedItemKey[] = [
//   'NoRecentViews' , 'PopularRecently' , 'PopularLifeTime',
// ];

// export interface IFPSItemIsASearchedObject {
//   NoRecentViews?: boolean;
//   PopularRecently?: boolean;
//   PopularLifeTime?: boolean;
//   allIsAKeys?: IItemIsASearchedItemValue[];
// }

// export type IItemIsASearchedItemValue = 'ItemHasNoRecentViews' | 'ItemWasPopularRecently' | 'ItemWasPopularLifeTime' ;

// export const ItemHasNoRecentViews: IItemIsASearchedItemValue = `ItemHasNoRecentViews`;
// export const ItemWasPopularRecently: IItemIsASearchedItemValue = `ItemWasPopularRecently`;
// export const ItemWasPopularLifeTime: IItemIsASearchedItemValue = `ItemWasPopularLifeTime`;

// export const ItemIsAValues: IItemIsASearchedItemValue[] = [
//   ItemHasNoRecentViews, ItemWasPopularRecently, ItemWasPopularLifeTime,
// ];
