// import { IFPSItemIsASecurableObject } from "./IFPSItemIsASecurable";

// export interface IFPSItemIsAListItem extends IFPSItemIsASecurableObject {

//   /**
//    * WARNING
//    * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
//    */
//   // 2023-03-19: added in addSearchMeta1 - Only added IF TRUE
//   DocSet?: boolean;
//   File?: boolean;
//   FolderContent?: boolean;
//   Page?: boolean;
//   News?: boolean;
//   NewsPost?: boolean;
//   NewsLink?: boolean;

//   // 2023-03-19: added in addOtherIsAMeta - Only added IF TRUE
//   Draft?: boolean;
//   Major?: boolean;
//   Published?: boolean;
//   UnPublished?: boolean;

//   //'CodeContent' | 'OfficeContent' | 'DataContent' | 'MediaContent' | 'SharePoint' ;
//   CodeContent?: boolean; // Added to highlight code in libraries... 
//   OfficeContent?: boolean; // Added to highlight code in libraries...
//   DataContent?: boolean; // Added to highlight code in libraries...
//   MediaContent?: boolean; // Added to highlight code in libraries...
//   SharePoint?: boolean; // Added to highlight code in libraries...

//   CheckedOut?: boolean; // Added to highlight code in libraries...

//   OtherContent?: boolean; // Added to highlight code in libraries...
//   DescIsHTML?: boolean; // Added to highlight code in libraries... // linked to sescIsHTML in IFPSItemSearch

//   UniquePerms?: boolean;

//   allIsAKeys?: IItemIsAListItemValue[];
// }

// export type IItemIsAListItemValue = 'ItemIsADocSet' | 'ItemIsAFile' | 'ItemIsFolderContent' |
//   'ItemIsAPage' | 'ItemIsANewsPost' | 'ItemIsANewsLink' |
//   'ItemIsADraft' | 'ItemIsAMajor' | 'ItemIsPublished' | 'ItemIsUnPublished' |
//   'ItemIsCodeContent' | 'ItemIsOfficeContent' | 'ItemIsDataContent' | 'ItemIsMediaContent' | 'ItemIsSharePointContent' |
//   'ItemHasUniquePerms' |
//   'ItemIsOtherContent';
// /**
//  * WARNING
//  * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
//  */


// export const ItemIsADocSet: IItemIsAListItemValue = `ItemIsADocSet`;
// export const ItemIsAFile: IItemIsAListItemValue = `ItemIsAFile`;
// export const ItemIsFolderContent: IItemIsAListItemValue = `ItemIsFolderContent`;

// export const ItemIsAPage: IItemIsAListItemValue = `ItemIsAPage`;
// export const ItemIsANewsPost: IItemIsAListItemValue = `ItemIsANewsPost`;
// export const ItemIsANewsLink: IItemIsAListItemValue = `ItemIsANewsLink`;

// export const ItemIsADraft: IItemIsAListItemValue = `ItemIsADraft`;
// export const ItemIsAMajor: IItemIsAListItemValue = `ItemIsAMajor`;
// export const ItemIsPublished: IItemIsAListItemValue = `ItemIsPublished`;
// export const ItemIsUnPublished: IItemIsAListItemValue = `ItemIsUnPublished`;

// export const ItemIsCodeContent: IItemIsAListItemValue = `ItemIsCodeContent`;
// export const ItemIsOfficeContent: IItemIsAListItemValue = `ItemIsOfficeContent`;
// export const ItemIsDataContent: IItemIsAListItemValue = `ItemIsDataContent`;
// export const ItemIsMediaContent: IItemIsAListItemValue = `ItemIsMediaContent`;
// export const ItemIsSharePointContent: IItemIsAListItemValue = `ItemIsSharePointContent`;

// export const ItemIsAListItemValues: IItemIsAListItemValue[] = [
//   ItemIsADocSet, ItemIsAFile, ItemIsFolderContent,
//   ItemIsAPage, ItemIsANewsPost, ItemIsANewsLink,
//   ItemIsADraft, ItemIsAMajor, ItemIsPublished, ItemIsUnPublished,
//   ItemIsCodeContent, ItemIsOfficeContent, ItemIsDataContent, ItemIsMediaContent, ItemIsSharePointContent,
// ];