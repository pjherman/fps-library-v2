import { IFPSHighlights, UniversalIconsPT } from "../../../atoms/Icons/standardUniversalFPS";
import { IAnySourceItem } from "../IAnyContent";

export function getIsAListHighlights( item: IAnySourceItem, UseHighlights: IFPSHighlights ): JSX.Element[] {

  if ( !item.FPSItem ) return [];
  const { IsA } = item.FPSItem;
  if ( !IsA ) return [];

  const highlights: JSX.Element[] = [];
  // IsA.UniquePerms / ItemHasUniquePerms
  if ( IsA.UniquePerms === true ) highlights.push( UseHighlights.UniquePerms );

  // IsA.HasMinimalDownload / ItemHasMinimalDownload
  if ( IsA.HasMinimalDownload === true ) highlights.push( UseHighlights.HasMinimalDownload );

  // IsA.NoRecentViews / ItemHasNoRecentViews
  if ( IsA.NoRecentViews === true ) highlights.push( UseHighlights.NoRecentViews );

  // IsA.LotsOfItems / ItemHasLotsOfItems
  if ( IsA.NoItems === true ) highlights.push( UseHighlights.NoItems )

    // IsA.ToManyItems / ItemHasToManyItems
    else if ( IsA.ToManyItems === true ) { highlights.push( UseHighlights.ToManyItems ); }

    // IsA.LotsOfItems / ItemHasNoItems
    else if ( IsA.LotsOfItems === true ) highlights.push( UseHighlights.LotsOfItems );

  // IsA.RequiresCheckout / ItemRequiresCheckout
  if ( IsA.RequiresCheckout === true ) highlights.push( UseHighlights.RequiresCheckout );

  // IsA.VersionsDisabled / ItemHasNoVersioning
  if ( IsA.VersionsDisabled === true ) highlights.push( UseHighlights.VersionsDisabled );

  // IsA.AttachmentsDisabled / ItemHasNoAttachments
  if ( IsA.AttachmentsDisabled ) highlights.push( UseHighlights.AttachmentsDisabled );

  return highlights;
}

export function getIsAWebHighlights( item: IAnySourceItem, UseHighlights: IFPSHighlights ): JSX.Element[] {

  if ( !item.FPSItem ) return [];
  const { IsA } = item.FPSItem;
  if ( !IsA ) return [];

  const highlights: JSX.Element[] = [];
  // IsA.UniquePerms / ItemHasUniquePerms
  if ( IsA.UniquePerms === true ) highlights.push( UseHighlights.UniquePerms );

  // IsA.HasMinimalDownload / ItemHasMinimalDownload
  if ( IsA.HasMinimalDownload === true ) highlights.push( UseHighlights.HasMinimalDownload );

  // IsA.NoRecentViews / ItemHasNoRecentViews
  if ( IsA.NoRecentViews === true ) highlights.push( UseHighlights.NoRecentViews );

  return highlights;
}





export function getIsAListHighlightsPT( item: IAnySourceItem ): JSX.Element[] {
  const Highlights: JSX.Element[] = getIsAListHighlights( item, UniversalIconsPT );
  return Highlights;
}

export function getIsAWebHighlightsPT( item: IAnySourceItem ): JSX.Element[] {
  const Highlights: JSX.Element[] = getIsAWebHighlights( item, UniversalIconsPT );
  return Highlights;
}