
// export const libraryColumns: string[] = [ 'ID','FileRef','FileLeafRef','ServerRedirectedEmbedUrl','Author/Title','Editor/Title','Author/Name','Editor/Name','Modified','Created','CheckoutUserId','HasUniqueRoleAssignments','Title','FileSystemObjectType','FileSizeDisplay','File_x0020_Type','FileLeafRef','LinkFilename','OData__UIVersion','OData__UIVersionString','DocIcon'];

import { IAnySourceItem } from "./IAnyContent";
import { IDefaultUser } from "../../../logic/Users/IDefaultUser";

// This adds specific properties that are always included in a File Object
export interface IFPSFileObject extends IAnySourceItem {
  ID: number;
  FileRef: string;
  FileLeafRef: string;
  ServerRedirectedEmbedUrl: string;
  Author?: IDefaultUser;
  Editor?: IDefaultUser;
  'Author/Title'?: string;
  'Editor/Title'?: string;
  'Author/Name'?: string;
  'Editor/Name'?: string;
  'File/ServerRelativeUrl'?: string;
  CheckoutUserId?: number;
  HasUniqueRoleAssignments?: boolean;
  Title?: string;
  FileSystemObjectType:  0 | 1;
  FileSizeDisplay:string;
  File_x0020_Type: string;
  LinkFilename: string;
  OData__UIVersion: number;
  OData__UIVersionString: string;
  DocIcon: string;

}

export const MinFileSelects: string[] = [ 'DocIcon' ];
export const MinFileObjectSelects: string[] = [ 'FileRef', 'FileLeafRef', 'FileSystemObjectType',  ];

// Added ,'CheckoutUserId' from Pivot Tiles to commonize it.
export const libraryColumns: string[] = [ 
  'ID','FileRef','FileLeafRef','ServerRedirectedEmbedUrl',
  'Author/Title','Editor/Title','Author/Name','CheckoutUserId','Editor/Name',
  'Modified','Created','HasUniqueRoleAssignments','Title','FileSystemObjectType',
  'FileSizeDisplay','File_x0020_Type','LinkFilename','OData__UIVersion','OData__UIVersionString',
  'DocIcon', 'ContentType/Name', ];

// same as libraryColumns but adding MetaInfo from Pivot Tiles
export const libraryColumnsMeta: string[] = [ ...libraryColumns, ...[ 'FieldValuesAsText/MetaInfo' ] ];

