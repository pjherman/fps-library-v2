import { ISearchType } from "../SearchPage/Interfaces/ISearchTypes";
import { IItemIsAValues } from "./IsA/IFPSItemIsA";


export interface IFPSItemSearch {
  // export type IAppFormat = 'general' | 'accounts' | 'manual' | 'sups' | 'appLinks' | 'news' | 'help' | 'entities' | 'acronyms' | 'history' | 'forms';
  format: any; //This represents the key of the SourceType

  searchText: string; // String that is used to search for items - Used to display search text in proper case
  searchTextLC: string; // String that is used to search for items - but in lower case to do the actual search

  leftSearch: string[]; //For easy display of casing
  leftSearchLC: string[]; //For easy string compare

  topSearch: string[]; //For easy display of casing
  topSearchLC: string[]; //For easy string compare

  sourceSearch: string[]; //For search buttons on Source Page 
  sourceSearchLC: string[]; //For search buttons on Source Page 

  searchSource: string; //For easy display of casing - For search page info
  searchSourceLC: string; //For easy string compare - For search page info


  // item.type = item['File_x0020_Type'] ;  // eslint-disable-line dot-notation
  primarySearchType: ISearchType;
  searchTypes: ISearchType[];
  allIsAKeys: IItemIsAValues[];

  type: string; // For content type icons
  searchTypeIdx: number; // Excact SearchTypeIndex for exact title, icon and color
  typeIdx: number; // For content type icons === searchTypeIdx - adjustIdx

  searchTitle: any;
  searchDesc: any;
  searchHref: string;

  descIsHTML: boolean; // linked to DescIsHTML in IFPSItemIsA
  meta: string[];

  // Added meta0-metaX for matching ISourceProps for future use.
  meta0?: string[]; // Used for quick filtering - aka buttons or Pivots - meta0 is used for things like Type
  meta1?: string[]; // Used for quick filtering - aka buttons or Pivots - meta1 is normal button
  meta2?: string[]; // Used for quick filtering - aka buttons or Pivots - meta2 is normal button
  meta3?: string[]; // Used for quick filtering - aka buttons or Pivots - meta3 is normal button
  metaX?: string[]; // Used for quick filtering - For common filters like Modified and Created metadata
}

export const EmptyFPSItemSearch : IFPSItemSearch = {
    // export type IAppFormat = 'general' | 'accounts' | 'manual' | 'sups' | 'appLinks' | 'news' | 'help' | 'entities' | 'acronyms' | 'history' | 'forms';
    format: null, //This represents the key of the SourceType

    searchText: '', // String that is used to search for items - Used to display search text in proper case
    searchTextLC: '', // String that is used to search for items - but in lower case to do the actual search
  
    leftSearch:  [], //For easy display of casing
    leftSearchLC:  [], //For easy string compare
  
    topSearch:  [], //For easy display of casing
    topSearchLC:  [],//For easy string compare
  
    sourceSearch:  [], //For search buttons on Source Page 
    sourceSearchLC:  [], //For search buttons on Source Page 
  
    searchSource: '', //For easy display of casing - For search page info
    searchSourceLC: '', //For easy string compare - For search page info
  
    // item.type = item['File_x0020_Type'] ;  // eslint-disable-line dot-notation
    primarySearchType: null,  // 2023-07-06: Should this be an object by default or null???
    searchTypes:  [],
    allIsAKeys:  [],
  
    type: '', // For content type icons
    searchTypeIdx: null, // Excact SearchTypeIndex for exact title, icon and color
    typeIdx: null, // For content type icons === searchTypeIdx - adjustIdx
  
    searchTitle: '',
    searchDesc: '',
    searchHref: '',
  
    descIsHTML: null, // linked to DescIsHTML in IFPSItemIsA
    meta: [],
}