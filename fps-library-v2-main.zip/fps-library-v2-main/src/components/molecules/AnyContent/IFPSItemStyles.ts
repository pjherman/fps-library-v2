import { IImageCover, IImageFit } from "../../../common/Images/imgFit";
import { IImageTarget } from "../../../common/Images/imgTarget";
import { ImageFit, ImageCoverStyle } from 'office-ui-fabric-react/lib/Image';

export interface IFPSItemStyles {
  class?: string;
  css?: {
    size?: string;
    weight?: string;
    style?: string;
    color?: string;
    height?: string;
    width?: string;
    margin?: string;
    padding?: string;
    target?: IImageTarget;
    cover?: IImageCover;
    fit?: IImageFit;
    background?: string;
  };
  fabric?: {
    imgCover?: ImageCoverStyle;
    imgFit?: ImageFit;
  }
  react?: React.CSSProperties;
}
