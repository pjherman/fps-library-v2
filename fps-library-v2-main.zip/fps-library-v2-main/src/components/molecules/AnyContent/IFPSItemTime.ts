/**
 * Copied from ITheTime except changed milliseconds to ms and daysAgo to age
 */

export interface IFPSItemTime {
  valid: boolean;
  now: Date; // Removing because .now is a method used to get the current timestamp.
  ms: number;
  theTime: string;
  local: string;
  year?: number;
  month?: number; //Zero Index
  minute?: number; //Zero Index
  monthStr?: string;
  week?: number;
  day?: number;
  date?: number;
  dayStr?: string;
  hour?: number;

  isToday?: boolean;
  isYesterday?: boolean;
  isThisWeek?: boolean;
  isThisMonth?: boolean;
  isThisYear?: boolean;
  age?: number;
  isoWeek?: number;

  priorSunday?: Date;
  priorMonday?: Date;
  firstOfMonth?: Date;

  daysSinceSun?: number;
  daysSinceMon?: number;
  daysSinceNewYear?: number;
  daysSinceMonthStart?: number;

  dayMMMDD?: string;
  dayDDDMMMDD?: string;
  dayYYYYMMDD?: string;
  dayOfWeekDDD?: string;
  dayOfWeekDxx?: string;

  coreTime?: string;
  hoursEarly?: number;
  hoursLate?: number;

}
