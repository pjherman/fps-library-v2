
export interface IFPSItemFile {
  valid: boolean;
  fileSizeNumber?: number;

  folderString?: string; // 'SubFolder1/SubFolder2' === Web/Library/SubFolder1/SubFolder2/Filename
  folderTree?: string[]; // [ 'SubFolder1', 'SubFolder2' ] === Web/Library/SubFolder1/SubFolder2/Filename

  fileDisplayName?: string;
}
