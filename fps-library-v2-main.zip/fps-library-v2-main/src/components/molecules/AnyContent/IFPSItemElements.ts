
export interface IFPSItemElements {
  content1?: JSX.Element; // In PivotTiles:  Top Left Views / pubDate
  content2?: JSX.Element; // In PivotTiles:  Top Right highlights
  content3?: JSX.Element; // In PivotTiles:  Bottom Left itemBar
  content4?: JSX.Element; // In PivotTiles:  Bottom Right have not used
}
