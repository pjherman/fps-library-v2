/**
 * Originally copied from IAnyContent in ALVFinMan.
 * Meant to be parent to be extended.
 */

import { IContentGroup } from "../SearchPage/Interfaces/IContentGroup";
import { IFPSItemIsA } from "./IsA/IFPSItemIsA";
import { IFPSItemStyles } from "./IFPSItemStyles";
import { IFPSItemTime } from "./IFPSItemTime";
import { IFPSItemFile } from "./IFPSItemFile";
import { IFPSItemSearch } from "./IFPSItemSearch";
import { IFPSItemPerson } from "./IFPSItemPerson";
import { IFPSItemRelated } from "./IFPSItemRelated";
import { IFPSItemElements } from "./IFPSItemElements";
import { IAnySecurableItem } from "./IAnySecurableItem";
import { IAnyLibrary, IAnyList } from "./IAnyListLib";
import { IAnyWeb } from "./IAnyWeb";


export interface IAnyListItem extends IAnySecurableItem {  // Properties associated with SharePoint List items (including files)
  Title?: string;
  Description?: string;
  Created?: string;
  createdAge?: number; // have this here for easy of use in AgeSlider
  Modified?: string;
  modifiedAge?: number; // have this here for easy of use in AgeSlider
  Author?: any;
  Editor?: any;
  'Author/Title'?: string;
  'Editor/Title'?: string;
  'Author/Name'?: string;
  'Editor/Name'?: string;
  'Author/Id'?: string;
  'Editor/Id'?: string;
  'Author/Office'?: string;
  'Editor/Office'?: string;
  'ContentType/Name'?: string;
  Id?: any;
  ID?: any;
  OData__UIVersionString?: any;
}

export interface IAnyFileItem extends IAnyListItem {  // Properties associated with SharePoint File items ( in addition to IAnyListItem )
  File?: any;
  FileRef?: string; // 2022-10-11:  Added as optional for File types for intellisense and typing
  FileLeafRef?: string; // 2022-10-11:  Added as optional for File types for intellisense and typing
  ServerRedirectedEmbedUri?: string;
  ServerRedirectedEmbedUrl?: string;
  File_x0020_Type?: string;
  DocIcon?: string;
  FileSizeDisplay?: string;
  FileSystemObjectType?: 0 | 1;
  CheckoutUserId?: any;
  'File/ServerRelativeUrl'?: string;
  /**
    * OData__OriginalSourceUrl is a hidden column in SharePoint Online that is used to store the original URL of a document that was uploaded to SharePoint. This column is used by the SharePoint Online search engine to crawl and index documents. It is not recommended to modify or delete this column as it can cause issues with search results and other SharePoint Online features¹.

    I hope this helps! Let me know if you have any other questions.

    Source: Conversation with Bing, 7/6/2023
    (1) Use OData query operations in SharePoint REST requests. https://learn.microsoft.com/en-us/sharepoint/dev/sp-add-ins/use-odata-query-operations-in-sharepoint-rest-requests.
    (2) OData Source for SharePoint Online - social.msdn.microsoft.com. https://social.msdn.microsoft.com/Forums/en-US/58807617-90aa-48e3-a06f-9582b683d8de/odata-source-for-sharepoint-online?forum=sharepointadmin.
    (3) Working with SharePoint Online through OData v4 Endpoint - KingswaySoft. http://www.kingswaysoft.com/blog/2021/06/29/Working-with-SharePoint-Online-through-OData-v4-Endpoint.
    (4) Using OData sources with Business Connectivity Services in SharePoint .... https://learn.microsoft.com/en-us/sharepoint/dev/general-development/using-odata-sources-with-business-connectivity-services-in-sharepoint.
  */
  OData__OriginalSourceUrl?: string;
}

export interface IAnySearchableItem {
  ViewsLifeTime?: string;
  ViewsRecent?: string;
  PopularLifeTime?: string;
  PopularRecent?: string;
}

export interface IAnyPageItem extends IAnyFileItem {
  ServerRelativeUrl?: string;
  CanvasContent1?: string;
  Title?: string;
  Description?: string;
  BannerImageUrl?: { // Copied from IPagesContent
    Url: string;
  };
  'File/ServerRelativeUrl'?: string;
}

export interface IAnyNewsItem extends IAnyPageItem {
  FirstPublishedDate?: string;
  publishedAge?: number;
  PromotedState?: 0 | 1 | 2;
  OData__OriginalSourceUrl?: string;
}

export interface IAnySourceItem extends IAnyListItem, IAnyFileItem, IAnyPageItem, IAnyNewsItem, IAnySecurableItem, IAnyList, IAnyLibrary, IAnyWeb, IAnySearchableItem  {
  FPSItem: IFPSItem;
}

export interface IAnySourceItemAny extends IAnySourceItem, Partial<any>  { }

// These are standard interfaces for properties created by this library but not on original item object
export interface IFPSItem {
  Stamp?: IFPSItemStamp;
  Image?: IFPSItemImage;
  Link?:  IFPSItemLink;
  Icon?: IFPSItemIcon;
  Search?: IFPSItemSearch;
  Suggestion?: IFPSItemSug;
  Font?: IFPSItemFont;
  File?: IFPSItemFile;
  IsA: IFPSItemIsA;
  Related?: IFPSItemRelated;
  Elements?: IFPSItemElements;  // Optional elements that are sent to components for rendering
  contentGroup?: IContentGroup; // - NOTE:  JSON files can be both Code and Data for searching but searchType: ISearchType; will be ContentGroupData
}

export interface IFPSItemStamp extends IFPSItemStyles {
  created?: IFPSItemTime;
  modified?: IFPSItemTime;
  published?: IFPSItemTime;
  editor?: IFPSItemPerson;
  author?: IFPSItemPerson;
  createdNote?: string;
  modifiedNote?: string;
}

export interface IFPSItemImage extends IFPSItemStyles {
  src: string;
  href?: string;
}

export interface IFPSItemLink extends IFPSItemStyles {
  href: string;
  title?: string;
  description?: string;
  status?: number;  // Optional status for when using test like _LinkStatus
  altUrl?: string;  // Link to open if holding alt key - Key #16
  ctrlUrl?: string;  // Link to open if holding ctrl key - Key #17
  shiftUrl?: string;  // Link to open if holding shift key - Key #18
  metaUrl?: string;  // Link to open if holding windows key - Key #XX
  key3Url?: string;  // Link to open if holding alt, ctr and shift key at same time
  altClick?: ( event: React.MouseEvent<HTMLDivElement | HTMLButtonElement | HTMLAnchorElement | HTMLSpanElement | HTMLLinkElement >, item: IAnySourceItem, ) => void;
}

export interface IFPSItemIcon extends IFPSItemStyles {  // Based upon IMyIcons in TrackMyTIme except added class and reactCss
  // hasIcon: boolean;
  name: string;
}

export interface IFPSItemSug {

}

export interface IFPSItemFont extends IFPSItemStyles {  // Based upon IMyFonts in TrackMyTime except added class and reactCss

}