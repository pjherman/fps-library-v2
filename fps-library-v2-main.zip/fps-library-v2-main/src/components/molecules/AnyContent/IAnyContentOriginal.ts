// /**
//  * Originally copied from IAnyContent in ALVFinMan.
//  * Meant to be parent to be extended.
//  */

// import { IFPSFileObject } from "../../../../pnpjs/SourceItems/FileInterface";
// import { IContentGroup } from "../../../../components/molecules/SearchPage/Interfaces/IContentGroup";
// import { IFPSItemIsA } from "./IFPSItemIsA";
// import { IFPSItemStyles } from "./IFPSItemStyles";
// import { IFPSItemTime } from "./IFPSItemTime";
// import { IFPSItemFile } from "./IFPSItemFile";
// import { IFPSItemSearch } from "./IFPSItemSearch";
// import { IFPSItemPerson } from "./IFPSItemPerson";


// export interface IAnyListItem {
//   Created?: string;
//   Modified?: string;
//   Author?: any;
//   Editor?: any;
//   Id?: any;
// }

// export interface IAnyFileItem {
//   File?: any;
//   FileRef?: string; // 2022-10-11:  Added as optional for File types for intellisense and typing
//   FileLeafRef?: string; // 2022-10-11:  Added as optional for File types for intellisense and typing
//   ServerRedirectedEmbedUri?: string;
// }

// export interface IAnyPageItem {
//   ServerRelativeUrl?: string;
// }

// export interface IAnyNewsItem {
//   FirstPublishedDate?: string;
// }

// export interface IAnySecurableItem {
//   HasUniqueRoleAssignments?: boolean;
// }

// // export interface IAnySourceItem extends Partial<any> {
// export interface IAnySourceItem extends IAnyListItem, IAnyFileItem, IAnyPageItem, IAnyNewsItem, IAnySecurableItem  {
//   // // export type IAppFormat = 'general' | 'accounts' | 'manual' | 'sups' | 'appLinks' | 'news' | 'help' | 'entities' | 'acronyms' | 'history' | 'forms';
//   // format: any; //This represents the key of the SourceType

//   // searchText: string;  // String that is used to search for items - Used to display search text in proper case
//   // searchTextLC: string;  // String that is used to search for items - but in lower case to do the actual search

//   // leftSearch: string[]; //For easy display of casing
//   // leftSearchLC: string[]; //For easy string compare

//   // topSearch: string[]; //For easy display of casing
//   // topSearchLC: string[]; //For easy string compare

//   // sourceSearch: string[]; //For search buttons on Source Page 
//   // sourceSearchLC: string[]; //For search buttons on Source Page 

//   // searchSource: string; //For easy display of casing - For search page info
//   // searchSourceLC: string; //For easy string compare - For search page info

//   // // item.type = item['File_x0020_Type'] ;  // eslint-disable-line dot-notation
//   // primarySearchType: ISearchType;
//   // searchTypes: ISearchType[];
//   // allIsAKeys: IItemIsAValues[];

//   // type: string;  // For content type icons
//   // searchTypeIdx: number // Excact SearchTypeIndex for exact title, icon and color
//   // typeIdx: number;  // For content type icons === searchTypeIdx - adjustIdx

//   // item.FPSItem.File.fileDisplayName = item['FileLeafRef'].replace(`.${item.type}`,'');  // eslint-disable-line dot-notation
//   // item.FPSItem.File.fileDisplayName = item['FileLeafRef'].replace(`.aspx`,'');  // eslint-disable-line dot-notation
//   // fileDisplayName?: string;

//   // searchTitle = item['FileLeafRef'] ? item['FileLeafRef'] : 'No Filename to show';  // eslint-disable-line dot-notation
//   // searchTitle: any;
//   // searchDesc: any;
//   // searchHref: string;

//   // descIsHTML: boolean;
//   // meta: string[];

//   // // Added meta0-metaX for matching ISourceProps for future use.
//   // meta0?: string[]; // Used for quick filtering - aka buttons or Pivots - meta0 is used for things like Type
//   // meta1?: string[]; // Used for quick filtering - aka buttons or Pivots - meta1 is normal button
//   // meta2?: string[]; // Used for quick filtering - aka buttons or Pivots - meta2 is normal button
//   // meta3?: string[]; // Used for quick filtering - aka buttons or Pivots - meta3 is normal button
//   // metaX?: string[]; // Used for quick filtering - For common filters like Modified and Created metadata


//   // FirstPublishedDate?: string;


//   // modifiedMS: number;
//   // createdMS: number;
//   // publishedMS?: number;

//   // modifiedLoc: string;
//   // createdLoc: string;
//   // publishedLoc?: string;

//   // modifiedD: string;
//   // createdD: string;
//   // publishedD?: string;

//   // modifiedAge: number;    // Age in Days from today
//   // createdAge: number;     // Age in Days from today
//   // publishedAge?: number;  // Age in Days from today

//   // FileRef?: string; // 2022-10-11:  Added as optional for File types for intellisense and typing
//   // FileLeafRef?: string; // 2022-10-11:  Added as optional for File types for intellisense and typing

//   // folderString: string; // 'SubFolder1/SubFolder2' === Web/Library/SubFolder1/SubFolder2/Filename
//   // folderTree: string[]; // [ 'SubFolder1', 'SubFolder2' ] === Web/Library/SubFolder1/SubFolder2/Filename

//   // HasUniqueRoleAssignments?: boolean;


//   /**
//    * WARNING
//    * Constants, ItemIsAValues, IItemIsAValues, ItemIsAKeys AND IAnySourceItem MUST BE IN SYNC AND IN ORDER
//    */

//   // 2023-03-19: added in addSearchMeta1 - Only added IF TRUE
//   // itemIsADocSet?: boolean;
//   // itemIsAFile?: boolean;
//   // itemIsFolderContent?: boolean;
//   // itemIsAPage?: boolean;
//   // itemIsANews?: boolean;
//   // itemIsANewsLink?: boolean;

//   // 2023-03-19: added in addOtherIsAMeta - Only added IF TRUE
//   // itemIsADraft?: boolean;
//   // itemIsAMajor?: boolean;
//   // itemIsPublished?: boolean;
//   // itemIsUnPublished?: boolean;

//     //'itemIsCodeContent' | 'itemIsOfficeContent' | 'itemIsDataContent' | 'itemIsMediaContent' | 'itemIsSharePoint' ;
//   // itemIsCodeContent?: boolean; // Added to highlight code in libraries... 
//   // itemIsOfficeContent?: boolean; // Added to highlight code in libraries...
//   // itemIsDataContent?: boolean; // Added to highlight code in libraries...
//   // itemIsMediaContent?: boolean; // Added to highlight code in libraries...
//   // itemIsSharePoint?: boolean; // Added to highlight code in libraries...
//   // itemIsOtherContent?: boolean; // Added to highlight code in libraries...
//   FPSItem: IFPSItem;
// }

// export interface IFPSItem {
//   Stamp?: IFPSItemStamp;
//   Image?: IFPSItemImage;
//   Link?:  IFPSItemLink;
//   Icon?: IFPSItemIcon;
//   Search?: IFPSItemSearch;
//   Suggestion?: IFPSItemSug;
//   Font?: IFPSItemFont;
//   File?: IFPSItemFile;
//   IsA?: IFPSItemIsA;
//   contentGroup?: IContentGroup; // - NOTE:  JSON files can be both Code and Data for searching but searchType: ISearchType; will be ContentGroupData
// }


// export interface IFPSItemStamp extends IFPSItemStyles {
//   created?: IFPSItemTime;
//   modified?: IFPSItemTime;
//   published?: IFPSItemTime;
//   editor?: IFPSItemPerson;
//   author?: IFPSItemPerson;
// }

// export interface IFPSItemImage extends IFPSItemStyles {
//   src: string;
//   href?: string;
// }

// export interface IFPSItemLink extends IFPSItemStyles {
//   href: string;
//   title?: string;
//   description?: string;
// }

// export interface IFPSItemIcon extends IFPSItemStyles {  // Based upon IMyIcons in TrackMyTIme except added class and reactCss
//   // hasIcon: boolean;
//   name: string;
// }

// export interface IFPSItemSug {

// }

// export interface IFPSItemFont extends IFPSItemStyles {  // Based upon IMyFonts in TrackMyTime except added class and reactCss

// }