
export interface IFPSItemPerson {
  valid: boolean;
  Id: any;
  ID: any;
  Title: string;
  Name: string;
  Email: string;
}
