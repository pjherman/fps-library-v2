import * as React from 'react';
import { Icon, } from 'office-ui-fabric-react/lib/Icon';

export type IAnimation = 'TopDown' | 'CenterExpand';

export interface IMinAccordionProps {
    refreshId?: string; // Optional to cause rerender in case content actually changes

    title: any; //Text or element
    titleClass?: string;
    titleStyles?: React.CSSProperties;

    content: any; //JSX.Element
    showAccordion?: boolean; //Defaults to false
    animation?: IAnimation; //Defaults to top-down

    componentClass?: string;
    componentStyles?: React.CSSProperties; //This is where you can set paddingBottom for entire component

    contentStylesVis?: React.CSSProperties; //This is where to set the height styles when visible
    contentStylesHidden?: React.CSSProperties; //This is where you can set content to be partially visible when 'hidden mode'.

    defaultIcon?: string; //Defaults to 
    toggleCallback?: any; //Can be used by caller to know the current state and make adjustments.  Sends current state back.
}

export interface IMinAccordionState {
    showAccordion: boolean;
}

require('@mikezimm/fps-styles/dist/AccordionStyles.css');

export default class Accordion extends React.Component<IMinAccordionProps, IMinAccordionState> {

    public constructor(props:IMinAccordionProps){
        super(props);

        this.state = {
            showAccordion: this.props.showAccordion !== undefined ? this.props.showAccordion : false,
        };
    }

    public componentDidMount() {
    }

    public componentDidUpdate(prevProps: IMinAccordionProps){

        let refresh = false;
        if ( prevProps.showAccordion !== this.props.showAccordion ) { refresh = true; }
        if ( prevProps.refreshId !== this.props.refreshId ) { refresh = true; }
        if ( refresh === true ) {
        }

        return refresh;

    }
    public shouldComponentUpdate(nextProps: IMinAccordionProps, nextState: IMinAccordionState ) {
      if (this.props.refreshId !== nextProps.refreshId) {
        return true;
      } else if (this.props.showAccordion !== nextProps.showAccordion) {
        return true;
      } else if (this.state.showAccordion !== nextState.showAccordion) {
        return true;
      }
      return false;
    }

    public render(): React.ReactElement<IMinAccordionProps> {

      const { title, content, defaultIcon, animation, componentClass, titleClass, titleStyles, 
          componentStyles, contentStylesVis, contentStylesHidden  } = this.props;

        const { showAccordion, } = this.state;

        let accordionClassName = '';

        switch ( this.props.animation ) {

            case 'CenterExpand':
                accordionClassName = showAccordion === true || contentStylesHidden ? 'show-fps-accordion-2' : 'hide-fps-accordion-2';
                break;

            case 'TopDown':
                accordionClassName = showAccordion === true || contentStylesHidden ? 'show-fps-accordion-1' : 'hide-fps-accordion-1';
                break;

            default: 
                accordionClassName = showAccordion === true || contentStylesHidden ? 'show-fps-accordion-1' : 'hide-fps-accordion-1';

        }
        const ExpandIconName = defaultIcon ? defaultIcon : 'ChevronDownSmall' ;

        const AccordionIcon = <Icon style={{ paddingLeft: '20px'}} iconName={ showAccordion === true ? 'ChevronUpSmall' : ExpandIconName }/>;

        const TitleClassNames = ['fps-accordion-title-flex'];
        if ( typeof title === 'string' ) TitleClassNames.push( 'fps-accordion-title' );
        if ( titleClass ) TitleClassNames.push( titleClass );

        const contentStylesWhenVisible = contentStylesVis ? contentStylesVis : { height: '100px' };
        const contentStyles = showAccordion === true ? contentStylesWhenVisible : contentStylesHidden ? contentStylesHidden : { }  ;
        if ( !title ) contentStyles.cursor = 'pointer'; // Make entire content the button if there is no title

        const AccordionComponent = <div className= { componentClass } style={ componentStyles }
          onClick={ title ? null : this._toggleAccordion.bind( this ) } >

          <div className={ TitleClassNames.join(' ') } style={ titleStyles }
            onClick={ title ? this._toggleAccordion.bind( this ) : null }>{ title } { AccordionIcon }</div>

          <div className={ [ 'fps-accordion', accordionClassName ].join(' ')} style={ contentStyles } >
                { content }
          </div>

        </div>;

        return ( AccordionComponent );
    }

    private _toggleAccordion( ) {
        let showAccordion = this.state.showAccordion === true ? false : true;
        this.setState( { showAccordion: showAccordion });
        if ( this.props.toggleCallback ) this.props.toggleCallback( showAccordion );
      }

}
