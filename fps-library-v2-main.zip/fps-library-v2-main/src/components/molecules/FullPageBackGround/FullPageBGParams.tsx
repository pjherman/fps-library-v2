
export const PageFitOriginal: string = `fullPageFit=Original`;
export const PageFitLayout2: string = `fullPageFit=Layout2`;
export const SetNormalColor: string = `defaultFontColor=default`;
export const SetWhiteColor: string = `defaultFontColor=white`;
export const ClearAllParams: string = `clearAllParams=true`;

export const FullPageBGParams: string[] = [PageFitOriginal, PageFitLayout2, SetNormalColor, SetWhiteColor, ClearAllParams];
// paramters used for FullBackGround