import { check4This } from "@mikezimm/fps-pnp2/lib/services/sp/CheckSearch";

// require( './forceWhiteText.css' );
require('@mikezimm/fps-styles/dist/forceWhiteText.css');
/**
 * NOTE:  To get CanvasZones, do this:  
 *    const divs: any[] = Array.from( document.querySelectorAll('.CanvasZone'));
 * 
 * @param CanvasZone 
 * @param updates 
 * @returns 
 */
export function forceWebpartWhiteText(CanvasZone: Element, updates: number): number {

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const webparts: any[] = Array.from(CanvasZone.querySelectorAll('.ControlZone'));
  if ( check4This(`defaultFontColor=default` ) === true ) console.log("CanvasControls.length: ", webparts.length);

  webparts.map((thisWP, wpNumb) => {
    thisWP.classList.add('forceWhiteText');
    updates++;

  });

  return updates;

}
