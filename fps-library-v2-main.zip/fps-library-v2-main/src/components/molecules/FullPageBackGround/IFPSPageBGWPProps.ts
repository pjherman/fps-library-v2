
// Partial lets you control two UI options:  
//  With Partial, it does not add the PropertyPaneGroup and Does NOT add the PropPaneHelp
//  So in SlickSections, you can put the PropertyPane Group at the top
//  AND you can put the PropPaneHelp exactly where you want.
export type IFullBackgroundMode = 'Auto' | 'Partial' | false; 

export type IFullPageOverlayColor = 'Black' | 'White';
export const FullPageOverlayColors: IFullPageOverlayColor[] = [ `Black`, `White` ];

export type IFPSFullPageImageFit = 'Original' | 'Layout2';
export const FullPageImageFitStrings: IFPSFullPageImageFit[] = [ `Original`, `Layout2` ];

export interface IFPSPageBGWPProps {

  // Used for full page background image
  fullPageImage: string; // background url
  fullPageImageFilter: string; // background url filter css
  fullPageScrollable: boolean; // NOT ENABLED YET.  scrollable image - image goes from top of content to bottom - false is fixed image
  defaultWhiteText: boolean; // default white text on all sections unless noted
  whiteRefreshTip: string;
  fullPageOverlayOpacity: number; // https://github.com/mikezimm/Slick-Sections/issues/40
  fullPageOverlayColor: IFullPageOverlayColor; // https://github.com/mikezimm/Slick-Sections/issues/40
  defaultWPBack: string;
  fullPageImageFit: IFPSFullPageImageFit;
  _allowFullPageBG: IFullBackgroundMode; // Pushed down from class automatically
  enableTabs: boolean; // Pushed down from class automatically

}

export const changeFullBackground: string[] = [`fullPageImage`, `fullPageImageFilter`, `fullPageScrollable`,
  `defaultWhiteText`, `whiteRefreshTip`, `fullPageOverlayOpacity`, `fullPageOverlayColor`, `defaultWPBack`, `fullPageImageFit`];
