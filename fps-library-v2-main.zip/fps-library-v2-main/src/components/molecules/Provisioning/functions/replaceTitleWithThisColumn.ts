import { ootbLinkFilename } from '../constants/columnsOOTB';
import { IMyFieldDefStringOrDef, IMyFieldTypes } from '../interfaces/columnTypes';

/**
 * replaceTitleWithThisColumn will replace the 'Title' column with any other column in an array of fields.
 *    By default, it will replace Title with the LinkFileName since that is the most common replacement for a library.
 * @param currentFields 
 * @param replacementField 
 * @returns 
 */
export function replaceTitleWithThisColumn(currentFields: IMyFieldDefStringOrDef[], replacementField: IMyFieldTypes = ootbLinkFilename ): IMyFieldDefStringOrDef[] {
  const result: IMyFieldDefStringOrDef[] = [];
  currentFields.map((field: IMyFieldTypes) => {
    result.push( field.name !== 'Title' ? field : replacementField ); }
  );
  return result;
}
