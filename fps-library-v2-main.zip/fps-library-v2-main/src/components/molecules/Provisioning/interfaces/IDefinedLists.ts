
export type IDefinedLists = 'No List Available' | 'ErrorChecks' | 'TrackMyTime' | 'Harmon.ie' | 'Customer Requirements' | 'Tasks' | 'Reports' | 'Turnover' |
  'Socialiis' | 'PivotTiles' | 'Drilldown' | 'PreConfig' | 'Manufacturing' | 'Analytics' | 'Logistics' | 'Components';
