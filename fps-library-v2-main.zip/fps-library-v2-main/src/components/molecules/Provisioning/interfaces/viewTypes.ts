
/**
 * This file was copied directly from npmFunctions last update and used in:
 *  Easy Contents
 *  Library Provisioning (for labels)
 *
 *  Changes only include cleaning up imports and removed the [ key: .... ] stuff
 *
 */

import { IViewInfo } from "@pnp/sp/views/types";

import { IMyFieldTypes, } from './columnTypes';

export interface MyOperator {
  q: string;
  o: string;
}

/**
 * Standard query values
 */
export const queryValueCurrentUser = '<Value Type="Integer"><UserID Type="Integer" /></Value>';

export function queryValueToday(offSetDays: number | null = null){

  if ( offSetDays == null || offSetDays === 0 ) {
    return '<Value Type="DateTime"><Today /></Value>';
  } else {
    return '<Value Type="DateTime"><Today OffsetDays="' + offSetDays + '" /></Value>';
  }

}

export const Eq : MyOperator = { q:'Eq' , o: '='};
export const Ne : MyOperator = { q:'Ne' , o: '<>'};
export const Gt : MyOperator = { q:'Gt' , o: '>'};
export const Geq : MyOperator = { q:'Geq' , o: '>='};
export const Lt : MyOperator = { q:'Lt' , o: '<'};
export const Leq : MyOperator = { q:'Leq' , o: '<='};
export const IsNull : MyOperator = { q:'IsNull' , o: 'IsNull'};
export const IsNotNull : MyOperator = { q:'IsNotNull' , o: 'IsNotNull'};
export const Contains : MyOperator = { q:'Contains' , o: 'Contains'};
export const BeginsWith : MyOperator = { q:'BeginsWith' , o: 'BeginsWith'};


export interface IViewOrder {
  field: string | IMyFieldTypes;
  asc: true | false;
}

export interface IViewWhere {
  field: string | IMyFieldTypes; // Static Name
  clause: 'Or' | 'And'; //clause
  oper: MyOperator ; //Operator
  val: string; //Value
}

export interface IViewGroupBy {
  fields?: IViewOrder[];
  collapse?: boolean;
  limit?: number;
}

export type IViewField = IMyFieldTypes | string;

export interface IMyView extends Partial<IViewInfo> {
  Title: string;
  ServerRelativeUrl?: string;  //For creating views, just partial URL with no .aspx
  RowLimit?: number; //Optional.  Default = 30
  iFields?: IViewField[]; //Interface Objects of ViewFields in array (from columnTypes)
  wheres?: IViewWhere[];
  orders?: IViewOrder[];
  groups?: IViewGroupBy;

  // 2023-09-15:  Added these to improve viewServices logic just adding it to the view itself.
  foundView?: boolean;
  actualViewSchema?: string;
  viewFieldsSchemaString?: string;
  viewWhereXML?: string;
  viewOrderByXML?: string;
  viewGroupByXML?: string;
  errMess?: string;

}
