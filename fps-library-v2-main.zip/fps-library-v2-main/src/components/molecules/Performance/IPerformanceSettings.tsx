import { DisplayMode } from '../../../common/interfaces/@msft/1.15.2/displayMode';
import { ILoadPerformanceOps, IPerformanceOp } from './IPerformance';

/**
 * Add this to ISource Props and performance will automatically be added to the return object
 */
export interface IPerformanceSettings extends IStartPerformOp {
  updateMiliseconds: boolean;
  op?: ILoadPerformanceOps;
}

export interface IStartPerformOp {
  label: string;
  editMode?: DisplayMode | null;
  includeMsStr?: boolean;
}

export interface IEndPerformOp {
  op: IPerformanceOp;
  updateMiliseconds: boolean;
  count: number | null;
}
