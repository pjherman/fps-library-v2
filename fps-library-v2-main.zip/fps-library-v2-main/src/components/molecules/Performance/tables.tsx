import * as React from 'react';

// import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';

import { IPerformanceOp, ILoadPerformance, ILoadPerformanceOps, LoadPerformanceOps, IMinPerformanceSetting } from './IPerformance';
import { check4This } from '@mikezimm/fps-pnp2/lib/services/sp/CheckSearch';

require('@mikezimm/fps-styles/dist/performance.css'); //Does not work
// window.require('./styles.css');  //Does not work

const alwaysShowNumber: number = -7799 ;

/**
 * 
 * @param performance 
 * @param keysToShow 
 * @param minMSToShow : set this number to 99 to only show rows when ms value > 99 ms
 * @returns 
 */
export function createPerformanceRows( performance: ILoadPerformance, keysToShow: ILoadPerformanceOps[], minMSToShow: number = alwaysShowNumber ) { //[ 'fetch', 'analyze' ]

    // const { fetch, analyze } = performance;
    let showRows = 0;
    let hideRows = 0;
    const cellStyles: React.CSSProperties = { paddingLeft: '10px' };
    const loadRows: any[] = [
      <tr>
        {/* https://github.com/mikezimm/fps-library-v2/issues/57  */}
        <th>Mode</th>
        <th style={ cellStyles }>Process</th>
        <th style={ cellStyles }>ms</th>
        <th style={ cellStyles }>Start Time</th>
      </tr>
    ];

    if ( !keysToShow || keysToShow.length === 0 ) { keysToShow = LoadPerformanceOps ; } 
    keysToShow.map( ( part: string ) => {

      if ( part.indexOf('setting') >-1 ) {
        const sets: any = performance.sets;
        const thisPart : IMinPerformanceSetting | undefined = sets[part];

        if ( thisPart ) {
          showRows ++;
          loadRows.push( <tr>
            <td>{ thisPart.label }</td>
            <td>{ `${thisPart.value}` }</td>
          </tr>);
        }
      } else {
        const ops: any = performance.ops;
        const thisPart : IPerformanceOp | undefined = ops[part];

        if ( thisPart ) {
          let time: string = thisPart.startStr;

          if ( minMSToShow === alwaysShowNumber || ( thisPart.ms && thisPart.ms > minMSToShow ) ) {
            showRows ++;
            loadRows.push( <tr>
              {/* https://github.com/mikezimm/fps-library-v2/issues/57  */}
              <td >{ thisPart.mode === 1 ? 'View' : 'Edit' }</td>
              <td style={ cellStyles }>{ thisPart.label }</td>
              <td style={ cellStyles }>{ thisPart.ms }</td>
              <td style={ cellStyles }>{ time }</td>
            </tr>);
          } else {
            hideRows ++;
          }
        }
      }
    });

    return showRows > 0 ? loadRows : [];

}

// export function createCacheRows( cacheInfo: ICacheInfo ) {
export function createCacheRows( cacheInfo: any ) {

  const loadRows: any[] = [
    <tr>
      <th style={{ minWidth: '150px' }}>Property</th>
      <th style={{ minWidth: '150px' }}>Value</th>
      {/* <th>Time</th>
      <th>ms</th> */}
    </tr>
  ];

  const skipProps: string[] = [ 'wasCached', 'enableHTMLCache', 'EditorName', 'FileRef', 'size' ];
  Object.keys( cacheInfo ).map( part => {

    if ( skipProps.indexOf( part ) < 0 && cacheInfo[ part ] ) {
      loadRows.push( <tr>
        <td>{ part }</td>
        <td>{ cacheInfo[ part ] }</td>
      </tr>);
    }

  });

   return loadRows;

}

/**
 * USED BY:  ALVFM This is used for the visitor panel, not code pane
 * @param performance 
 * @returns 
 */
export function createPerformanceTableVisitor( performance: ILoadPerformance , keysToShow: ILoadPerformanceOps[] ) {

  if ( check4This( 'tracePerformance=true' ) === true ) console.log( `tracePerformance createPerformanceTableVisitor ~ 92`, JSON.parse(JSON.stringify( performance )) );

  if ( performance ) {
    const loadSummary = <div className={ 'fps-performance' } style={{ paddingLeft: '15px', paddingTop: '30px'}}>
      <div className={ 'fps-header-styles' }>Load Performance: Vis</div>
      {/* Originally:  <div style={{paddingBottom: '8px'}}>forceReloadScripts: { JSON.stringify( performance.forceReloadScripts )}</div> */}
      {/* { !titleAboveTable ? null : <div style={{paddingBottom: '8px'}}>{ titleAboveTable } { JSON.stringify( objAboveTable )}</div> } */}
      <table>
          {/* { buildPerformanceTableRows( fetchInfo.performance ) } */}
          { createPerformanceRows( performance, keysToShow ) }
      </table>
    </div>;

    return ( loadSummary );

  } else {

    return ( <div></div> );

  }


}

/**
 * USED BY:  SecureScript7 loadTable >> loadSummary in \secureScript7\components\SecureScriptVisitorPanel.tsx
 * @param performance 
 * @returns 
 */
 export function createPerformanceTableVisitorXtra( performance: ILoadPerformance, titleAboveTable: string = '', keysToShow: ILoadPerformanceOps[] , objAboveTable: any = null ) {

  if ( check4This( 'tracePerformance=true' ) === true ) console.log( `tracePerformance createPerformanceTableVisitorXtra ~ 120`, JSON.parse(JSON.stringify( performance )) );

  const loadSummary = <div className={ 'fps-performance' } style={{ paddingLeft: '15px', paddingTop: '30px'}}>
    <div className={ 'fps-header-styles' }>Load Performance: Xtra</div>
    {/* Originally:  <div style={{paddingBottom: '8px'}}>forceReloadScripts: { JSON.stringify( performance.forceReloadScripts )}</div> */}
    { !titleAboveTable ? null : <div style={{paddingBottom: '8px'}}>{ titleAboveTable } { JSON.stringify( objAboveTable )}</div> }
    <table>
        {/* { buildPerformanceTableRows( fetchInfo.performance ) } */}
        { createPerformanceRows( performance, keysToShow ) }
    </table>
  </div>;

  return ( loadSummary );

}

/**
 * USED BY: SecureScript7 loadTable >> loadSummary in \secureScript7\components\SecureScript7.tsx
 * @param performance 
 * @param cacheOnClick 
 * @returns 
 */
export function createPerformanceTableSmall( performance: ILoadPerformance , keysToShow: ILoadPerformanceOps[], cacheOnClick: any ) {
  const loadSummary = <div className={ 'fps-performance' } style={{ paddingLeft: '15px'}}>
    <div className={ 'fps-tableheading' } >Performance Details</div>
    <table>
      {/* { buildPerformanceTableRows( fetchInfo.performance ) } */}
      { createPerformanceRows( performance, keysToShow ) }
      {/* { rows } */}
    </table>
  </div>;

  return ( loadSummary );

}

/**
 * USED BY: SecureScript7 code pane and includes cache info
 * @param cache 
 * @param cacheOnClick 
 * @returns 
 */
//  export function createCacheTableSmall( cache: ICacheInfo, cacheOnClick: any ) {
 export function createCacheTableSmall( cache: any, cacheOnClick: any ) {

  const loadSummary = <div className={ 'fps-performance' } style={{ paddingLeft: '15px'}}>
    <div  className={ 'fps-tableheading' }>Cache Details</div>
    <table>
      {/* { buildPerformanceTableRows( fetchInfo.performance ) } */}
      { createCacheRows( cache ) }
      {/* { rows } */}
    </table>
  </div>;
  
  return ( loadSummary );

}