
// import { fetchFpsPageAsXML, } from '@mikezimm/fps-library-v2/lib/pnpjs/FieldAsXML/FetchPage'

// import { ISourceProps } from "../../../../pnpjs";
import { ISourceProps } from "../../../../pnpjs/SourceItems/Interface";
import { fetchFpsPageAsXML } from "../../../../pnpjs/FieldAsXML/FetchPage";
import { IPagesContent } from "../../../../pnpjs/SourceItems/SitePages/IPagesContent";
import { ICanvasContentOptions } from "../Interfaces/IModernPage";

// import { IPagesContent } from "../../../fpsReferences";
// import { ICanvasContentOptions } from "../../INTERFACES/IModernPage";

// import { ISourcePropsFM,  } from '../../DataInterface';

export function getDocWiki( item: IPagesContent, source: ISourceProps, canvasOptions: ICanvasContentOptions,  showCanvasContent1: boolean, callBack: any ) :void {

  if ( !item || !item.ID ) { 
    console.log('Error getting item wiki');
    const result = { 
      fetchError: 'getDocWiki item is null!',
      CanvasContent1: 'CanvasContent1:  getDocWiki item is null!',
    };

    callBack( result, showCanvasContent1 );

  } else {
    const { webUrl, listTitle, selectThese, expandThese, isModern } = source;
    const { ID,  } = item;

    // const result: IFpsPageAsXMLReturn = await fetchFpsPageAsXML( webUrl, listTitle, typeof ID === 'string' ? parseInt(ID): ID, selectThese, expandThese, [], isModern, true, true );
    fetchFpsPageAsXML( webUrl, listTitle, typeof ID === 'string' ? parseInt(ID): ID, selectThese, expandThese, [], isModern, true, true ).then( result => {

      if ( result.status === 'Success' && result.item ) {
        const fetchedItem = result.item;
        //Added this to fit images into the current width or else the image is full size
        if ( fetchedItem.CanvasContent1 ) { fetchedItem.CanvasContent1Str = fetchedItem.CanvasContent1.replace( /<img\s*/ig , `<img ${canvasOptions.imageOptions.style} ` ) ; }
        fetchedItem.BannerImageUrl = item.BannerImageUrl as any;
        fetchedItem.fetchError = '';
        console.log('Fetched modern page');
        fetchedItem.originalContent = {};

        // Set type of thisKey as 'originalContent' to resolve typing error without casting entire object as any
        Object.keys( item ).map( ( thisKey: 'originalContent' )  => {
          if ( thisKey === 'originalContent' ) {
            console.log('getModernContent.ts ~ 57');
          }
          else if ( fetchedItem[ thisKey ] && fetchedItem[ thisKey ] !== item[ thisKey ]) { fetchedItem.originalContent[ thisKey ] = item[ thisKey ]; }
          else { fetchedItem[ thisKey ] = item[ thisKey ]; }
        });

        callBack( fetchedItem, showCanvasContent1 ) ;

      } else {
        item.fetchError = 'Error getting item wiki';
        console.log('Error getting item wiki');
        callBack( item, showCanvasContent1 ) ;
      }
    }).catch((e) =>  {
      console.log('fetchFpsPageAsXML seemed to fail')
    });
  }
}
