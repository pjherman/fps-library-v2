import * as React from 'react';

// import { Icon, } from 'office-ui-fabric-react/lib/Icon';

import Accordion from '../../Accordion/Accordion';

require('@mikezimm/fps-styles/dist/fpsGeneralCSS.css'); // for gotoLink

// import stylesP from '../../SourcePages/SourcePages.module.scss';
// import stylesA from '../../AlvFinMan.module.scss';
// import { openThisLinkInNewTab } from '../../../atoms/Links/CreateLinks';
import { getGoToLinks } from '../../../atoms/Links/GoToLinks';
import { ISourceProps } from '../../../../pnpjs/SourceItems/Interface';

// import { openThisLinkInNewTab } from '../../../fpsReferences';

export function LimitedVersionPage( showThisItem: any,   primarySource: ISourceProps ): JSX.Element {

    /**
     * Limited Content Warning content accordion
     */

    // const LimitedTitle: JSX.Element = <h2 style={{ fontSize: 'larger', marginTop: '20px', textDecoration: 'underline' }}>This is a Limited version of this page:</h2>;

    const ClickHereToOpenContent: JSX.Element = <div style={{ padding: '20px 20px 30px', backgroundColor: 'lightgray' }}>
        <div>

        <h3 style={{ marginBlockStart: '0px' }} >What you will see here:</h3>
        <ul>
            <li>Formatted text and Links</li>
            <li>Images shown as banner - may not see full image.</li>
        </ul>

        <h3  style={{ marginBlockStart: '0px' }} >To get full page functionality listed below - click on the link below.</h3>
        <ul>
            <li>Image formatting like sizing,</li>
            <li>All other parts such as Tiles, PageInfo, Youtube, Images and Galleries etc...</li>
        </ul>

        </div>
        { getGoToLinks( { item: showThisItem , primarySource: primarySource, altText: `Click here to open full page ( in a new tab )` } ) }
        {/* <div style={{ display: 'flex', alignItems: 'center', fontSize: 'larger', fontWeight: 600, color: 'darkblue' }}>
          <div style={{ cursor: 'pointer', marginRight: '50px' }}
          onClick={ openThisLinkInNewTab.bind( this, showThisItem.FileRef ? showThisItem.FileRef : showThisitem.FPSItem.Search.searchHref ) }>
          Click here to open full page ( in a new tab ) <Icon iconName='OpenInNewTab'/></div>

          { !listLink ? undefined : <div style={{ cursor: 'pointer',}} className={ [ 'fps-gen-inBlockNoWrap', 'fps-gen-goToLink' ].join(' ')} onClick={ () => { window.open( `${listLink}`,'_blank' ) ; } }>
            Open list <Icon iconName='OpenInNewTab'/>
          </div>}
        </div> */}



    </div>;

    const LimitedVersionAccordion: JSX.Element = <Accordion 
        // title={ LimitedTitle }
        title={ `NOTE:  This is a Limited version of this page:` }
        showAccordion={ false }
        animation= { 'TopDown' }
        contentStylesVis={ {height: '270px'} }
        content = { ClickHereToOpenContent }
        defaultIcon = 'Info'
    />;

    return LimitedVersionAccordion;
}

