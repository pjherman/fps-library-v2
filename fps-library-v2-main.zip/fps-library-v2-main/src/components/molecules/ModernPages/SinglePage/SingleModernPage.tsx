import * as React from 'react';

require ('@mikezimm/fps-styles/dist/ModernPages.css');
// import stylesM from '../ModernPages.module.scss';
// import { IPagesContent } from "../../../fpsReferences";
import { ISingleModernPageProps, ISingleModernPageState, } from '../Interfaces/ISingleModernPageProps';

// import * as strings from 'AlvFinManWebPartStrings';

import ReactJson from "react-json-view";

// import { makeToggleJSONCmd } from '../../../fpsReferences';
import { getDocWiki } from './getModernContent';
import { getModernHumanReadable } from './processModernContent';

import { LimitedVersionPage } from './LimitedVersion';
import { PageDetailsComponent } from './PageDetails';
import { makeToggleJSONCmd } from '../../../atoms/Elements/ToggleJSONButton';
import { IPagesContent } from '../../../../pnpjs/SourceItems/SitePages/IPagesContent';
import { getItemProperties } from '../../SourceList/ItemPane/itemProperties';
import { getItemEmbed } from '../../SourceList/ItemPane/itemEmbed';

// const consoleLineItemBuild: boolean = false;  // eslint-disable-line @typescript-eslint/no-unused-vars

export default class SingleModernPage extends React.Component<ISingleModernPageProps, ISingleModernPageState> {

  private cke_editable = this.props.canvasOptions.addCkeEditToDiv !== false ? 'cke_editable' : '';

  private ToggleJSONCmd = makeToggleJSONCmd( this._toggleJSON.bind( this ), 'Click for more details' );

  public constructor(props:ISingleModernPageProps){
    super(props);
    console.log('constructor:',   );
    this.state = {
      showPanelJSON: false,
      showThisItem: this.props.page,
      showPageDetails: false,
    };
  }

  public componentDidMount():void {
    console.log('SMP: componentDidMount:',   );
    this.updateWebInfo( '', false );
  }

  public updateWebInfo ( webUrl: string, listChangeOnly : boolean ):void {
    console.log('SMP: updateWebInfo:',   );
    if ( this.props.page && this.props.showCanvasContent1 === true ) {
      getDocWiki( this.props.page , this.props.source, this.props.canvasOptions, this.props.showCanvasContent1, this.updateModernState.bind( this ) );
    }
  }

    /***
   *         d8888b. d888888b d8888b.      db    db d8888b. d8888b.  .d8b.  d888888b d88888b 
   *         88  `8D   `88'   88  `8D      88    88 88  `8D 88  `8D d8' `8b `~~88~~' 88'     
   *         88   88    88    88   88      88    88 88oodD' 88   88 88ooo88    88    88ooooo 
   *         88   88    88    88   88      88    88 88~~~   88   88 88~~~88    88    88~~~~~ 
   *         88  .8D   .88.   88  .8D      88b  d88 88      88  .8D 88   88    88    88.     
   *         Y8888D' Y888888P Y8888D'      ~Y8888P' 88      Y8888D' YP   YP    YP    Y88888P 
   *                                                                                         
   *                                                                                         
   */

  public componentDidUpdate(prevProps: ISingleModernPageProps): void {
    //Just rebuild the component
    if ( this.props.refreshId !== prevProps.refreshId ) {
      this.setState({ showThisItem: this.props.page });

    } else if ( this.props.page && !prevProps.page ) {
      this.setState({ showThisItem: this.props.page });

    } else if ( this.props.imageStyle !== prevProps.imageStyle ) {
        this.setState({ showThisItem: this.props.page });

    } else if ( JSON.stringify( this.props.canvasOptions) !== JSON.stringify( prevProps.canvasOptions ) ) {
      this.setState({ showThisItem: this.props.page, });

    } else if ( this.props.page === null ) {
      //Do nothing if page is null

    } else if ( this.props.page.ID !== prevProps.page.ID ) {
      this.setState({ showThisItem: this.props.page, });
    }
  }

  public render(): React.ReactElement<ISingleModernPageProps> {

    const { showCanvasContent1, source } = this.props;
    const { showThisItem, } = this.state;

    if ( !showThisItem ) {
      // const FetchingSpinner = <Spinner size={SpinnerSize.large} label={"Fetching Page ..."} style={{ padding: 30 }} />;
      // return ( <div>{ FetchingSpinner }</div> );
      return ( <div /> );
    } else {

      const debugContent = this.props.debugMode !== true ? null : <div style={{ cursor: 'default', marginLeft: '20px' }}>
        App in debugMode - Change in Web Part Properties - Page Preferences.  <b><em>Currently in SinglePage</em></b>
      </div>;


      let panelHeading = null;
      let panelTitle = 'Unknown Title';
      if ( showThisItem.Title ) { panelTitle = showThisItem.Title ; }
      else if ( showThisItem.Title0 ) { panelTitle = showThisItem.Title0 ; }
      else if ( showThisItem.FileLeafRef ) { panelTitle = showThisItem.FileLeafRef ; }

      let articleDesc: any  = showThisItem ? showThisItem.Description : '';

      panelHeading = <div style={{ paddingBottom: '20px'}}>
        <h2>{ panelTitle }</h2>
        { articleDesc ? <h3>Description:</h3> : null }
        { articleDesc }
      </div>;

       const imageUrl = showThisItem ? showThisItem.BannerImageUrl : null;
      const image = !showThisItem || !imageUrl ? null : 
      <img src={ imageUrl.Url } height="100px" width="100%" style={{ objectFit: "cover" }} title={ imageUrl.Url }/>;

      const headerComponent = <div>
          { debugContent }
          { image }
          { panelHeading }
          { PageDetailsComponent( showThisItem, this.props.debugMode ) }
      </div>;


      /* eslint-disable dot-notation */


      if ( !showThisItem ) {
        return null;

      //Add warning to link outside of our system.
      } else if ( showThisItem && showThisItem['OData__OriginalSourceUrl'] && showThisItem['OData__OriginalSourceUrl'].indexOf( window.location.origin ) < 0 ) {  // eslint-disable-line dot-notation
        //Link is external...  Use different instructions
        return (
          <div style={{ paddingTop: '15px'}}>
          { headerComponent }
          <div style={{ paddingBottom: '10px', fontWeight: 600 }}>To go to article: <span style={{ cursor: 'pointer', color: 'darkblue' }} onClick={ this.openThisLink.bind( this, showThisItem['OData__OriginalSourceUrl'] )}>click here</span></div>
          <div style={{ color: 'red', }}>Security check :)  This is the full link you will be clicking on</div>
          <div>{ showThisItem['OData__OriginalSourceUrl'] } </div>
        </div>
        );

      } else if ( showCanvasContent1 !== true ) {
        return (
          <div style={{ paddingTop: '15px'}}>
            { headerComponent }
            <div>To go to article: <span style={{ cursor: 'pointer', color: 'darkblue' }}onClick={ this.openArticleNewTab.bind( this, showThisItem )}>click here</span></div>
            <div>To open article in NEW full-size tab: <b>CTRL-Click the Title</b> </div>
            <div>To show it right here: <b>CTRL-ALT-Click the Title</b></div>
            <div>To show it in a side panel: <b>ALT-Click the Title</b></div>
          </div>);

      } else {
        // const listUrl = `${this.props.source.webUrl}${this.props.source.webRelativeLink}`;

        const CanvasContent1 = !showThisItem || !showThisItem.CanvasContent1Str ? null : 
        <div>
          { LimitedVersionPage( showThisItem, this.props.source ) }
          <div className={ ['', this.cke_editable].join(' ') } dangerouslySetInnerHTML={{ __html: showThisItem.CanvasContent1Str }} />
        </div>;

        if ( CanvasContent1 ) { articleDesc = null ; } //Remove Description because full article is shown below

        const jsonContent = this.state.showPanelJSON !== true ? null : <div>
          <ReactJson src={ showThisItem } name={ 'Summary' } collapsed={ false } displayDataTypes={ true } displayObjectSize={ true } enableClipboard={ true } style={{ padding: '20px 0px' }}/>
        </div>;

        // const fileEmbed = !showThisItem || !showThisItem.ServerRedirectedEmbedUrl ? null : <iframe src={ showThisItem.ServerRedirectedEmbedUrl } height='350px' width='100%' style={{paddingTop: '20px' }}/>;

        const DetailsElement : JSX.Element = this.state.showPanelJSON !== true ? null :  
          <div style={{ paddingTop: '1.5em' }}>
            { getItemProperties( { item: showThisItem , primarySource: source, columns: [ 'Searched', 'Selected' ], searchText: this.props.searchText  } ) }
            { jsonContent }
          </div>



        return (
          <div className={ ['fps-modern-article', '' ].join(' ') } style={{ paddingBottom: '3em' }}>
            { headerComponent }
            { CanvasContent1 }
            { getItemEmbed( { item: showThisItem } ) }
            { this.ToggleJSONCmd }
            { DetailsElement }
          </div>
        );
      }
    }
  }

  private updateModernState( item: IPagesContent, ): void {
    this.setState({
      showThisItem: item });
  }

  private openArticleNewTab( item: IPagesContent ): void {
    window.open( item.File.ServerRelativeUrl , '_blank' );
  }

  private openThisLink( link:string ): void {
    window.open( link , '_blank' );
  }

  // export { openThisLinkInNewTab } from '../fpsPreferences';
  // private clickOpenInNewTab( href ) {

  // }

  private _toggleJSON( ): void {
    const newState = this.state.showPanelJSON === true ? false : true;

    let result = this.state.showThisItem;
    result = getModernHumanReadable( result );

    this.setState( { showThisItem: result , showPanelJSON: newState });
  }

  
  // private _togglePageDetails( ) {
  //   let showPageDetails = this.state.showPageDetails === true ? false : true;
  //   this.setState( { showPageDetails: showPageDetails });
  // }

}
