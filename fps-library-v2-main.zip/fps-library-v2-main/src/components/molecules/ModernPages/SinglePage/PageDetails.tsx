import * as React from 'react';
import { getDateStampRow } from '../../../atoms/WhoDunItRow/getDateStampRow';

// import styles from '../../AlvFinMan.module.scss';

require('@mikezimm/fps-styles/dist/fpsDateStamp.css');
require('@mikezimm/fps-styles/dist/fpsGeneralCSS.css');

import Accordion from '../../Accordion/Accordion';
import { makeid } from '../../../../logic/Strings/guids';

export function PageDetailsComponent( showThisItem: any, debugMode : boolean = false ): JSX.Element {

    /**
     * Page Details content accordion
     */

    let PageDetails: JSX.Element = null;

    if ( debugMode !== true ) {
        PageDetails = <div style={{ paddingBottom: '20px' }}>
          {/* NOTE IF Styles are not same... I am pulling this from sourceItemPane.css now */}
        <div className={ 'fps-gen-flexColWidth100' } >
          { getDateStampRow( showThisItem, 'Modified' ) }
        </div>
        </div>;

    } else {
        const pageDetailsX = <div>
        <div className={ 'fps-gen-flexColWidth100' } >
            <div>File Location: { showThisItem.FileRef ? showThisItem.FileRef : showThisItem.FPSItem.Search.searchHref }</div>
            { getDateStampRow( showThisItem, 'Created' ) }
            { getDateStampRow( showThisItem, 'Modified' ) }
        </div>
        </div>;

        PageDetails = <Accordion 
          title={ `Page properties:` }
          showAccordion={ false }
          animation= { 'TopDown' }
          refreshId={ makeid(5) }
          contentStylesVis={ {height: '70px'} }
          content = { pageDetailsX }
        />;
    }

    return PageDetails;

}
