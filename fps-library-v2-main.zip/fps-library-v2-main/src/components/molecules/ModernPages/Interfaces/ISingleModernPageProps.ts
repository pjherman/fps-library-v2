
// import { IPagesContent } from "../../../fpsReferences";
// import { ICanvasContentOptions } from "../../INTERFACES/IModernPage";
// import { ISourcePropsFM } from "../../DataInterface";

import { ISourceProps } from "../../../../pnpjs/SourceItems/Interface";
import { IPagesContent } from "../../../../pnpjs/SourceItems/SitePages/IPagesContent";
import { ICanvasContentOptions } from "./IModernPage";

export interface ISingleModernPageProps {

  page: IPagesContent;

  showCanvasContent1: boolean;

  imageStyle: string;

  source: ISourceProps;

  refreshId: string;

  canvasOptions: ICanvasContentOptions;

  searchText?: string; // used to highlight properties

  debugMode?: boolean; //Option to display visual ques in app like special color coding and text

}

export interface ISingleModernPageState {
  // description: string;
  showPanelJSON: boolean;
  showThisItem: any;  // eslint-disable-line @typescript-eslint/no-explicit-any
  showPageDetails: boolean;

}
