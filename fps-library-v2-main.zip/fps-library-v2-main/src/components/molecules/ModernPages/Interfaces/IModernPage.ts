
export type IPageLoadPref = 'description' | 'canvasContent1' | 'tab';

export interface IPageLoadPrefChoices {
  key: IPageLoadPref | IObjectFit;
  text: string;
}
export const PageLoadPefs: IPageLoadPrefChoices[] = [
  { key: 'description', text: 'Just short description' },
  { key: 'canvasContent1', text: 'Full page' },
  { key: 'tab', text: 'Open full page in new tab' },
];

export type IObjectFit = 'center' | 'contain' | 'cover' | 'none' | 'center-cover' | 'center-contain';

export const ImageFitPrefs: IPageLoadPrefChoices[] = [
  { key: 'center', text: 'center' },
  { key: 'contain', text: 'contain' },
  { key: 'cover', text: 'cover' },
  { key: 'center-cover', text: 'center-cover' },
  { key: 'center-contain', text: 'center-contain' },
];

export interface IModernImageSettings {
  height: number | string;
  width: number | string;
  objectFit: string; //cover, contain, etc...
  style: string; //gets embedded directly into all image tags as:  <img style="Your style string here" - height: 150px; object-fit: "cover"; width: 100%;
  autoFix?: boolean; //Maybe eventually I could try to auto-fix but have this optional.
  lightBox?: boolean; //Option to add lightbox on click to show image full size
}

export interface ICanvasContentOptions {

  pagePreference: IPageLoadPref;

  addCkeEditToDiv?: boolean; //Will add class="cke_editable" to the styles.article div so that Tables have some formatting when shown in app.
  imageOptions?: IModernImageSettings;

  h1Styles?: string; //Use similar to FPSPageOptions styling 
  h2Styles?: string; //Use similar to FPSPageOptions styling 
  h3Styles?: string; //Use similar to FPSPageOptions styling 

}
