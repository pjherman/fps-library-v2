// import { sortStringArray, sortObjectArrayByStringKey, sortNumberArray, sortObjectArrayByNumberKey, sortKeysByOtherKey } from '../../fpsReferences';
// import { ISeriesSort, ISeriesSortObject } from '../../fpsReferences';  // eslint-disable-line @typescript-eslint/no-unused-vars

import { ISeriesSortObject } from "../../../../logic/indexes/ArraySortingNumbers";
import { ISourceProps } from "../../../../pnpjs/SourceItems/Interface";
import { IPagesContent } from "../../../../pnpjs/SourceItems/SitePages/IPagesContent";
import { ICanvasContentOptions } from "./IModernPage";

// import { IPagesContent } from "../../fpsReferences";
// import { ICanvasContentOptions } from "../INTERFACES/IModernPage";
// import { ISourcePropsFM } from "../DataInterface";

export type IModernPage = 'General' | 'News' | 'Help' | 'Standards' | '';
export const ModernPageValues: IModernPage[] = [ 'General', 'News', 'Help' ,'Standards'  ];

export interface IModernPagesProps {

  pages: IPagesContent[];

  sort: ISeriesSortObject;

  source: ISourceProps;

  // buckets: IFMBuckets;

  mainPivotKey: IModernPage;

  showPublishDate: boolean;
  showSearch: boolean;

  refreshId: string;

  canvasOptions: ICanvasContentOptions;

  debugMode?: boolean; //Option to display visual ques in app like special color coding and text

}

export interface IModernPagesState {
  // description: string;

  showItemPanel: boolean;
  showThisItem: any;
  showCanvasContent1: boolean;
  showPanelJSON: boolean;
  
  sort: ISeriesSortObject;

  searchText?: string; // Optional for searching

  refreshId: string;

}
