import * as React from 'react';
// import styles from '../AlvFinMan.module.scss';
// import stylesM from './ModernPages.module.scss';
// import { IPagesContent } from "../../fpsReferences";
import { IModernPagesProps, IModernPagesState, ModernPageValues, } from './Interfaces/IModernPagesProps';
import { escape } from '@microsoft/sp-lodash-subset';  // eslint-disable-line @typescript-eslint/no-unused-vars

import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';

// import { getMMMDDFromStr } from '@mikezimm/fps-library-v2/lib/logic/Time/monthLabels';

// import { sortObjectArrayByNumberKey } from '../../fpsReferences';

import { getDocWiki } from './SinglePage/getModernContent';

import SingleModernPage from './SinglePage/SingleModernPage';
import { IPagesContent } from '../../../pnpjs/SourceItems/SitePages/IPagesContent';
import { sortObjectArrayByNumberKey } from '../../../logic/indexes/ArraySortingNumbers';
import { getMMMDDFromStr } from '../../../logic/Time/monthLabels';

require ('@mikezimm/fps-styles/dist/ModernPages.css');

//  NOTE:   linkNoLeadingTarget is used in Layouts1, Layouts2 and Modern Pages... maybe consolidate
export const linkNoLeadingTarget = /<a[\s\S]*?href=/gim;   //

// const consoleLineItemBuild: boolean = false;

/**
 *
  Never list these page titles in the list of pages:
*/
const ignoreThesePages: string[] = [
  'Easy Contents', // 
  'EasyContents', // 
];

export default class ModernPages extends React.Component<IModernPagesProps, IModernPagesState> {

  private imageStyle = '';

  public constructor(props:IModernPagesProps){
    super(props);
    console.log('constructor:',   );
    this.state = {
      showItemPanel: false,
      showCanvasContent1: this.props.canvasOptions.pagePreference === 'canvasContent1' ? true : false,
      showPanelJSON: false,
      showThisItem: this.props.pages.length > 0 ? this.props.pages[ 0 ] : null,
      refreshId: `${this.props.refreshId}`,
      sort: {
        prop: this.props.sort.prop,
        order: this.props.sort.order,
      },
    };
  }

  public async componentDidMount() : Promise<void>  {
    console.log('MP: componentDidMount:',   );
    await this.updateWebInfo( '', false );
  }

  public async updateWebInfo ( webUrl: string, listChangeOnly : boolean ) : Promise<void>{
    console.log('MP: updateWebInfo:',   );
    if ( this.state.showThisItem && this.state.showCanvasContent1 === true ) {
      await getDocWiki( this.state.showThisItem , this.props.source, this.props.canvasOptions, this.state.showCanvasContent1, this.updateModernState.bind( this ) );
    }

    // this.setState({ docs: docs, buckets: buckets, sups: sups });

  }

  //        
    /***
   *         d8888b. d888888b d8888b.      db    db d8888b. d8888b.  .d8b.  d888888b d88888b 
   *         88  `8D   `88'   88  `8D      88    88 88  `8D 88  `8D d8' `8b `~~88~~' 88'     
   *         88   88    88    88   88      88    88 88oodD' 88   88 88ooo88    88    88ooooo 
   *         88   88    88    88   88      88    88 88~~~   88   88 88~~~88    88    88~~~~~ 
   *         88  .8D   .88.   88  .8D      88b  d88 88      88  .8D 88   88    88    88.     
   *         Y8888D' Y888888P Y8888D'      ~Y8888P' 88      Y8888D' YP   YP    YP    Y88888P 
   *                                                                                         
   *                                                                                         
   */

  public async componentDidUpdate(prevProps: IModernPagesProps): Promise<void> {
    //Just rebuild the component

    const { showSearch, showPublishDate, pages, source, refreshId, canvasOptions } = this.props;

    const hasNewPages = pages?.length && pages?.length > 0 && pages.length !== prevProps.pages.length ? true : false;
    
    if ( hasNewPages === true && this.state.showCanvasContent1 === true ) {
      // Get full page if it is required and first page is available
      getDocWiki( pages[0] , source, canvasOptions, this.state.showCanvasContent1, this.updateModernState.bind( this ) );

    } else if ( hasNewPages === true || refreshId !== prevProps.refreshId ) {

      console.log('MP: componentDidUpdate: refreshId', prevProps.refreshId, refreshId  );
      let showThisItem: IPagesContent = this.state.showThisItem;
      if ( !showThisItem && pages.length > 0 ) showThisItem = pages[0];
      this.setState({ refreshId: refreshId, showThisItem: showThisItem });

    } else if ( JSON.stringify( canvasOptions) !== JSON.stringify( prevProps.canvasOptions ) ) {
      console.log('MP: ModernPages style update: ', this.imageStyle );
      this.setState({ refreshId: refreshId, });
    }
  }

  public render(): React.ReactElement<IModernPagesProps> {

    if ( ModernPageValues.indexOf( this.props.mainPivotKey )< 0  ) {
      return ( null );

    } else {

      const { showSearch, showPublishDate, pages, source, refreshId, canvasOptions } = this.props;

      console.log('ModernPages: ReactElement', refreshId  );

      const pagesList : any[] = [];

      const SortedPages: IPagesContent[] = sortObjectArrayByNumberKey( pages, this.state.sort.order, this.state.sort.prop );

      SortedPages.map( item => {
        const classNames = [ 'titleListItem', 'leftFilter' ];

        //Disabled lint on this line in case it was number vs text
        if ( this.state.showThisItem && ( item.ID == this.state.showThisItem.ID ) ) { classNames.push( 'isSelected' ) ; }  // eslint-disable-line eqeqeq
        //Make sure page has Title and is not a dud, also check it's not a common page that does not belong in this component
        if ( item.Title && ignoreThesePages.indexOf( item.Title ) < 0 ) {
          pagesList.push( <li className={ classNames.join( ' ' ) } onClick= { this.clickNewsItem.bind( this, item.ID, 'pages', item  )} style={ null }>
          { showPublishDate === true ? 
          <div style={{ display: 'inline-block' }}>
            <div >{ getMMMDDFromStr( item.FirstPublishedDate ) }</div>
            <div>{ item.Title }</div>
          </div>
          : item.Title } 
          </li> );
        }
      });

      const page = <div className={ [ 'modernPage', this.props.debugMode === true ? 'debugMode' : null ].join(' ') } style={{  }} >
        {/* <div className={ styles.titleList }> <ul>{ pagesList }</ul></div> */}
        <div className={ 'titleList' }>
          <h3>{source.searchSource}</h3>
          <div className= { 'pageDescription' }>{source.searchSourceDesc}</div>
           { pagesList }
        </div>
        <SingleModernPage 
          page= { this.state.showThisItem }
          showCanvasContent1= { this.state.showCanvasContent1 }
          source= { source }
          refreshId= { refreshId  }
          canvasOptions= { canvasOptions }
          imageStyle= { this.imageStyle }
          debugMode= { this.props.debugMode }
          searchText={ this.state.searchText }
        />
      </div>;

      const userPanel = this.state.showItemPanel !== true ? null : <div><Panel
        isOpen={ this.state.showItemPanel === true ? true : false }
        // this prop makes the panel non-modal
        isBlocking={true}
        onDismiss={ this._onClosePanel.bind(this) }
        closeButtonAriaLabel="Close"
        type = { PanelType.large }
        isLightDismiss = { true }
        >
        <SingleModernPage 
          page= { this.state.showThisItem }
          showCanvasContent1= { true }
          source= { source }
          refreshId= { refreshId  }
          canvasOptions= { canvasOptions }
          imageStyle= { this.imageStyle }
          debugMode= { this.props.debugMode }
          searchText={ this.state.searchText }
        />
      </Panel></div>;

      const debugContent = this.props.debugMode !== true ? null : <div style={{ cursor: 'default', marginLeft: '20px' }}>
        App in debugMode - Change in Web Part Properties - Page Preferences.  <b><em>Currently in ModernPage</em></b>
      </div>;

      return (
        // <div className={ styles.alvFinMan }>
        <div className={ null }>
          {/* <div className={ stylesM.pagesPage }> */}
          <div className={ null }>
            {/* <div className={ styles.row }> */}
              {/* <div className={ styles.column }> */}
                { debugContent }
                { page }
                { userPanel }
              {/* </div> */}
            {/* </div> */}
          </div>
        </div>
      );

    }

  }

  //getDocWiki( item: IPagesContent, source: ISourcePropsFM,  canvasOptions: ICanvasContentOptions, callBack: any )
  private updateModernState( item: IPagesContent, showCanvasContent1: boolean ): void  {

    this.setState({ 
      showItemPanel: showCanvasContent1 === false ? true : false, 
      showCanvasContent1: showCanvasContent1, 
      showThisItem: item });

  }
  
  private async clickNewsItem( ID: number, category: string, item: IPagesContent, e: any ) : Promise<void> {  //this, item.ID, 'pages', item
    console.log('clickNewsItem:', ID, item );
    // debugger;

    const { showSearch, showPublishDate, pages, source, refreshId, canvasOptions } = this.props;

    const newState = this.state.showItemPanel;

    if ( e.altKey === true ) {
      // newState = this.state.showItemPanel === true ? false : true;
      const showCanvasContent1 = e.ctrlKey === true ? true : false;
      await getDocWiki( item , source, canvasOptions, showCanvasContent1, this.updateModernState.bind( this ) );

    } else if ( e.ctrlKey === true && item.File ) {
      window.open( item.File.ServerRelativeUrl , '_blank' );
      this.setState({ showThisItem: item, showItemPanel: newState });

    } else if ( this.state.showCanvasContent1 === true ) {
      await getDocWiki( item , source, canvasOptions, true, this.updateModernState.bind( this ) );

    } else if ( canvasOptions.pagePreference === 'tab' && item.File ) {
      window.open( item.File.ServerRelativeUrl , '_blank' );
        this.setState({ showThisItem: item, showItemPanel: newState });

      } else {
        this.setState({ showThisItem: item, showItemPanel: newState });
      }


  }

  private _onClosePanel( ): void  {
    this.setState({ showItemPanel: false });
  }

}
