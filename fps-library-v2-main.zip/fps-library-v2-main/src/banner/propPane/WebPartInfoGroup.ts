// was src\Services\PropPane\zReusablePropPane.ts

import {
  PropertyPaneLink, PropertyPaneToggle
} from '@microsoft/sp-property-pane';

import { fpsLogo326 } from '../../components/atoms/SVGIcons/fpsLogo326';

import { IRepoLinks } from '../../components/atoms/Links/CreateLinks';
import { IThisFPSWebPartClass } from '../FPSWebPartClass/IThisFPSWebPartClass';

/**
 *
 * @param gitLinks 
 * @param shortDescription 
 * @param PropertyPaneWebPartInformation import { PropertyPaneWebPartInformation } from '@pnp/spfx-property-controls/lib/PropertyPaneWebPartInformation';
 * @returns 
 */
export function WebPartInfoGroup( thisWPClass: IThisFPSWebPartClass, shortDescription: any, PropertyPaneWebPartInformation: any ) {

  const gitLinks = thisWPClass._repoLink;
  const allowPropsEasyMode = thisWPClass._allowPropsEasyMode ? true : false;// Allows for auto expanding WebPartInfoGroup on opening the prop pane if desired;

  let infoGroup = { groupName: 'Web Part Info',
  isCollapsed: thisWPClass._wpInfoGroupExpanded === true && ( allowPropsEasyMode === true || thisWPClass.properties.propsEasyMode === true )  ? false : true ,
  groupFields: [
    PropertyPaneWebPartInformation({
      description: `<img src='${fpsLogo326}'/>`,
      key: 'webPartInfoId'
    }) ,
    PropertyPaneWebPartInformation({
      description: `<p><i>"If you change the way you look at things, the things you look at change."</i></p>`,
      key: 'webPartInfoId2'
    }) ,
  /*
    PropertyPanePropertyEditor({
      webpart: this,
      key: 'propertyEditor'
    })  ,
  */
    PropertyPaneWebPartInformation({
      description: shortDescription,
      key: 'webPartInfoId3'
    }) ,

    PropertyPaneLink('About Link' , {
      text: 'Github Repo:  ' + gitLinks.desc ,
      href: gitLinks.href,
      target: gitLinks.target,
    }),

    PropertyPaneLink('Issues Link' , {
      text: 'Report Issues:  ' + gitLinks.desc ,
      href: gitLinks.href  + '/issues',
      target: gitLinks.target,
    }),

  ]
  };

  if ( allowPropsEasyMode === true ) {
    infoGroup.groupFields.push(
      // propsEasyMode
      PropertyPaneToggle('propsEasyMode', {
        label: 'Easy Mode - Property Pane options',
        onText: 'Easy Mode - Keep it simple mode',
        offText : 'Complex - All options',
      })
    )
  }

  return infoGroup;

}
