
export const TrickyTenantA: string = "}$ju=<n";
export const TrickyTenantC: string = "_/+#1/(~joe";
export const TrickyTenants: string[] = [TrickyTenantA, TrickyTenantC];
export const TrickyAZ : string = "me+us)($e<)l"; // jk: azure
export const TrickySPA : string = "yes#a)qoe.}l";// pab : spa

export const TrickyBK : string = "(ee<zeo~jez";// : bk
export const TrickyCMc : string = "+#1/(7o.+/=<+]g|)}";// mmc

export const TrickyMX : string = "+ee#a~o|e$m<=#a";// car: mx
export const TrickyAMX : string = '}#cuo.}}j<zol';// am: mx


export const TrickyMM : string = "_<(ooz1._oe.}l";// mz
export const TrickyMMc : string = "1]))_/+#1/(~joe";// mmc

export const TrickyFR : string = "yej}1/()=7+<e";// pl: fr
export const TrickyOO : string = "g$j|q<y-alp)(u)|ge~ez&($=w}$ju=<n)+u_";// sutt: 0
export const TrickyPONG : string = "gueeyu=)jez|17}nalpw}$ju=<n)+u_";// sorap: tan
export const TrickySUK : string = "zejg}}}lp)g$(uz|}l}|>ev|a#1yo/a.";// nat: suk
export const TrickyQA : string = "joe}1)g/ay1#=w}$ju=<n)+u_";// qa: Recs ts

export const ContALVFMContent: string = 'Rupoe E#_9eu'; //re title - used for label
export const ContALVFMWebP: string = 'M<(o Z1._oe.}l'; //mm - used for label

export const trickyAnalytics : string[] = [
  TrickySPA,// : spa
  TrickyBK,// : bk
  TrickyMM,// : mz
  TrickyMMc,// : mmc
  TrickyCMc,// : cmc
]

export const alwaysTricky: string [] = [
  TrickyAZ,// : azure
  TrickySPA,// : spa
  TrickyBK,// : bk
  TrickyCMc,// : cmc
  TrickyMM,// : mz
  TrickyMMc,// : mmc
];

export const allSP: string [] = [
  TrickyAZ,// : azure
  TrickySPA,// : spa
  TrickyBK,// : bk
  TrickyCMc,// : cmc
  TrickyMM,// : mz
  TrickyMMc,// : mmc
  TrickyMX,// c: mx
  TrickyAMX, // a: mx
  TrickyFR,// fr
  TrickyPONG,// tan
  TrickySUK,// suk
  TrickyQA,// 
];

export const alleXt: string [] = [
  TrickyAZ,// : azure
  TrickySPA,// : spa
  TrickyBK,// : bk
  TrickyCMc,// : cmc
  TrickyMM,// : mz
  TrickyMMc,// : mmc
  TrickyMX,// c: mx
  TrickyAMX, // a: mx
  TrickyFR,// m
  TrickyFR,// fr
  TrickyOO,// 0
  TrickyPONG,// tan
  TrickySUK,// suk
  TrickyQA,// 
];

export const allEC: string [] = [
  TrickyAZ,// : azure
  TrickySPA,// : spa
  TrickyBK,// : bk
  TrickyCMc,// : cmc
  TrickyMM,// : mz
  TrickyMMc,// : mmc
  TrickyFR,// fr
];


export const TrickyALVFM1 : string = "eupoe))#_9eu>ev|a#1yo/a.";// re
export const TrickyALVFM2 : string = "muzej-}lo#vlc9)}pw}$ju=<n)+u_";// jl

export const allALVFM: string [] = [
  TrickyAZ,// : azure
  TrickySPA,// : spa
  TrickyBK,// : bk
  TrickyCMc,// : cmc
  TrickyMM,// : mz
  TrickyMMc,// : mmc
  TrickyALVFM1,// re
  TrickyALVFM2,// jl
];

export const allCompliance: string [] = [
  TrickyAZ,// : azure
  TrickySPA,// : spa
  TrickyBK,// : bk
  TrickyCMc,// : cmc
  TrickyMM,// : mz
  TrickyMMc,// : mmc
  TrickyMX,// : mx
  TrickyFR,// m
  TrickyFR,// fr
  TrickyOO,// 0
  TrickyPONG,// tan
  TrickySUK,// suk
  TrickyQA,// 
];