
export const decrpt : string = 'fghim3b%(tu^cd4epq)=n_6o+[]w2a,r7sx{}5y~zjklv.#&-8*/19|<0>$!@';
export const encrpt : string = 'wpq1_rshijv4+cx)y#][z%7abd3~0}{efgk^tu6,lm(=no85/@$|*!92.<-&>';


