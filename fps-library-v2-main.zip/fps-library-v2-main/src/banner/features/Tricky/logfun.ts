/**
 * See full file in C:\Users\me\OneDrive...\SharePoint
 */

// Need to add:  ?{}[],

import { allSP, TrickyTenantA, TrickyTenantC, TrickyTenants } from './constants';

import { decrpt, encrpt } from './verify';
/**
 * usage:  testTricky(['test string1','test string2','test string3'])
 * return:  [ true, false, true ]
 * @param tests 
 */

export function testTenantA() {
  let testLarge = ecrptMe( window.location.hostname);
  let test = testLarge.indexOf( TrickyTenantA );
  return test > -1 ? true : false;
}


export function testTenantC() {
  let testLarge = ecrptMe( window.location.hostname);
  let test = testLarge.indexOf( TrickyTenantC );
  return test > -1 ? true : false;
}


export function testTenants() {
  return testTricky( [window.location.hostname], TrickyTenants );
}

/**
 * 
 * @param tests This should be array of longer strings
 * @param testArray This should be array of shorter strings to be found in longer strings
 */
export function testTricky ( tests: string[], testArray: string[] = allSP ){
  let encryptarr: string [] = [];
  let found: boolean [] = [];

  tests.map( original => {
    let testing: string = ecrptMe( original) ;
    let idx: number = testArray.indexOf( testing );
    if ( idx > -1 ) {
      console.log( 'Found: ', idx, original );
      found.push( true );
    } else {
      console.log( 'NOT Found: ', idx, original );
      found.push( false );
    }
    encryptarr.push( testing );
  });
  
  console.log('Finished!',tests,encryptarr);
  console.log('results:',found);
  return found;

}

function isOdd(num: number) { return (num % 2) == 1;}

// export function ecrptMe( str: string ) {
export function ecrptMe( str: string, key1: string = decrpt, key2: string = encrpt ) {
  let result: string = '';

  for (var i = 0; i < str.length; i++) {
    let testChar = str.charAt(i);
    
    let idx = key2.indexOf( testChar ) ;
    //console.log( testChar, i, idx);

    if ( idx === -1 ) {
      result += testChar;
    } else if ( isOdd(i) === true ){
      result += key1.charAt(key1.length -1 - idx);
    } else {
      result += key1.charAt(idx);
    }
  }
  return result;
}

// export function ecrptMe( str: string ) {
  export function dcrptMe( str: string, ) {
    let result = '';
    for (var i = 0; i < str.length; i++) {
      let testChar = str.charAt(i);
      let idx = encrpt.indexOf( testChar );
      
      //let idx = isOdd(1) ? decript.indexOf(str.charAt(i)) : decript.lastIndexOf(str.charAt(i));
      if ( idx === -1 ) {
        result += testChar;
      } else if ( isOdd(i) === true ){
        result += decrpt.charAt(decrpt.length - 1 - idx);
      } else {
        result += decrpt.charAt(idx);
      }
    }
    return result;
  }