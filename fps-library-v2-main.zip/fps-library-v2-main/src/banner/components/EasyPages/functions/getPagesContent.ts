import { sortObjectArrayByStringKeyCollator } from "../../../../logic/Arrays/sorting/objects";
import { IEasyLink } from "../components/componentPage";

//Interfaces
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { EasyPagesSysTab, ISourcePropsEP } from '../interfaces/epTypes'; //SourceInfo, 

import { createBasePerformanceInit, startPerformOp, updatePerformanceEnd } from '../../../../components/molecules/Performance/functions';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { ILoadPerformance, } from '../../../../components/molecules/Performance/IPerformance';
// import { warnMutuallyExclusive } from 'office-ui-fabric-react';

import { EasyIconObjectDefault, IEasyIcons,  } from "../../../../components/atoms/EasyIcons/interfaces/eiTypes";
import { addEasyIcons, } from "../../../../components/atoms/EasyIcons/functions/getEasyIcon";
import { getSourceItems, } from "../../../../pnpjs/SourceItems/getSourceItems";
import { IFpsItemsReturn } from "../../../../pnpjs/Common/CheckItemsResults";
import { addSearchMeta1 } from "../../../../components/molecules/SearchPage/functions/addSearchMeta1";

/**
 * This returns only tabs that were found and in the original order provided by props.
 * @param sourceProps 
 * @param items 
 * @returns 
 */
export function getUsedTabs( sourceProps: ISourcePropsEP, items: IEasyLink[] ) : string[] {
  const foundTabs: string[] = [];
  let showOverFlow: any = false;
  let systemTab: any = false;  //  https://github.com/mikezimm/drilldown7/issues/280

  items.map( item => {
    item.tabs.map( tab => {

      if ( tab === EasyPagesSysTab ) {
        systemTab = true;  //  https://github.com/mikezimm/drilldown7/issues/280

      } else if ( foundTabs.indexOf( tab ) < 0 ) {
        foundTabs.push( tab );

      } else if ( tab === sourceProps.EasyPageOverflowTab ) {
        showOverFlow = true;
      }

    } );
  });

  const sortedTabs: string[] = [];
  sourceProps.meta1?.map( tab => { if ( foundTabs.indexOf( tab ) > -1 ) sortedTabs.push( tab ) ;} );
  if ( showOverFlow === true && sourceProps.EasyPageOverflowTab ) sortedTabs.push( sourceProps.EasyPageOverflowTab );
  if ( systemTab === true ) sortedTabs.push( EasyPagesSysTab );  //  https://github.com/mikezimm/drilldown7/issues/280
  // Per chatGPT suggested link:  https://www.technicalfeeder.com/2021/07/8-ways-to-remove-duplicates-from-an-array/#toc6
  return Array.from(new Set(sortedTabs));  
  // return sortedTabs;

}

/**
 * This gets Site Pages content, based on ALVFinMan7 model
 * @param sourceProps 
 * @returns 
 */
export interface IGetPagesContent { items: IEasyLink[], performance: ILoadPerformance, errMessage: string }

export async function getPagesContent( sourceProps: ISourcePropsEP, EasyIconObject: IEasyIcons = EasyIconObjectDefault, parentLink: string, ): Promise<IGetPagesContent> {

  //"List 'Site Pages' does not exist at site with URL
  const performance: ILoadPerformance = createBasePerformanceInit( 1, false, );
  performance.ops.fetch1 = startPerformOp( 'fetch1 - getPages', null, true );  // https://github.com/mikezimm/Slick-Sections/issues/69

  const fetchResults: IFpsItemsReturn = await getSourceItems( sourceProps, false, true );

  // eslint-disable-next-line @typescript-eslint/no-unused-vars, prefer-const
  let { items, errorInfo, } = fetchResults;

  if ( errorInfo && errorInfo.returnMess.indexOf(`"List 'Site Pages' does not exist`) > 1 ) alert( `I'm sorry, this site does NOT have a library Titled 'Site Pages :(`);

  performance.ops.fetch1 = updatePerformanceEnd( performance.ops.fetch1, true, items.length );

  if ( parentLink ) items.push( //'Title','Description','Author/Title','Editor/Title','File/ServerRelativeUrl','BannerImageUrl'
    {
      Title: '.. ^ Go to Parent Site',
      Description: 'Quick link to parent site Home page',
      File: { ServerRelativeUrl: parentLink },
      type: 'current',
    } as any
  );

  performance.ops.analyze1 = startPerformOp( 'analyze1 - addSearchMeta', null, true );  // https://github.com/mikezimm/Slick-Sections/issues/69
  items = addSearchMeta1( items, sourceProps, null );
  // This should not be required because addEasyIcons already filters out 'SharePoint' and 'Files'
  // EasyIconObject.GroupKeys = EasyIconObject.GroupKeys.filter( key => { return key !== 'SharePoint' } );
  items = addEasyIcons( items, sourceProps, EasyIconObject );

  performance.ops.analyze1 = updatePerformanceEnd( performance.ops.analyze1, true, items.length );

  items = sortObjectArrayByStringKeyCollator( items, 'asc', 'title', true, 'en' );

  // eslint-disable-next-line no-eval
  if ( sourceProps.evalFilter ) items = items.filter( item => eval( sourceProps.evalFilter ? sourceProps.evalFilter : '' ) === true );

  console.log( sourceProps.defType, sourceProps.listTitle , items );

  return { items: items as IEasyLink[], performance: performance, errMessage: errorInfo ? errorInfo.returnMess : '' };

}


