import { IEasyLink } from "../components/componentPage";

/**
 * This filters first by a meta string and then by text search string
 * @param items
 * @param MetaFilter
 * @param SearchString
 * @returns
 */

export function compoundArrayFilter(items: IEasyLink[], MetaFilter: string, SearchString: string): IEasyLink[] {

  const SearchStringLc = SearchString.toLocaleLowerCase();

  const links: IEasyLink[] = !MetaFilter ? items : items.filter((link) => link.tabs.indexOf(MetaFilter) > -1);

  let filtered: IEasyLink[] = [];

  if (!SearchStringLc) {
    filtered = links;

  } else {

    links.map((item: IEasyLink) => {
      const textFound: number = !SearchStringLc ? 0 : item.FPSItem.Search.searchTextLC.indexOf(SearchStringLc);
      if (textFound > -1)
        filtered.push(item);
    });

  }

  return filtered;
}
