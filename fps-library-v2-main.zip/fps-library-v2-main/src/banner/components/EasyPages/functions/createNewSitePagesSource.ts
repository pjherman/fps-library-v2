import { ISourceName } from "../components/componentPage";
import { ISourcePropsEP, EasyPagesSysTab, EasyPagesDevTab, DefaultOverflowTab } from "../interfaces/epTypes";
import { SitePagesSource } from "../../../../pnpjs/SourceItems/SitePages/SitePagesSource";

//export type ISourceName = 'Current' | 'Parent' | 'Alternate' | typeof EasyPagesDevTab | typeof EasyPagesRepoTab ;

export function createNewSitePagesSource(source: ISourceName, webUrl: string | undefined, tabs: string[], EasyPageOverflowTab: string | undefined, showTricks: boolean): ISourcePropsEP {

  const NewSource: ISourcePropsEP = JSON.parse(JSON.stringify(SitePagesSource));
  NewSource.webUrl = webUrl ? webUrl : '';
  // 2023-07-07: Add filter to remove duplicates
  NewSource.meta1 = tabs.filter((value, index) => tabs.indexOf(value) === index);
  if ( NewSource.meta1.indexOf( EasyPagesSysTab ) < 0 ) NewSource.meta1.push(EasyPagesSysTab);
  if (showTricks === true && NewSource.meta1.indexOf(EasyPagesDevTab) < 0)
    NewSource.meta1.push(EasyPagesDevTab);
  NewSource.EasyPageOverflowTab = EasyPageOverflowTab ? EasyPageOverflowTab : DefaultOverflowTab;

  // console.log( `epTypes createNewSitePagesSource ${source}`, JSON.parse(JSON.stringify(NewSource)) );
  return NewSource;

}
