
// import { ISourceProps } from "../../../pnpjs/SourceItems/index";
import { IEveryoneAudience } from "../../../../common/interfaces/fps/AudienceInterfaces";
import { ISourceProps } from "../../../../pnpjs/SourceItems/Interface";
// import { IEveryoneAudience } from "../../../propPane/Audiences/Interfaces";

// Just extending generic one and using EasyPageOverflowTab to match the object name because
// Different sources may have different prop keys to match prop pane and differentiate from each other.

export interface ISourcePropsEP extends ISourceProps {
  EasyPageOverflowTab?: string;
}
/**
 * Minimum interface into Main Web Part Properties needed to use this feature
 */
//To be added to npmFunctions
export interface IEasyPagesWPProps {
  EasyPagesAudience: IEveryoneAudience;
  EasyPageOverflowTab?: string;

  EasyPagesEnable: boolean;
  EasyPageTabsC: string;

  EasyPageParent?: boolean; //Include parent site pages
  EasyPageTabsP: string;

  EasyPageUrlA?: string; //Include alternate site's site pages
  EasyPagesSiteTitleA?: string;  // Button Text for Alternate Site
  EasyPageTabsA: string;

  EasyPageUrlB?: string; //Include 2nd alternate site's site pages
  EasyPagesSiteTitleB?: string;  // Button Text for 2nd Alternate Site
  EasyPageTabsB: string;

  // easyPageAltNav?: string; //Include navigation elements from other site
  // easyPageSeparateExtras?: boolean; //Put Parent/Alt links in separate tab ( default )

  EasyPageStyles?: string;  //Optional styles on entire page
  EasyPageContainerStyles?: string;  //Optional styles on container element
}

export const changeEasyPages: string[] = ['EasyPagesEnable', 'EasyPagesAudience', 'EasyPageTabsC', 'EasyPageOverflowTab', 
  'EasyPageParent', 'EasyPageTabsP', 'EasyPageUrlA', 'EasyPageTabsA', 'EasyPagesSiteTitleA', 'EasyPageStyles', 'EasyPageContainerStyles'];

// Shortcuts:  https://github.com/mikezimm/fps-library-v2/issues/49
export const DefaultEasyPagesTabs: string[] = [ 'Shortcuts', 'Home', 'Help', 'Training', 'Links', 'Drilldown', 'Contents', 'Admin' ];

//https://github.com/mikezimm/drilldown7/issues/280
export const EasyPagesCCSPages: string[] = [
  'CCSBrandingSettings',
  'CCSDisplayForm',
  'CCSEditForm',
  'CCSNewForm',
  'CCSMSTeamsUtils',
  'Workflow-Errors-Dashboard',
  'Workflow-Logs-Dashboard',
];

export const EasyPagesSysPages: string[] = [
  ...EasyPagesCCSPages,
  ...[ ],
];

//https://github.com/mikezimm/drilldown7/issues/280
export const EasyPagesSysTab = 'System';
export const EasyPagesDevTab = 'zDev';
export const EasyPagesRepoTab = 'zGit';
export const EasyPagesAnalTab = 'Analytics';
export const DefaultOverflowTab = 'Others';
