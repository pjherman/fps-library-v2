import * as React from 'react';
import { WebPartContextCopy_15_2 } from '../../../../common/interfaces/@msft/1.15.2/WebPartContext';
import { ISupportedHost } from '../../../../common/interfaces/@msft/1.15.2/layout';
import { IPinMeState } from "../../../features/PinMe/Interfaces";
import { ISourcePropsEP } from './epTypes';
import { IRepoLinks } from '../../../../components/atoms/Links/CreateLinks';
import { ISourceName } from '../components/componentPage';

// Moved out for easier compatibility with analyticsPage

export interface IEasyPagesPageProps {
  expandedState: boolean; //Is this particular page expanded
  tabs: string[]; // Tabs for Current site
  source: ISourcePropsEP;
  sourceName: ISourceName;
  parentUrl: string;

}

export interface IEasyPagesSourceProps {

  context: WebPartContextCopy_15_2; // WebPartContext;  Set as any for now:  import { WebPartContext } from '@microsoft/sp-webpart-base';
  pageLayout: ISupportedHost; //  SharePointFullPage

  pinState: IPinMeState; // To be used when rebuilding the Banner and FetchBanner components

  styles?: React.CSSProperties; //Optional styles on entire page
  containerStyles?: React.CSSProperties; //Optional styles on container element

  repo: IRepoLinks; //This can eventually be taken from bannerProps directly
}
