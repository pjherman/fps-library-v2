import { IZFetchedAnalytics } from '../interfaces/IStateSourceA';

export function getPageTitle(item: IZFetchedAnalytics): string {
  if (!item) { console.log(`EasyAnalytics ERROR: getPageTitle item is undefined!`, item); return undefined; }
  const { PageLink, PageURL } = item;
  let result = PageLink && PageLink.Description.indexOf('.aspx') > 0 ? PageLink.Description : PageURL && PageURL.indexOf('.aspx') > 0 ? PageURL.substring(PageURL.lastIndexOf('/') + 1) : '';
  return result;
}
