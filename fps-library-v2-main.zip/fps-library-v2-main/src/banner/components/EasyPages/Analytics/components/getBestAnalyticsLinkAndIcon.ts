import { IZFetchedAnalytics } from '../interfaces/IStateSourceA';
import { addGulpParam, removeGulpParam } from '../../../../../components/atoms/Links/GulpLinks';
import { gulpParam1, ProcessingRunIcon } from './Row';

export interface IAnalyticsLinkIcon {
  linkUrl: string;
  iconName: string;
}

export type IAnalyticsLinkIconPriority = 'PageURL' | 'PageLink' | 'SiteLink';

export function getBestAnalyticsLinkAndIcon(item: IZFetchedAnalytics, gulpMe: boolean, priority: IAnalyticsLinkIconPriority[]): IAnalyticsLinkIcon {

  const result: IAnalyticsLinkIcon = {
    linkUrl: '',
    iconName: '',
  };

  let foundBest: boolean = false;
  priority.map((col: IAnalyticsLinkIconPriority) => {
    if ( foundBest === true ) {
      // Already found first choice... do nothing more.

    } else if (col === 'PageURL' && item.PageURL) {
      result.linkUrl = gulpMe === true ? `${item.PageURL}?${gulpParam1}` : item.PageURL;
      result.iconName = gulpMe === true ? ProcessingRunIcon : 'Page';
      foundBest = true;

    } else if (col === 'PageLink' && item.PageLink) {
      result.linkUrl = gulpMe === true ? addGulpParam(item.PageLink.Url) : removeGulpParam(item.PageLink.Url);
      result.iconName = gulpMe === true ? ProcessingRunIcon : 'Page';
      foundBest = true;

    } else if (col === 'SiteLink' && item.SiteLink) {
      result.linkUrl = gulpMe === true ? `${item.SiteLink.Url}?${gulpParam1}` : item.SiteLink.Url;
      result.iconName = gulpMe === true ? ProcessingRunIcon : 'SharepointLogo';
      foundBest = true;
    }
  });

  return result;

}
