/* eslint-disable dot-notation */

import * as React from 'react';

import { getHighlightedText } from '../../../../../components/atoms/Elements/HighlightedText';
import { ISourceRowRender } from '../../../../../components/molecules/SourcePage/ISourceRowRender';
import { IOjbectKeySummaryItem } from '../functions/summarizeArrayByKey';
import { IAnySourceItem } from '../../../../../components/molecules/AnyContent/IAnyContent';
import { checkDeepProperty } from '../../../../../logic/Objects/deep';
import { getSumableNumber } from '../../../../../logic/Math/getNumber';

require ('@mikezimm/fps-styles/dist/easyAnalytics.css');
require ('@mikezimm/fps-styles/dist/fpsGeneralCSS.css');

export const ezAnalyticsBarHeaders: string[] = [ 'Item', 'Count I/T', 'Count pareto', 'Fetch-Avg', 'TBD-Sum', ];

export function createBarsRow( props: ISourceRowRender ): JSX.Element { 
  const { item, onClick, searchText } = props; 

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const thisItem: IOjbectKeySummaryItem = item as any;

  const { primaryKey, percentB, countI, countT, link } = thisItem;

  let sumFetch = 0;
  let cntFetch = 0;

  if ( thisItem.items ) {
    thisItem.items.map( ( barItem ) => {
      return checkDeepProperty( barItem, 'performanceObj.ops.fetch9.ms'.split('.'), 'Actual', false );
    }).map( v => {
      if (typeof v === 'number' || typeof v === 'bigint' ) {
        sumFetch += getSumableNumber( v );
        cntFetch ++;
      }
    });
  }
  const avgFetch = cntFetch !== 0 ? Math.round( sumFetch/cntFetch ): `-na-`;

  const isLink: boolean = link || thisItem.keyZ !== 'createdAge' ? true : false;
  const countVal = countI === countT ? `${countI}` : `${ countI } / ${ countT }`;
  const row = <tr className={ 'ezAnalyticsBarRow' } onClick = { ( event ) => onClick( -1 , 'generic', item, event ) }>
    <td className={ isLink === true ? 'fps-gen-goToLink' : '' } title={ link }
      onClick= { isLink === true ? () => props.onParentCall( 'GoToItems', -1, '', item ) : undefined } >{ getHighlightedText( primaryKey, searchText ) }</td>
    <td style={ { paddingRight: '20px', whiteSpace: `nowrap` } } >{ countVal }</td>
    <td title={ null } className={ 'ezAnalyticsBarCell' } ><div className={ 'eazyBar' } style={{ 'width': `calc(${percentB}% - 20px)` } }/></td>
    <td style={ { paddingRight: '20px', whiteSpace: `nowrap` } } >{ avgFetch } ms</td>
  </tr>;

  return row;

}
