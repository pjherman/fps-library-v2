import { IAnySourceItem } from "../../../../../components/molecules/AnyContent/IAnyContent";
import { IStateSource } from "../../../../../pnpjs/Common/IStateSource";
import { IZFullAnalytics } from "../../../../../pnpjs/Logging/Interfaces/analytics";

// let finalSaveObject: IZFullAnalytics = saveOjbectCopy;
export interface IZFetchedAnalytics extends IZFullAnalytics {
  performanceObj?: any;
  FPSPropsObj?: any;
}

export interface IStateSourceA extends IStateSource {
  items: IZFetchedAnalytics[];
  itemsA: any[];
  itemsS: any[];
  itemsO: any[];
  itemsP: any[];

}
