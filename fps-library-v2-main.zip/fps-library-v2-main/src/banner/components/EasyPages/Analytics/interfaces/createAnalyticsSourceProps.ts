import { ISourceProps } from "../../../../../pnpjs/SourceItems/Interface";
import { createSeriesSort } from "../../../../../pnpjs/SourceItems/createOrderBy";
import { AnalyticsWeb } from "../../../../../pnpjs/Logging/Interfaces/constants";
import { prepSourceColumns } from "../../../../../pnpjs/SourceItems/prepSourceColumns";

export function createAnalyticsSourceProps(analyticsListX: string,  analyticsWebX: string = AnalyticsWeb ): ISourceProps {

  const key: string = `analytics`;
  const AnalyticsSourceProps: ISourceProps = prepSourceColumns( {
    key: key,
    defType: key,
    webUrl: `${window.location.origin}${analyticsWebX}`,// /${analyticsListX}
    webRelativeLink: `/lists/${analyticsListX}`,
    searchSource: key,
    searchSourceDesc: key,
    listTitle: analyticsListX,
    columns: [ '*', ],
    searchProps: [ 'ID', 'Author/Title','Author/Office', 'SiteTitle', 'language', 'CodeVersion' ],
    selectThese: ['*', 'Author/Title','Author/Office', 'performance' ],
    isModern: true,
    defSearchButtons: [],
    orderBy: createSeriesSort( 'Id', false ),
    fetchCount: 5000,
    performanceSettings: { label: 'analytics', updateMiliseconds: true, includeMsStr: true, op: 'fetch' },
    fpsContentType: [ 'item' ],
  }, null );

  return AnalyticsSourceProps;

}
