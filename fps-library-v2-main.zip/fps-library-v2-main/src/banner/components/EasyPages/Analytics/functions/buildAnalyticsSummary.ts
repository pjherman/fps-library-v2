import { IFPSEnviro } from "../../../../../common/interfaces/fps/IFPSEnviro";
import { addDeepPropsToSearch } from "../../../../../components/molecules/SearchPage/functions/addDeepPropsToSearch";
import { addSearchMeta1 } from "../../../../../components/molecules/SearchPage/functions/addSearchMeta1";
import { getDeepValuesStringArray } from "../../../../../logic/Objects/deep";
import { IFPSUser } from "../../../../../logic/Users/IUserInterfaces";
import { ISourceProps } from "../../../../../pnpjs/SourceItems/Interface";
import { retrieveFPSUser } from "../../../../FPSWebPartClass/functions/showTricks";
import { retrieveFPSEnviro } from "../../../../features/FPSDOM/FPSEnviro";
import { getPageTitle } from "../components/getPageTitle";
import { IStateSourceA, IZFetchedAnalytics } from "../interfaces/IStateSourceA";

export function buildAnalyticsSummary( AnalyticsSourceProps: ISourceProps, stateSource: IStateSourceA, wpFilterProps: string[] ): IStateSourceA {
  // DO something here to summarize
  const FPSUser: IFPSUser = retrieveFPSUser();
  const FPSEnviro: IFPSEnviro = retrieveFPSEnviro();
  const currentSiteLC: string = FPSEnviro.siteUrl.toLowerCase();

  let isMine: any = false, isOthers: any = false, isThisSite: any = false, isOtherSite: any = false;

  stateSource.items = addSearchMeta1( stateSource.items, AnalyticsSourceProps, null ) as IZFetchedAnalytics[];

  stateSource.itemsS = [];
  stateSource.itemsO = [];
  stateSource.itemsP = [];

  if ( !stateSource.meta1  ) stateSource.meta1 = [];
  if ( !stateSource.meta2  ) stateSource.meta2 = [];

  stateSource.items.map( ( item ) => {
    let { searchTextLC, searchText, } = item.FPSItem.Search;
    if ( item['Author/Title'] === FPSUser.Title ) { searchText += ` || Mine`; isMine = true }
    else { searchText += ` || OtherPeeps`; isOthers = true }

    // if ( item['Author/Title'] === FPSUser.Title ) { searchTextLC += ` || Mine` }
    //   else { item.FPSItem.SearchLC += ` || Others` }

    if ( item.SiteLink && item.SiteLink.Url.toLowerCase().indexOf( currentSiteLC ) > -1 ) 
      { searchText += ` || ThisSite`; isThisSite = true }
    else { searchText += ` || OtherSites`; isOtherSite = true }

    if ( item.language && stateSource.meta2.indexOf( item.language ) < 0 ) stateSource.meta2.push( item.language );

    if ( item.performance ) {
      try {
        item.performanceObj = JSON.parse( item.performance );
      } catch(e) {  }
    }
    if ( item.FPSProps ) {
      try {
        item.FPSPropsObj = JSON.parse( item.FPSProps );
      } catch(e) {  }
    }

    const PageTitle = getPageTitle( item );

    if ( PageTitle ) searchText = searchText + ` || ` +  PageTitle;
    item.FPSItem.Search.searchText = searchText;
    item.FPSItem.Search.searchTextLC = searchText.toLowerCase();

    // Added search for extra Search Buttons
    const wpFilterPropVals = getDeepValuesStringArray( item, wpFilterProps );

    // This will add the filtered values to stateSource.meta array if they are not already there.
    wpFilterPropVals.map( (v: string ) => { if ( stateSource.meta1.indexOf( v ) < 0 ) stateSource.meta1.push( v ) } );

    // This will update FPSItem.Search searchString on the item with the latest deep values.
    item = addDeepPropsToSearch( wpFilterPropVals, item ) as IZFetchedAnalytics;

  });

  if ( isMine === true ) stateSource.meta1.push( 'Mine' );
  if ( isOthers === true ) stateSource.meta1.push( 'OtherPeeps' );
  if ( isThisSite === true ) stateSource.meta1.push( 'ThisSite' );
  if ( isOtherSite === true ) stateSource.meta1.push( 'OtherSites' );

  stateSource.itemsA = [];
  return stateSource;
}


