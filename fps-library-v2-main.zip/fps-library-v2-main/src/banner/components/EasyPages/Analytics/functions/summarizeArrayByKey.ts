
import { IPerformanceOp } from "../../../../../components/molecules/Performance/IPerformance";
import { IPerformanceSettings } from "../../../../../components/molecules/Performance/IPerformanceSettings";
import { startPerformOpV2, updatePerformanceEndV2 } from "../../../../../components/molecules/Performance/functions";
import { IAnySourceItem, IAnySourceItemAny, IFPSItem } from "../../../../../components/molecules/AnyContent/IAnyContent";
import { makeid } from "../../../../../logic/Strings/guids";
import { sortObjectArrayByNumberKey } from "../../../../../logic/indexes/ArraySortingNumbers";
import { IUnifiedPerformanceOps } from "../../../../../pnpjs/Common/IFpsErrorObject";
import { getBestAnalyticsLinkAndIcon } from "../components/getBestAnalyticsLinkAndIcon";
import { IZFetchedAnalytics } from "../interfaces/IStateSourceA";
import { check4This } from "@mikezimm/fps-pnp2/lib/services/sp/CheckSearch";
import { checkDeepProperty } from "../../../../../logic/Objects/deep";
import { getSumableNumber } from "../../../../../logic/Math/getNumber";
import { EmptyFPSItemSearch } from "../../../../../components/molecules/AnyContent/IFPSItemSearch";

export interface IOjbectKeySummaryItem {
  primaryKey: string;
  link?: string;
  countT: number; // count of items that are included in the summary
  countI: number; // items that actually have a value in the key
  countV: number; // items that actually have a value in the key
  percentT: number; // percent of total items
  percentV: number; // percent of total value
  percentB: number; // percent of max bar length ( largest value in summary )
  sum: number;
  avg: number;
  labelV: string;
  FPSItem: IFPSItem;
  // searchTextLC: string;
  items: IAnySourceItem[];
  key0?: string[];
  key1?: string[];
  key2?: string[];
  key3?: string[];
  key4?: string[];
  key5?: string[];
  keyZ: string;
}

export interface IObjArraySummary {
  keys: string[];
  summaries: IOjbectKeySummaryItem[];
  topLabels: string[];
}

export function createKeyObject(keyZ: string, prime: string, labelV: string, otherKeys: string[]): IOjbectKeySummaryItem {
  prime = prime ? prime : `<< EMPTY ${ keyZ } >>`;
  const result: IOjbectKeySummaryItem = {
    primaryKey: prime,
    link: '',
    countT: 0,
    countI: 0,
    countV: 0,
    percentT: 0,
    percentV: 0,
    percentB: 0,
    labelV: labelV,
    FPSItem: {
      Search: EmptyFPSItemSearch,
      IsA: { allIsAKeys: [] }
    },
    sum: 0,
    avg: 0,
    items: [],
    keyZ: keyZ,
  };
  // create empty arrays as needed
  [ 0,1,2,3,4,5 ].map( num => { 
    if ( otherKeys.length > num ) { 
      result[ `key${num}` as 'key0' ] = [];
    }});

  return result;
}

export interface IAnalyticsSummary {
  Titles: IObjArraySummary;
  Sites: IObjArraySummary;
  Offices: IObjArraySummary;
  Languages: IObjArraySummary;
  Users: IObjArraySummary;
  Dates: IObjArraySummary;
  CodeVersion: IObjArraySummary;
  processOp: IPerformanceOp;
  unifiedPerformanceOps: IUnifiedPerformanceOps;
  refreshId: string;
  stats: {
    Titles: number;
    Sites: number;
    Offices: number;
    Languages: number;
    Users: number;
    Dates: number;
    CodeVersion: number;
    x0: number;
    x1: number;
    x2: number;
    x3: number;
  },

  // Optional custom key summaries
  x0: IObjArraySummary;
  x1: IObjArraySummary;
  x2: IObjArraySummary;
  x3: IObjArraySummary;
}

export function easyAnalyticsSummary( items: IAnySourceItem[], wpFilterProps: string[] ) : IAnalyticsSummary {

  const performanceSettings: IPerformanceSettings = {  label: 'summary', updateMiliseconds: true, includeMsStr: true, op: 'analyze' };
  let processOp = performanceSettings ? startPerformOpV2( performanceSettings ) : null;

  const Titles = summarizeArrayByKey( items, 'Titles', 'Title',[ 'Author/Office', 'Author/Title', 'language', 'CodeVersion' ] );
  const Sites = summarizeArrayByKey( items, 'SiteTitle', 'Title',[ 'Author/Office', 'Author/Title', 'language', 'CodeVersion' ] );
  const Offices = summarizeArrayByKey( items, 'Author/Office', 'Title',[ 'SiteTitle', 'Author/Title', 'language', 'CodeVersion' ] );
  const Languages = summarizeArrayByKey( items, 'language', 'Title',[ 'SiteTitle', 'Author/Title', 'Author/Office', 'CodeVersion' ] );
  const Users = summarizeArrayByKey( items, 'Author/Title', 'Title',[ 'Author/Office', 'SiteTitle', 'language', 'CodeVersion' ] );
  const Dates = summarizeArrayByKey( items, 'createdAge', 'Title',[ 'Author/Office', 'SiteTitle', 'language', 'Author/Title', 'CodeVersion' ] );
  const CodeVersion = summarizeArrayByKey( items, 'CodeVersion', 'Title',[ 'Author/Office', 'SiteTitle', 'language', 'Author/Title', 'createdAge' ] );

  // If there is a filter prop for the index, then build the summary.  Else just copy the Titles one so it has the correct structure.
  const x0 = wpFilterProps.length < 1 ? EmptyObjArraySummary : summarizeArrayByKey( items, wpFilterProps[0], 'Title',[ 'Author/Office', 'SiteTitle', 'language', 'Author/Title', 'createdAge' ] );
  const x1 = wpFilterProps.length < 2 ? EmptyObjArraySummary :summarizeArrayByKey( items, wpFilterProps[1], 'Title',[ 'Author/Office', 'SiteTitle', 'language', 'Author/Title', 'createdAge' ] );
  const x2 = wpFilterProps.length < 3 ? EmptyObjArraySummary :summarizeArrayByKey( items, wpFilterProps[2], 'Title',[ 'Author/Office', 'SiteTitle', 'language', 'Author/Title', 'createdAge' ] );
  const x3 = wpFilterProps.length < 4 ? EmptyObjArraySummary :summarizeArrayByKey( items, wpFilterProps[3], 'Title',[ 'Author/Office', 'SiteTitle', 'language', 'Author/Title', 'createdAge' ] );

  processOp = updatePerformanceEndV2( { op: processOp, updateMiliseconds: performanceSettings.updateMiliseconds, count: items.length * 6 });

  const result: IAnalyticsSummary = {
    Titles: Titles,
    Sites: Sites,
    Offices: Offices,
    Languages: Languages,
    Users: Users,
    Dates: Dates,
    CodeVersion: CodeVersion,
    processOp: processOp,
    unifiedPerformanceOps: { process: processOp },
    refreshId: makeid(5),
    stats: {
      Titles: Titles.keys.length,
      Sites: Sites.keys.length,
      Offices: Offices.keys.length,
      Languages: Languages.keys.length,
      Users: Users.keys.length,
      Dates: Dates.keys.length,
      CodeVersion: CodeVersion.keys.length,
      x0: x0.keys.length,
      x1: x1.keys.length,
      x2: x2.keys.length,
      x3: x3.keys.length,
    },
    x0: x0,
    x1: x1,
    x2: x2,
    x3: x3,
  }

  if ( check4This( 'sourceResults=true' ) === true )  console.log( 'sourceResults easyAnalyticsSummary', result, );

  return result;
}

const EmptyObjArraySummary: IObjArraySummary = {
  keys: [],
  summaries: [],
  topLabels: [],
};

export function summarizeArrayByKey( items: IAnySourceItem[], key: string, valProp: string, otherKeys: string[] ): IObjArraySummary {

  const summary: IObjArraySummary = JSON.parse(JSON.stringify( EmptyObjArraySummary ) );

  const keyIsDate: boolean = key.indexOf('Age') > -1 ? true : false;

  items.map(( item: IAnySourceItemAny, idx0: number ) => {

    let itemValue = key.indexOf('.') < 0 ? item[key] : `${checkDeepProperty( item, key.split( '.' ), 'EmptyString', false )}`;

    // if itemValue is a date, then convert to integer to group by date in the past
    if ( keyIsDate === true ) itemValue = parseInt( itemValue , 10) + 0; // Added 0 to make this non mutating

    // Get index of this item and create object if it does not exist
    let idx: number = summary.keys.indexOf( itemValue );

    if (idx < 0) {
      idx = summary.keys.length;
      summary.keys.push( itemValue );
      const keyItem: IOjbectKeySummaryItem = createKeyObject(key,  keyIsDate === true ? getDateLabel(itemValue) : itemValue, valProp, otherKeys );

      // Only add link if it is for a site.
      if ( key === 'SiteTitle' ) keyItem.link = getBestAnalyticsLinkAndIcon( item as IZFetchedAnalytics, false, [ 'SiteLink', 'PageLink', 'PageURL' ] ).linkUrl;
      summary.summaries.push( keyItem );
    }

    item.primeIdx = idx0;
    const thisSum = summary.summaries[idx];
    thisSum.countT++;
    if (itemValue)
      thisSum.countI++;
    if (typeof itemValue === 'number' || typeof itemValue === 'bigint' ) {
      thisSum.countV++;
      thisSum.sum += getSumableNumber( itemValue ) ;
    }

    // Add other keys for additional information
    otherKeys.map((oKey: string, idx: number) => {
      if (item[oKey] && thisSum[`key${idx}` as 'key0'].indexOf(item[oKey]) < 0) {
        thisSum[`key${idx}` as 'key0'].push(item[oKey]);
      }
    });

    thisSum.items.push(item);
  });

  summary.summaries.map(thisSum => {
    if (thisSum.sum > 0) thisSum.avg = thisSum.sum / thisSum.countV;
  });

  // Sort by count unless it's an age, then asc sort by date ( which is the avg value of the column )
  // 2023-10-06:  https://github.com/mikezimm/fps-library-v2/issues/120
  //    Only sort if not date... sortObjectArrayByNumberKey( summary.summaries, 'dec', keyIsDate === true ? 'avg' : 'countT' );
  //    if key === createdAge then it is already reverse sorted during fetch and will show latest on top.
  if ( key !== 'createdAge' )  summary.summaries = sortObjectArrayByNumberKey( summary.summaries, 'dec', keyIsDate === true ? 'avg' : 'countT' );

  // Get top 10 labels by count
  summary.topLabels = summary.summaries.slice( 0, 9 ).map( thisSum => { return thisSum.primaryKey });

  // Get % T - 100 = max item:  https://stackoverflow.com/a/16751601
  const sumCountT: number = summary.summaries.map( thisSum => { return thisSum.countT }).reduce((partialSum, a) => partialSum + a, 0);
  const countMax: number = Math.max( ...summary.summaries.map( thisSum => { return thisSum.countT }) );
  if ( sumCountT !== 0 ) summary.summaries.map( thisSum => { thisSum.percentT = ( thisSum.countT / sumCountT ) * 100 });
  if ( countMax !== 0 )  summary.summaries.map( thisSum => { thisSum.percentB = ( thisSum.countT / countMax ) * 100 });

  summary.summaries.map( thisSum => {
    thisSum.FPSItem.Search.searchText = thisSum.primaryKey;
    thisSum.FPSItem.Search.searchTextLC = thisSum.primaryKey.toLowerCase();
   });

  return summary;

}

function getDateLabel(daysAgo: number): string {
  const date = new Date();
  date.setDate(date.getDate() - daysAgo);
  return date.toLocaleDateString();
}