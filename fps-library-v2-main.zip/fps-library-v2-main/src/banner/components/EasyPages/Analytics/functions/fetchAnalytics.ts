import { getSourceItems } from "../../../../../pnpjs/SourceItems/getSourceItems";
import { ISourceProps } from "../../../../../pnpjs/SourceItems/Interface";
import { buildAnalyticsSummary } from "./buildAnalyticsSummary";
import { createAnalyticsSourceProps } from "../interfaces/createAnalyticsSourceProps";
import { IStateSourceA } from "../interfaces/IStateSourceA";

export async function getAnalyticsSummary( AnalyticsSourceProps: ISourceProps, wpFilterProps: string[], analyticsListX: string = '', analyticsWebX: string = '' ): Promise<IStateSourceA> {

  if ( !AnalyticsSourceProps ) AnalyticsSourceProps = createAnalyticsSourceProps( analyticsListX, analyticsWebX );

  let stateSource: IStateSourceA = await getSourceItems( { ...AnalyticsSourceProps, ...{ editMode: null } }, false, true ) as IStateSourceA;
  stateSource.fpsContentType = [ ...AnalyticsSourceProps.fpsContentType, 'item' ];
  stateSource = buildAnalyticsSummary( AnalyticsSourceProps, stateSource, wpFilterProps );


  return stateSource;
}


