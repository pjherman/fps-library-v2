
import {
  PropertyPaneTextField,
  PropertyPaneDropdown, IPropertyPaneField, IPropertyPaneGroup
} from '@microsoft/sp-property-pane';

import { IThisFPSWebPartClass } from '../../FPSWebPartClass/IThisFPSWebPartClass';

/**
 * Derived from Secure Script 7 v2 web part
 * @param wpProps 
 * @param _approvedLists 
 * @param _listsDropdownDisabled 
 * @param _listItemsPickerList 
 * @param _itemsDropdownDisabled 
 * @returns 
 */

const ListPickerLabel = "Pick an approved library";
const ListItemPickerLabel = "Pick a file";
const WebPickerLabel = 'Approved web url - Must end with /';

export function FPSListItemPickerGroupFields( thisWPClass: IThisFPSWebPartClass, wpStrings?: IFPSItemPickerWebPartStrings ): IPropertyPaneField<any>[] {

  const { _approvedLists, _listsDropdownDisabled, _listItemsPickerList, _itemsDropdownDisabled } = thisWPClass; 
  const wpProps = thisWPClass.properties;
  
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const groupFields: IPropertyPaneField<any>[] = [];

  groupFields.push(
    PropertyPaneTextField('webUrlPickerValue', {
      label: WebPickerLabel,
      description: 'Make sure to add / at end!',
    })
  );

  groupFields.push(
    PropertyPaneDropdown('listPickerValue', {
      label: wpStrings && wpStrings.ListPickerLabel ? wpStrings.ListPickerLabel : ListPickerLabel,
      options: _approvedLists,
      selectedKey: wpProps.listPickerValue,
      disabled: _listsDropdownDisabled,
    })
  );

  groupFields.push(
    PropertyPaneDropdown('listItemPickerValue', {
      label: wpStrings && wpStrings.ListPickerLabel ? wpStrings.ListItemPickerLabel : ListItemPickerLabel,
      options: _listItemsPickerList,
      selectedKey: wpProps.listItemPickerValue,
      disabled: _itemsDropdownDisabled,
    })
  );

  return groupFields;

}

/**
 * Derived from Secure Script 7 v2 web part
 * @param wpProps 
 * @param _approvedLists 
 * @param _listsDropdownDisabled 
 * @param _listItemsPickerList 
 * @param _itemsDropdownDisabled 
 * @returns 
 */
export function FPSListItemPickerGroup( groupName: string, thisWPClass: IThisFPSWebPartClass, wpStrings?: IFPSItemPickerWebPartStrings ): IPropertyPaneGroup {

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const groupFields: IPropertyPaneField<any>[] = FPSListItemPickerGroupFields( thisWPClass, wpStrings );

  const ExportThisGroup: IPropertyPaneGroup = {
    groupName: groupName,
    groupFields: groupFields
  };

  return ExportThisGroup;

}
