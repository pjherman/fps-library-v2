// define([], function() {
//   return {
//     "ListPickerLabel": "Pick an approved library",
//     "ListItemPickerLabel":"Pick a file",
//   }
// });

import { IFPSItemPickerWebPartStrings } from "./IFPSItemPickerWebPartStrings";

export const FPSItemPickerWebPartStrings: IFPSItemPickerWebPartStrings = {
  "ListPickerLabel": "Pick an approved library",
  "ListItemPickerLabel":"Pick a file",
}

