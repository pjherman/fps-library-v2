export interface IFPSItemPickerWebPartStrings {
  ListPickerLabel: string;
  ListItemPickerLabel: string;
}
