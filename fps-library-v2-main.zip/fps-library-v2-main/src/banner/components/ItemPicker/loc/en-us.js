define([], function() {
  return {
    "ListPickerLabel": "Pick an approved library",
    "ListItemPickerLabel":"Pick a file",
  }
});

