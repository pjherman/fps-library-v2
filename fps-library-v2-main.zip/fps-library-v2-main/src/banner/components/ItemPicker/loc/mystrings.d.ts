
declare interface IFPSItemPickerWebPartStrings {
  ListPickerLabel: string;
  ListItemPickerLabel: string;
}

declare module 'FPSItemPickerWebPartStrings' {
  const strings: IFPSItemPickerWebPartStrings;
  export = strings;
}
