
import { IPropertyPaneDropdownOption } from '@microsoft/sp-property-pane';
import { IFPSListItemPropPaneDropDownOption } from './IFPSListItemPropPaneDropDownOption';

/**
 * These are class level props used for ItemPicker in property pane
 */
export interface IFPSListItemPickerWPClass {
  _listPickerValue: string;
  _webUrlPickerValue: string;
  _webUrlPickerValueApproved: boolean;
  _listItemPickerValue: string;

  _runSandbox: boolean;

  _listsDropdownDisabled: boolean;
  _itemsDropdownDisabled: boolean;
  
  _listItemsPickerList: IPropertyPaneDropdownOption[];
  _listPickerList: IFPSListItemPropPaneDropDownOption[];
  _approvedLists: IFPSListItemPropPaneDropDownOption[];
  
  _approvedFilePickerTypes: string[];
  _fetchInstance: string;
  refreshPaneReRender: () => void;
}
