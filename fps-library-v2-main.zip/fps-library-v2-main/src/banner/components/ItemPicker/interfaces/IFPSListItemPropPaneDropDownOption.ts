import { IPropertyPaneDropdownOption } from '@microsoft/sp-property-pane';

/**
 * IFPSListItemPropPaneDropDownOption was originally IApprovedCDNs/IApprovedWebs in SecureScript7.
 *  It is used as interface of approved webs that could be used as a webpart property.
 *  The interface can also be passed into the property pane dropdown column
 */

export interface IFPSListItemPropPaneDropDownOption extends IPropertyPaneDropdownOption {
  key: string;
  siteRelativeURL: string;
  list: string; // Changed from library to list to be more flexible 
  text: string;
  subsites?: boolean;
}
