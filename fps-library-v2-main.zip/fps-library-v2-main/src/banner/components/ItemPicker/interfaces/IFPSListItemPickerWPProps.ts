
export interface IFPSListItemPickerWPProps {
  // webPicker: string; // Currently not used
  webUrlPickerValue: string;
  listPickerValue: string;
  listItemPickerValue: string;
}

export const changeListItemPickers: string[] = [ 'webUrlPickerValue', 'listPickerValue', 'listItemPickerValue' ];