
# FPS List Item Picker implimentation notes

## In order to use, follow these steps and compare to CoreFPS1173 sample

1. import changeListItemPickers into ILocalWebPartProps file and into WebPartAnalyticsChanges
```typescript
import { changeListItemPickers } from '@mikezimm/fps-library-v2/lib/banner/components/ItemPicker/interfaces/IFPSListItemPickerWPProps';
```

2. Update required class properties in the onInit
```typescript
protected async onInit(): Promise<void> {
  //... stuff
  this._approvedLists = approvedLists;
  this._approvedFilePickerTypes = [ 'html', 'js' ]; // File types you want available in the picker.  Use [ '*' ] or [] for all extensions
  // this._fetchInstance = Math.floor(Math.random() * 79797979 ).toString();
  //... stuff
}
```

3. Add required functions into the propPaneStart
```typescript

    import { onwebUrlPickerValueChanged } from '@mikezimm/fps-library-v2/lib/banner/components/ItemPicker/functions/onWebUrlPickerValueChanged';
    import { onListPickerChanged } from '@mikezimm/fps-library-v2/lib/banner/components/ItemPicker/functions/onListPickerChanged';
    import { onListItemPickerChanged } from '@mikezimm/fps-library-v2/lib/banner/components/ItemPicker/functions/onListItemPickerChanged';
    import { onListItemPropPaneStart } from '@mikezimm/fps-library-v2/lib/banner/components/ItemPicker/functions/onListItemPropPaneStart';

    protected async onPropertyPaneConfigurationStart(): Promise<void> {

      // If required add approvedSites into approvedSites[] or set to just [] to allow any site
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await onListItemPropPaneStart( this as any, approvedSites, );
    }

```

4. Update onPropertyPaneFieldChanged to call change functions
```typescript

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  protected async onPropertyPaneFieldChanged(propertyPath: string, oldValue: any, newValue: any): Promise<void>{
    super.onPropertyPaneFieldChanged(propertyPath, oldValue, newValue);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await onFPSPropPaneCHanged( this as any, propertyPath, oldValue, newValue, );

    // If required add approvedSites into approvedSites[] or set to just [] to allow any site
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await onwebUrlPickerValueChanged( this as any, propertyPath, oldValue, newValue, approvedSites, );
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await onListPickerChanged( this as any, propertyPath, oldValue, newValue, );
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await onListItemPickerChanged( this as any, propertyPath, oldValue, newValue, );

  }
```

5. Add your prop pane group into getPropertyPaneConfiguration
```typescript
  import { FPSListItemPickerGroup, } from '@mikezimm/fps-library-v2/lib/banner/components/ItemPicker/FPSListItemPickerGroup';

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    // add group to your property pane config as needed...
    groups = [ ...groups, FPSListItemPickerGroup( 'File Picker', thisAsAny ), ...FPSGroups ];
    // ...
  }
```

6. Update /loc/en-us.js 
```typescript
import { LanguageSpecificStrings } from '@mikezimm/fps-library-v2/lib/banner/components/ItemPicker/loc/en-us-ts.ts';
define([], function() {
  return { ...LanguageSpecificStrings, ...{
    // add your web part strings as needed
    "ListPickerLabel": "Pick an approved library",
    "ListItemPickerLabel":"Pick a file"
  }}
```

7. Update /loc/mystrings.d.ts
```typescript
declare interface IYourWebPartStrings extends IFPSItemPickerWebPartStrings {
  ListPickerLabel: string;
  ListItemPickerLabel: string;
}
```

8. Update PreConfiguredSettings
    webUrlPickerValue: "CurrentSite",


## What is included in base class FPSBaseClass and it's interface:

```typescript
export interface IFPSListItemPickerWPClass extends IThisFPSWebPartClass {
  _listPickerValue: string;
  _webUrlPickerValue: string;
  _webUrlPickerValueApproved: boolean;
  _runSandbox: boolean;
  _listItemPickerValue: string;
  _listsDropdownDisabled: boolean;
  _itemsDropdownDisabled: boolean;
  _listItemsPickerList: IPropertyPaneDropdownOption[];
  _listPickerList: IFPSListItemPropPaneDropDownOption[];
  _approvedLists: IFPSListItemPropPaneDropDownOption[];
  _fetchInstance: string;
  refreshPaneReRender: () => void;
}
```