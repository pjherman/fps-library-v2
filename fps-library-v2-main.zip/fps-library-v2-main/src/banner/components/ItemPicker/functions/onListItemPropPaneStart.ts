
import { IJSFetchReturn } from "../../../../components/molecules/SpHttp/doSpJsFetch";
import { IFPSListItemPickerWPProps } from "../interfaces/IFPSListItemPickerWPProps";
import { fetchListList } from "./fetchListList";
import { IFPSListItemPropPaneDropDownOption } from '../interfaces/IFPSListItemPropPaneDropDownOption';
import { fetchFileList } from "../functions/fetchFileList";
import { IThisFPSWebPartClass } from "../../../FPSWebPartClass/IThisFPSWebPartClass";

export function testValidWebUrl( approvedWebs: IFPSListItemPropPaneDropDownOption[] , webUrl: string ): boolean {
  let isValidWebUrl = true;
  let isApprovedWeb = false;
  if ( !webUrl || webUrl.length === 0 ) { isValidWebUrl = false; 
  } else if ( webUrl.indexOf('/sites/') !== 0 && webUrl.indexOf(window.origin ) !== 0 ) { isValidWebUrl = false; }

  if ( isValidWebUrl === true ) {
    if ( approvedWebs.length === 0 ){
      isApprovedWeb = true;
    } else {
      approvedWebs.map( site => {
        if ( webUrl.toLowerCase().indexOf( `${site.siteRelativeURL.toLowerCase()}/` ) > -1 ) { isApprovedWeb = true; }
      });
    }
  }

  return isApprovedWeb;

}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function onListItemPropPaneStart( thisWPClass: IThisFPSWebPartClass, approvedWebs: IFPSListItemPropPaneDropDownOption[] ,  ): Promise<void> {

  const wpProps: IFPSListItemPickerWPProps = thisWPClass.properties;

  if ( wpProps.webUrlPickerValue && wpProps.webUrlPickerValue.toLowerCase().indexOf('currentsite') > -1 ) { 
    wpProps.webUrlPickerValue = `${thisWPClass.context.pageContext.web.serverRelativeUrl}/`;
    thisWPClass.context.propertyPane.refresh();
  }

  thisWPClass._webUrlPickerValueApproved = false;
  thisWPClass._itemsDropdownDisabled = true;
  thisWPClass._listsDropdownDisabled = true;

  const webUrlIsApproved = approvedWebs.length === 0 ? true : testValidWebUrl( approvedWebs, wpProps.webUrlPickerValue );

  //May need to remove this check so you can run in sandbox mode after saving props to invalid CDN
  if ( webUrlIsApproved === true || thisWPClass._runSandbox === true ) {

    // eslint-disable-next-line @typescript-eslint/no-floating-promises, @typescript-eslint/no-explicit-any
    fetchListList( thisWPClass.context as any, wpProps.webUrlPickerValue, `BaseTemplate eq 101 and Hidden eq false` )
    .then(( results: IJSFetchReturn ): void => {
      if (results.items.length > 0 ) {
        thisWPClass._listPickerList = results.items;
        thisWPClass._approvedLists = thisWPClass._listPickerList as IFPSListItemPropPaneDropDownOption[];
        thisWPClass._listsDropdownDisabled = false;

        if (results.items.length > 0 ) {
          if (wpProps.listPickerValue) {

            let selectedLibrary: IFPSListItemPropPaneDropDownOption = undefined;

            thisWPClass._listPickerList.map( ( lib, idx ) => {
              if ( lib.key === wpProps.listPickerValue ) { selectedLibrary = lib as IFPSListItemPropPaneDropDownOption; }
            });

            // eslint-disable-next-line @typescript-eslint/no-floating-promises, @typescript-eslint/no-explicit-any
            fetchFileList( thisWPClass.context as any, selectedLibrary, thisWPClass._approvedFilePickerTypes )
              .then(( results: IJSFetchReturn ): void => {

                console.log('onPropertyPaneConfigurationStart: files', results );

                thisWPClass._listItemsPickerList = results.items;

                // enable item selector
                thisWPClass._itemsDropdownDisabled = false;
                thisWPClass.refreshPaneReRender();
              });
          } else {
            console.log('onPropertyPaneConfigurationStart: wpProps.listPickerValue', wpProps.listPickerValue );
            thisWPClass._listItemsPickerList = [];
            thisWPClass.refreshPaneReRender();
          }
        }
      }
    })

  } else { //No web selected, clear all sub properties
    wpProps.listPickerValue = null;
    thisWPClass._listItemsPickerList = [];
    thisWPClass.refreshPaneReRender();
  }

}
