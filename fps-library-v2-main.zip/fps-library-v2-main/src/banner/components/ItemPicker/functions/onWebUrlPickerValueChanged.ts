
import { IFPSListItemPickerWPProps } from "../interfaces/IFPSListItemPickerWPProps";
import { IJSFetchReturn } from "../../../../components/molecules/SpHttp/doSpJsFetch";
import { fetchListList } from "./fetchListList";
import { IFPSListItemPropPaneDropDownOption } from '../interfaces/IFPSListItemPropPaneDropDownOption';
import { testValidWebUrl } from "./onListItemPropPaneStart";
import { IThisFPSWebPartClass } from "../../../FPSWebPartClass/IThisFPSWebPartClass";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function onwebUrlPickerValueChanged(  thisWPClass: IThisFPSWebPartClass, propertyPath: string, oldValue: any, newValue: any, approvedWebs: IFPSListItemPropPaneDropDownOption[] , ): Promise<void> {

  if ((propertyPath === 'webUrlPickerValue') && (newValue) ) {
    const wpProps: IFPSListItemPickerWPProps = thisWPClass.properties;
    const webUrlIsApproved = testValidWebUrl( approvedWebs, wpProps.webUrlPickerValue );

    thisWPClass._fetchInstance = Math.floor(Math.random() * 79797979 ).toString();
    thisWPClass._webUrlPickerValueApproved = false;
    wpProps.listPickerValue = '';
    wpProps.listItemPickerValue = '';
    thisWPClass._listsDropdownDisabled = true;
    thisWPClass._itemsDropdownDisabled = true;

    if ( webUrlIsApproved === false ) {
      thisWPClass._listPickerList = [];
      thisWPClass._approvedLists = [];

    } else {
      //Not sure what thisWPClass does but am keeping same model as with libraries
      const previousItem: string = wpProps.listPickerValue;

      await thisWPClass.onPropertyPaneFieldChanged('listPickerValue', previousItem, wpProps.listPickerValue);

      //Added last check to only get libraries when the Url ends in /
      if ( newValue !== '' && newValue.length > 0 && newValue.charAt(newValue.length - 1) === '/' ) {

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await fetchListList( thisWPClass.context as any, wpProps.webUrlPickerValue, `BaseTemplate eq 101 and Hidden eq false` )
          .then(( result: IJSFetchReturn ): void => {

          if (result.items.length) {
            // store items
            thisWPClass._listPickerList = result.items;
            thisWPClass._approvedLists = thisWPClass._listPickerList as IFPSListItemPropPaneDropDownOption[];
            // enable item selector
            thisWPClass._listsDropdownDisabled = false;
          }
          });
      }

    }

    thisWPClass.refreshPaneReRender();

  }

}