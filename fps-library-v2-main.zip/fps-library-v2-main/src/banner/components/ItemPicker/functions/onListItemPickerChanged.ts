
import { IFPSListItemPickerWPProps } from '../interfaces/IFPSListItemPickerWPProps';
import { IThisFPSWebPartClass } from '../../../FPSWebPartClass/IThisFPSWebPartClass';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function onListItemPickerChanged( thisWPClass: IThisFPSWebPartClass, propertyPath: string, oldValue: any, newValue: any, ): Promise<void> {

  const wpProps: IFPSListItemPickerWPProps = thisWPClass.properties;

  if ((propertyPath === 'listItemPickerValue') && (newValue)) {
    thisWPClass._fetchInstance = Math.floor(Math.random() * 79797979 ).toString();
    console.log('changed Library Item:  ', newValue );
    wpProps.listItemPickerValue = newValue;
    thisWPClass.refreshPaneReRender();
  }

}
