
import { IJSFetchReturn, doSpJsFetch } from '../../../../components/molecules/SpHttp//doSpJsFetch';
import { IPerformanceSettings } from '../../../../components/molecules/Performance/IPerformanceSettings';
import { startPerformOpV2, unifiedPerformanceEnd } from '../../../../components/molecules/Performance/functions';
import { IFpsErrorObject } from '../../../../pnpjs/Common/IFpsErrorObject';
import { IFpsItemsReturn, checkItemsResults } from '../../../../pnpjs/Common/CheckItemsResults';
import { WebPartContextCopy_15_2 } from '../../../../common/interfaces/indexes/WebPartContext@152';

export interface IListPickerLists {
  Title: string;
  EntityTypeName: string;
  BaseType: 0 | 1;
  ParentWebUrl: string;
  RootFolder: {
    ServerRelativeUrl: string;
  }
  list: string;
  text: string;  // Required for list picker
  key: string;   // Required for list picker
  isLibrary: boolean;
  siteRelativeURL: string;
}

// THIS SHOULD COME FROM doSpJsFetch file
export function createEmptyFetchReturn( fetchAPI: string ): IJSFetchReturn {
  const emptyObject: IJSFetchReturn = {
    items: [],
    ok: null,
    e: null,
    status: 'Unknown',
    fetchAPI: fetchAPI,
  }
 return emptyObject;
}

/**
 * 
 * @param context 
 * @param filesLocation 
 * @param postFilters : would be string array of valid extensions to return
 * @returns 
 */

export async function fetchListList( context: WebPartContextCopy_15_2, web : string, filter: string ): Promise<IJSFetchReturn> {

  let websLocation = web;
  if ( web.indexOf('/sites/') === 0 ) { websLocation = window.location.origin + websLocation ; }
  if ( websLocation.slice(-1) !== '/' ) { websLocation += '/'; }

  const performanceSettings: IPerformanceSettings = {  label: 'myHubs', updateMiliseconds: true, includeMsStr: true, op: 'fetch' };
  const fetchOp = performanceSettings ? startPerformOpV2( performanceSettings ) : null;

  const apiFetchLibsQuery = `${websLocation}/_api/Web/Lists?$filter=${filter}&select=Title,EntityTypeName,BaseType,ParentWebUrl,RootFolder`;

  if ( !web ) return createEmptyFetchReturn( apiFetchLibsQuery );

  const resultFileList: IJSFetchReturn = await doSpJsFetch( apiFetchLibsQuery );

  if ( resultFileList.ok ) resultFileList.items = cleanWebLists( resultFileList.items, );

  let result : IJSFetchReturn = unifiedPerformanceEnd( resultFileList as IFpsErrorObject, performanceSettings, fetchOp, 'fetch', 'items'  ) as IJSFetchReturn;
  result.fpsContentType = [ 'list' ];

  result = checkItemsResults( result as IFpsItemsReturn, `fps-library-v2: fetchFileList ~ 69`, false, true ) as IJSFetchReturn;

  return result;

}

export function cleanWebLists( ListPickerInfo: IListPickerLists[], ): IListPickerLists[] {

  // Do postFilters here
  //Issue #6 & #7

  ListPickerInfo.map( list => {
    const listRelativeURL = list.RootFolder ? 
      list.RootFolder.ServerRelativeUrl : 
      list.BaseType === 1 ? `${list.ParentWebUrl}/${list.EntityTypeName}` : 
      `${list.ParentWebUrl}/lists/${list.EntityTypeName}`;

    list.siteRelativeURL = `${list.ParentWebUrl}`;
    list.text = list.Title;
    list.list = list.EntityTypeName;
    list.key = listRelativeURL;
  });

  return ListPickerInfo;

}