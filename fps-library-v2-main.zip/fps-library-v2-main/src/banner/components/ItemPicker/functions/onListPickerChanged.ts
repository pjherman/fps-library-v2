import { IFPSListItemPickerWPProps } from "../interfaces/IFPSListItemPickerWPProps";
import { IJSFetchReturn } from "../../../../components/molecules/SpHttp/doSpJsFetch";

import { fetchFileList } from "../functions/fetchFileList";
import { IThisFPSWebPartClass } from "../../../FPSWebPartClass/IThisFPSWebPartClass";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function onListPickerChanged( thisWPClass: IThisFPSWebPartClass, propertyPath: string, oldValue: any, newValue: any, ): Promise<void> {

  const wpProps: IFPSListItemPickerWPProps = thisWPClass.properties;

  if ((propertyPath === 'listPickerValue') && (newValue)) {
    thisWPClass._fetchInstance = Math.floor(Math.random() * 79797979 ).toString();
    // get previously selected item
    const previousItem: string = wpProps.listItemPickerValue;
    // reset selected item
    wpProps.listItemPickerValue = "";
    // disable item selector until new items are loaded
    thisWPClass._itemsDropdownDisabled = true;
    // push new item value
    await thisWPClass.onPropertyPaneFieldChanged('listItemPickerValue', previousItem, wpProps.listItemPickerValue);

    let libIndex = -1;

    thisWPClass._listPickerList.map( ( lib, idx ) => {
      if ( lib.key === newValue ) { libIndex = idx; }
    });

    const selectedLibrary = libIndex > -1 ? thisWPClass._listPickerList[libIndex] : null;
    thisWPClass.refreshPaneReRender();

    // eslint-disable-next-line @typescript-eslint/no-floating-promises, @typescript-eslint/no-explicit-any
    fetchFileList( thisWPClass.context as any, selectedLibrary, thisWPClass._approvedFilePickerTypes )
      .then(( results: IJSFetchReturn ): void => {

        console.log('onPropertyPaneConfigurationStart: files', results );

        thisWPClass._listItemsPickerList = results.items;

        // enable item selector
        thisWPClass._itemsDropdownDisabled = false;

        thisWPClass.refreshPaneReRender();
    });  // END:  thisWPClass.getLibraryItemsList

  }

}
