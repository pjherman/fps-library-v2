

import { IJSFetchReturn, doSpJsFetch } from '../../../../components/molecules/SpHttp//doSpJsFetch';
import { IPerformanceSettings } from '../../../../components/molecules/Performance/IPerformanceSettings';
import { startPerformOpV2, unifiedPerformanceEnd } from '../../../../components/molecules/Performance/functions';
import { IFpsErrorObject } from '../../../../pnpjs/Common/IFpsErrorObject';
import { IFpsItemsReturn, checkItemsResults } from '../../../../pnpjs/Common/CheckItemsResults';
import { WebPartContextCopy_15_2 } from '../../../../common/interfaces/indexes/WebPartContext@152';
import { IFPSListItemPropPaneDropDownOption } from '../interfaces/IFPSListItemPropPaneDropDownOption';
import { sortObjectArrayByStringKey } from '../../../../logic/Arrays/sorting/objects';
import { IAnySourceItem } from '../../../../components/molecules/AnyContent/IAnyContent';

/**
 * fetchFileList will fetch an array of the current site's hub associated sites.  Used in Pivot Tiles and Hub Connections.
 * @param webUrlPicker 
 * @param departmentId 
 * @returns 
 */

// import { sortObjectArrayByStringKey } from '../../fpsReferences';


// These are for Prop Pane File Picker
export interface IKeyText {
  key: string;
  text: string;
}


/**
 * IKeyText is for the prop pane dropdown picker
 */
export interface IPropPaneFetchFileProps extends IKeyText {
  FileLeafRef: string;  // part of the return value
  FileRef: string;  // part of the return value
  FileSystemObjectType?: number;
  '@odata.id': string;  // part of the return value

  Name: string;
  id: string;
  type: string;

}

// THIS SHOULD COME FROM doSpJsFetch file
export function createEmptyFetchReturn( fetchAPI: string ): IJSFetchReturn {
  const emptyObject: IJSFetchReturn = {
    items: [],
    ok: null,
    e: null,
    status: 'Unknown',
    fetchAPI: fetchAPI,
  }
 return emptyObject;
}

  /**
   * 
   * @param context 
   * @param filesLocation 
   * @param postFilters : would be string array of valid extensions to return
   * @returns 
   */
  // export async function getPickerFiles ( context: WebPartContextCopy_15_2, filesLocation: undefined | IFPSListItemPropPaneDropDownOption, postFilters: string[] ): Promise<IPropPaneFetchFileProps[]> {


export async function fetchFileList( context: WebPartContextCopy_15_2, filesLocation: undefined | IFPSListItemPropPaneDropDownOption, postFilters: string[] ): Promise<IJSFetchReturn> {

  const performanceSettings: IPerformanceSettings = {  label: 'myHubs', updateMiliseconds: true, includeMsStr: true, op: 'fetch' };
  const fetchOp = performanceSettings ? startPerformOpV2( performanceSettings ) : null;

  const apiFetchFilesQuery = window.location.origin + filesLocation.siteRelativeURL + "/_api/web/lists/getbytitle('" + filesLocation.text + "')/Items?$select=FileLeafRef,FileRef,FileSystemObjectType";

  if ( filesLocation === undefined ) return createEmptyFetchReturn( apiFetchFilesQuery );

  const resultFileList: IJSFetchReturn = await doSpJsFetch( apiFetchFilesQuery );

  if ( resultFileList.ok ) resultFileList.items = cleanWebFileList( resultFileList.items, postFilters );

  let result : IJSFetchReturn = unifiedPerformanceEnd( resultFileList as IFpsErrorObject, performanceSettings, fetchOp, 'fetch', 'items'  ) as IJSFetchReturn;
  result.fpsContentType = [ 'file' ];

  result = checkItemsResults( result as IFpsItemsReturn, `fps-library-v2: fetchFileList ~ 69`, false, true ) as IJSFetchReturn;

  return result;

}

export interface IPickerFileFetch {


}

export function cleanWebFileList( FilePickerInfo: IPropPaneFetchFileProps[],  postFilters: string[] ): IPropPaneFetchFileProps[] {

  // Do postFilters here
  //Issue #6 & #7
  let FilteredItems: IPropPaneFetchFileProps[] = [];

  if ( !postFilters || postFilters.length === 0 || postFilters.indexOf('*') > -1 ) {
    FilePickerInfo.map((item : IPropPaneFetchFileProps) => {
      // Only push files, not folders
      if ( item.FileSystemObjectType !== 1 ) {
          FilteredItems.push(item);
      }
    });
  } else {
    FilePickerInfo.map( (item: IPropPaneFetchFileProps ) => {
      // const extension = item.key.substr(item.key.lastIndexOf(".") + 1).toLowerCase() as IApprovedFileType;
      const extension: string = item.FileRef ? item.FileRef.substring(item.FileRef.lastIndexOf('.') + 1).toLowerCase() : 'unknown' ;
      if (extension && extension.length > 0 && postFilters.indexOf(extension) > -1) {
          FilteredItems.push(item);
      }
    });
  }

  // Moved after because it's more efficient with potentially less items
  FilteredItems.map( item => {

    item.Name = item.FileLeafRef;
    item.id = item['@odata.id'];
    item.text = item.FileLeafRef;

    item.type = item['@odata.id'];
    item.key = item.FileRef;

  });

  const SortedItems: IPropPaneFetchFileProps[] = sortObjectArrayByStringKey( FilteredItems, 'asc', 'text' );

  return SortedItems;

}