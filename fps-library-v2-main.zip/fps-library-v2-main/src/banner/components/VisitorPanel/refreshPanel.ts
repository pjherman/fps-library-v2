
import { IRepoLinks } from "../../../components/atoms/Links/CreateLinks";
import { createPerformanceTableVisitor } from "../../../components/indexes/Performance";
import { ILoadPerformance, ILoadPerformanceOps } from "../../../components/molecules/Performance/IPerformance";
import { visitorPanelInfo } from "./VisitorPanelComponent";
import { IMinWPBannerProps } from "../../interfaces/MinWP/IMinWPBannerProps";
import { check4This } from "@mikezimm/fps-pnp2/lib/services/sp/CheckSearch";

export function refreshPanel(bannerProps: IMinWPBannerProps, repoLink: IRepoLinks, performance: ILoadPerformance, keysToShow: ILoadPerformanceOps[]) {

  if (performance) {
    if ( check4This( 'tracePerformance=true' ) === true ) console.log( `tracePerformance refreshPanel ~ 12`, JSON.parse(JSON.stringify( performance )) );
    bannerProps.replacePanelHTML = visitorPanelInfo(bannerProps as IMinWPBannerProps, repoLink, '', '', createPerformanceTableVisitor(performance, keysToShow), 'refreshPanel');
  }

  return bannerProps;

}
