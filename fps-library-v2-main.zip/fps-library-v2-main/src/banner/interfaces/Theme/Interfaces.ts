// ####################################################### #######################################################
// ####################################################### #######################################################

export interface IMinBannerThemeProps {
  bannerStyleChoice: string;
  bannerStyle: string;
  bannerCmdStyle: string;
  lockStyles: boolean;

  bannerHoverEffect: boolean;
  bannerPillShape: boolean;  // https://github.com/mikezimm/fps-library-v2/issues/53

}
export const changeBannerTheme : string[] = [ 'bannerStyleChoice', 'bannerStyle', 'bannerCmdStyle', 'lockStyles', 'bannerHoverEffect', 'bannerPillShape' ];
