
import { IMinWPFieldPanelProps } from "../../../components/molecules/FieldPanel/components/IMinWPFieldPanelProps";
import { IFPSPageBGWPProps } from "../../../components/molecules/FullPageBackGround/IFPSPageBGWPProps";
import { IEasyPagesIconsWPProps } from "../../components/EasyPages/components/EasyPagesGroup";
import { IFPSListItemPickerWPProps } from "../../components/ItemPicker/interfaces/IFPSListItemPickerWPProps";
import { IMinCustomHelpProps } from "../../components/VisitorPanel/Interfaces";
import { IMinPandoramicProps } from "../../features/Expando/Interfaces";
import { IMinPageStyleProps } from "../../features/PageStyle/Interfaces";
import { IMinPinMeProps } from "../../features/PinMe/Interfaces";
import { changeBannerTheme, IMinBannerThemeProps } from "../Theme/Interfaces";
import { changeBannerBasics, changeBannerNav, IMinBannerUIProps } from "./IMinBannerUIProps";
import { changeBannerUtility, IMinBannerUtilityProps } from "./IMinBannerUtilityProps";

/**
 * Usage:  export interface FutureMailable extends IMinWPBannerProps {
 */

 export interface IMinWPBannerProps extends 
  IMinBannerUIProps, IEasyPagesIconsWPProps, IMinPinMeProps, IMinPandoramicProps, 
  IMinBannerThemeProps, IMinCustomHelpProps, IMinPageStyleProps, 
  IMinBannerUtilityProps, IMinWPFieldPanelProps, IFPSPageBGWPProps, IFPSListItemPickerWPProps {

}

export const changeBanner : string[] = [ ...changeBannerBasics, ...changeBannerNav, ...changeBannerTheme, ...changeBannerUtility  ];
