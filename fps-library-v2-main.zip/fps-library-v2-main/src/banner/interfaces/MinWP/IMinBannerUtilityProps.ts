
// ####################################################### #######################################################
// ####################################################### #######################################################

import { IWebpartHistory } from "../../features/WebPartHistory/Interface";
import { ISupportedHost } from "../../../common/interfaces/@msft/1.15.2/layout";

export interface IMinBannerUtilityProps {
  uniqueId: string;
  pageLayout: ISupportedHost ;// like SinglePageApp etc... this.context[_pageLayout];

  analyticsListX: string; // Used for saving and fetching analytics list data

  showRepoLinks: boolean;
  showExport: boolean;

  fpsImportProps: string;

  //ADDED FOR WEBPART HISTORY:
  webpartHistory: IWebpartHistory;

  showTricks: boolean;

  propsEasyMode: boolean;

}

export const changeBannerUtility : string[] = [ 'showRepoLinks', 'showExport', 'propsEasyMode' ];