import { PageContextCopy_15_2_User } from "../../../common/interfaces/@msft/1.15.2/WebPartContext";
import { IFPSWindow } from "../../../common/interfaces/fps/Window";
import { IFPSUser } from "../../../logic/Users/IUserInterfaces";
import { dcrptMe } from "../../features/Tricky/logfun";

/**
 * This was moved from BuildBannerPropsX2 to here so the same logic could be used directly in the web part.
 *    Also created IPageContextCopy_15_2User in WebPartContext
 * @param _trickyEmailsAll 
 * @param user :  if user === null then it will compare against FPSUser
 * @returns 
 */
export function check4Tricks( _trickyEmailsAll: string[], user: PageContextCopy_15_2_User ): boolean {
  let showTricks: any = false;
  const useFPSUser: boolean = !user ? true : false;
  if ( useFPSUser === true ) user = retrieveFPSUser();
  _trickyEmailsAll.map( getsTricks => {
    if ( useFPSUser === false && user && user.loginName && user.loginName.toLowerCase().indexOf(dcrptMe(getsTricks)) > -1) { 
      showTricks = true ;
    // Added this so that you can compare against the window.FPSUser
    } else if ( user && user.email && user.email.toLowerCase().indexOf(dcrptMe(getsTricks)) > -1) { 
      showTricks = true ;
    }
  });
  return showTricks;
}

export function retrieveFPSUser(): any {
  const thisWindow : IFPSWindow = window as any;
  const FPSUser : IFPSUser = thisWindow.FPSUser ;
  return FPSUser;
}