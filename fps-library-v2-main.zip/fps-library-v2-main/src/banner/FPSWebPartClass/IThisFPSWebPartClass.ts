
import { DisplayMode } from '@microsoft/sp-core-library';
import { IFPSEnviro } from '../../common/interfaces/fps/IFPSEnviro';
import { WebPartContextCopy_15_2 } from '../../common/interfaces/@msft/1.15.2/WebPartContext';
import { ISitePreConfigProps } from '../../common/PropPaneHelp/preconfig/IPreConfig';
import { IRepoLinks } from '../../components/atoms/Links/CreateLinks';
import { IFieldPanelDesignMode } from '../../components/molecules/FieldPanel/components/IMinWPFieldPanelProps';
import { ILoadPerformance, ILoadPerformanceOps } from '../../components/molecules/Performance/IPerformance';
import { IFPSUser } from '../../logic/Users/IUserInterfaces';
import { IMinWPBannerProps } from '../interfaces/MinWP/IMinWPBannerProps';
import { IFullBackgroundMode } from '../../components/molecules/FullPageBackGround/IFPSPageBGWPProps';
import { IPropertyPaneDropdownOption } from '@microsoft/sp-property-pane';
import { IFPSListItemPickerWPClass } from '../components/ItemPicker/interfaces/IFPSListItemPickerWPClass';

export type IFieldPanelMode = 'Auto' | 'Manual' | 'Disabled';

export type ICallbackAddParamToUrl = ( newParamStr: string, reRender: boolean, newTab: boolean ) => void;

// Should match structure in CoreFPS/fpsTheme.module.scss
export interface IFPSSiteThemes {
  fpsMainErrBlock: string;
  fpsSiteThemeDark: string;
  fpsSiteThemeLight: string;
  fpsSiteThemePrimary: string;
}
/**
 *
 * WARNING:  THIS SHOULD MATCH THE CLASS IN FPSBaseClass
 * It is intended to mirror the class and is used for type checking in various functions including:
 *  - BuildBannerProps
 *  - runOnPropChange
 *  - runOnSuperOnInit
 *  - runWebPartRender
 *
 */
export interface IThisFPSWebPartClass extends IFPSListItemPickerWPClass {

  /**
   * These are intended to be set or adjusted right at the beginning of the main webpart class
   */
  _repoLink: IRepoLinks;
  _exportIgnorePropsWP: string[];
  _importBlockPropsWP: string[];
  _trickyApp: string;
  _trickyEmailsWP: string[]; // These are emails that get tricky functionality for this specific web part

  _panelVersion: string;
  _analyticsListX: string;  // Used for saving and fetching main analytics
  _analyticsWebX: string;  // Used for saving and fetching main analytics
  _analyticsOptionsX: string[];  // Used for saving and fetching main analytics
  _wpTDLeft: string[]; // Used for displaying tricky analytics
  _wpTDRight: string[]; // Used for displaying tricky analytics
  _wpFilterProps: string[]; // Used for displaying tricky analytics

  /**
   * These are preset but likely to be adjusted in each webpart as needed
   */
  _allowPinMe: boolean;

  /**
   * These are preset and NOT Likely to need adjustments
   */
  _forceBanner: boolean;
  _modifyBannerTitle: boolean;
  _modifyBannerStyle: boolean;
  _keysToShow: ILoadPerformanceOps[]; // Performance keys to show in the propPaneHelp

  //Disabling any of these removes from property pane, may not actually block importing though
  _allowQuickLaunchHide: boolean; //Allows user to hide quick launch via property pane
  _allowPageHeaderHide: boolean; //Allows user to hide Page Header (Title block) via property pane
  _allowToolBarHide: boolean; //Allows user to hide Toolbar (like edit page button) via property pane
  _allowAllSectWidth: boolean; //Allows user to hide Adjust all sections max width via property pane
  _allowShowSearch: boolean; //Adds 'Show Search' Toggle to property pane, only needed if web part needs it.
  _allowBeAUser: boolean; //Allows page editors to 'BeAUser' and adds to property pane where needed.
  _allowFeedback: boolean; //Allows page editors to add 'Feedback email' in banner.
  _allowPandoramic: boolean;  //Allows page editors the modify Expandoramic settings
  _allowSiteThemeChoice: boolean; //Allows page editors the choice to inherit SiteTheme as a Theme choice
  _allowEasyPages: boolean; //Allows page editors use EasyPages and EasyIcons
  _allowFullPageBG: IFullBackgroundMode; //Allows FullPageBackground component in webpart

  _allowFieldPanel: IFieldPanelMode;
  _allowPropsEasyMode: boolean; // Allows for Prop Pane Easy Mode if enabled in onInit... Default currently off https://github.com/mikezimm/pivottiles7/issues/246
  _wpInfoGroupExpanded: boolean; // Allows for auto expanding WebPartInfoGroup on opening the prop pane if desired

  _FieldPanelDesignMode: IFieldPanelDesignMode;  // Other web part prop that will get mapped to the FieldPanelProps - in case it's different property name for retro compatibility
  _FieldPanelWebProp: 'webUrl' | string;  // Other web part prop that will get mapped to the FieldPanelProps - in case it's different property name for retro compatibility
  _FieldPanelListProp: 'listTitle' | string;  // Other web part prop that will get mapped to the FieldPanelProps - in case it's different property name for retro compatibility

  _doHeadingStyles: boolean;

  /**
   * These are updated later in the code
   */
  _performance: ILoadPerformance;
  _sitePresets: ISitePreConfigProps;
  _FPSUser: IFPSUser;
  _FPSEnviro: IFPSEnviro;

  // All themes object... import stylesFPS from './CoreFPS/fpsTheme.module.scss';
/**
 * All themes object... 
 *    import stylesFPS from './CoreFPS/fpsTheme.module.scss';
 * 
 * add before super onInit
 *  this._fpsSiteThemes.fpsTheme;
 */
  _fpsSiteThemes: IFPSSiteThemes;  
  _fpsSiteThemeDark: string;
  _fpsSiteThemeLight: string;
  _fpsSiteThemePrimary: string;
  /**
   * These are preset and should be managed by the code... do not change in main webpart class
   */
  _wpInstanceID: string;
  _exitPropPaneChanged: boolean;
  _importErrorMessage: string;
  _trickyEmailsAll: string[]; // These are emails that get tricky functionality for this specific web part
  _isSPA: boolean; // Is SinglePageApp ( Layout === SingleWebPartAppPageLayout )

  _urlParameters: any;

  _beAReader: boolean;


  /**
   * These are functions used in the class
   */

  _beAUserFunction(): void;
  _saveFieldPanelViewsFunction(): void;
  _saveFieldPanelCommandsFunction(): void;
  _addParamToUrl: ICallbackAddParamToUrl;    // https://github.com/mikezimm/Slick-Sections/issues/27
  _refreshBGStyles(): void;    // Copied over from SlickSections to refresh white and background styles

  /**
   * These are here JUST FOR INTERFACE but come from SharePoint class
   */
  displayMode: DisplayMode;
  context: WebPartContextCopy_15_2;
  domElement: HTMLElement;
  properties: IMinWPBannerProps;
  onPropertyPaneConfigurationStart: any;
  onPropertyPaneFieldChanged: any;



}
