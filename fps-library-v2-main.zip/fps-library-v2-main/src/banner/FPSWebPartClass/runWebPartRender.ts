
import { addCanvasBGImageComponent } from '../../components/molecules/FullPageBackGround/addCanvasBGImageComponent';
import { startPerformOp, updatePerformanceEnd } from '../../components/molecules/Performance/functions';
import { buildExportPropsX } from '../features/ImportExport/BuildExportPropsX';

import { renderCustomStyles } from '../features/PageStyle/renderCustStyles';
import { IWebpartBannerProps } from '../mainReact/IWebpartBannerProps';
import { IMainWPBannerSetupX, mainWebPartRenderBannerSetupX } from './BuildBannerPropsX2';

import { IThisFPSWebPartClass } from './IThisFPSWebPartClass';

import { updateSectionBGStyles } from '../../components/molecules/FullPageBackGround/SectionStyles';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function runFPSWebPartRender( thisWPClass: IThisFPSWebPartClass, strings: any, 
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  WebPartAnalyticsChanges: any, WebPartPanelChanges: any, alreadyStartedPerformOp: boolean = false ): IWebpartBannerProps {

  /**
   * NOTE FROM TESTING, Only deconstruct things that do NOT change.
   * If I deconstructed _performance, _sitePresets, _FPSUser, then in main web part it would not return the actual values back.
   */

  const {displayMode, properties,  context, _wpInstanceID, domElement, _beAUserFunction, _saveFieldPanelCommandsFunction, _saveFieldPanelViewsFunction } = thisWPClass;

  /**
   * PERFORMANCE - START
   * This is how you can start a performance snapshot - make the _performance.KEYHERE = startPerforOp('KEYHERE', this.displayMode)
   */

  //This will create renderWebPartStart only if it was not created earlier in the render
  if ( thisWPClass._performance.ops.renderWebPartStart === undefined || alreadyStartedPerformOp === false ) {
    thisWPClass._performance.ops.renderWebPartStart = startPerformOp( 'renderWebPartStart', displayMode, true ); // https://github.com/mikezimm/Slick-Sections/issues/69
  }

  renderCustomStyles( 
    { wpInstanceID: _wpInstanceID, domElement: domElement, wpProps: properties, 
      displayMode: displayMode,
      doHeadings: thisWPClass._doHeadingStyles } );  //doHeadings is currently only used in PageInfo so set to false.

  const exportProps = buildExportPropsX( 'Panel', properties , _wpInstanceID, context.pageContext.web.serverRelativeUrl, WebPartAnalyticsChanges, WebPartPanelChanges, thisWPClass._exportIgnorePropsWP );
  const analyticsProps = buildExportPropsX( 'Analytics', properties , _wpInstanceID, context.pageContext.web.serverRelativeUrl, WebPartAnalyticsChanges, WebPartPanelChanges, thisWPClass._exportIgnorePropsWP );


  const buildBannerProps: IMainWPBannerSetupX = {
    main: thisWPClass,
    exportProps: exportProps,
    analyticsProps: analyticsProps,
    strings: strings,
    wideToggle: true,
    expandConsole: true,
    SpecialMessage: undefined,
  }

  const bannerProps: IWebpartBannerProps = mainWebPartRenderBannerSetupX( buildBannerProps );

  // https://github.com/mikezimm/Slick-Sections/issues/27
  // NOTE:  In SlickSections, this was run in the updateSectionStyles function AFTER runFPSWebPartRender was executed... so it is here at the end
  if ( thisWPClass._allowFullPageBG  !== false ) addCanvasBGImageComponent( thisWPClass.properties, 0, thisWPClass._isSPA );

  if ( bannerProps.showBeAUserIcon === true ) { bannerProps.beAUserFunction = _beAUserFunction.bind(thisWPClass); }

  // Migrated from SlickSections web part
  thisWPClass._performance.ops.process1 = updateSectionBGStyles( 'BGStylesR', thisWPClass as any );

  /**
    * PERFORMANCE - UPDATE
    * This is how you can UPDATE a performance snapshot - make the _performance.KEYHERE = startPerforOp('KEYHERE', this.displayMode)
    * NOTE IN THIS CASE to do it before you refreshPanelHTML :)
    */

  thisWPClass._performance.ops.renderWebPartStart = updatePerformanceEnd( thisWPClass._performance.ops.renderWebPartStart, true, 555 );

  return bannerProps;

}