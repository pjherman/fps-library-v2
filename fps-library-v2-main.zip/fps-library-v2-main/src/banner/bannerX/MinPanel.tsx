
import * as React from 'react';

import { createPerformanceTableVisitor } from '../../components/molecules/Performance/tables';
import { IWebpartBannerProps } from '../mainReact/IWebpartBannerProps';
import { check4This } from '@mikezimm/fps-pnp2/lib/services/sp/CheckSearch';

export function getMinPanel( bannerProps: IWebpartBannerProps ) : JSX.Element {

    const bonusHTML1: any = bannerProps.bonusHTML1 ? bannerProps.bonusHTML1 : null;
    const panelPerformance = bannerProps.panelPerformance ? createPerformanceTableVisitor( bannerProps.panelPerformance, [] ): null;
    if ( check4This( 'tracePerformance=true' ) === true ) console.log( `tracePerformance getMinPanel ~ 12`, JSON.parse(JSON.stringify( bannerProps.panelPerformance )) );
    const bonusHTML2: any = bannerProps.bonusHTML2 ? bannerProps.bonusHTML2 : null;

    const panelContent = <div>
      { bannerProps.replacePanelHTML }
      { bonusHTML1 ? <div>{ bonusHTML1 }</div> : null }
      <div>{ bannerProps.versionInfo } - getMinPanel</div>
      { panelPerformance ? <div>{ panelPerformance }</div> : null }
      { bonusHTML2 ? <div>{ bonusHTML2 }</div> : null }
    </div>;

  return panelContent;

}


