
import * as React from 'react';

import { Icon, } from 'office-ui-fabric-react/lib/Icon';
import { IWebpartBannerProps } from '../mainReact/IWebpartBannerProps';

export interface IUpdateWhiteRefresh  {
  farBannerElementsArray: JSX.Element[];
  bannerProps: IWebpartBannerProps;
  _showBeakerBanner(): void;
}

export function updateFarElementsWhiteRefresh( whiteProps: IUpdateWhiteRefresh ): JSX.Element[] {

  const { farBannerElementsArray, bannerProps, _showBeakerBanner } = whiteProps;
  const { _refreshBGStyles, bannerCmdReactCSS, fpsPageBGWPProps, beAUser, FPSUser } = bannerProps;
  const { defaultWhiteText, whiteRefreshTip } = fpsPageBGWPProps;

    // https://github.com/mikezimm/Slick-Sections/issues/18
    if ( defaultWhiteText === true ) {
      farBannerElementsArray.push( 
        //https://github.com/mikezimm/Slick-Sections/issues/49
        whiteRefreshTip ? 
        <div title={'Refresh Font colors - re-whitens them after scrolling down'} onClick={ _refreshBGStyles } 
          style={{ flexWrap: 'nowrap',
            justifyContent: 'start',
            alignItems: 'center',
            display: 'flex', cursor: 'pointer' }}>
              <div>{ whiteRefreshTip}</div>
              <Icon iconName={ 'SyncStatusSolid' } style={ bannerCmdReactCSS }/></div>:
        <div title={'Refresh Font colors - re-whitens them after scrolling down'}><Icon iconName={ 'SyncStatusSolid' } onClick={ _refreshBGStyles } style={ bannerCmdReactCSS }/></div>
      );
    }

    //Setting showTricks to false here ( skipping this line does not have any impact on bug #90 )
    // https://github.com/mikezimm/Slick-Sections/issues/18
    if ( beAUser === false 
        && FPSUser.simple !== 'Reader' 
        && FPSUser.simple !== 'None' ) {
            farBannerElementsArray.push( 
              <div title={'Show Debug Info'}><Icon iconName='TestAutoSolid' onClick={ _showBeakerBanner } style={ bannerCmdReactCSS }/></div>
            );
    }

  return farBannerElementsArray;

}
