
// @param traceString :  Format = webpart|analyticsWeb|analyticsList|result|text1|text2|text3|number1|number2
export const BaseErrorTrace = `fps-library-v2|/sites/Templates/Analytics/|ErrorLog`;