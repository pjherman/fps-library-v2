// import { IImageFit, IImageCover, IImageTarget, IImageZoom } from '@mikezimm/npmfunctions/dist/Services/PropPane/IReactImage';

// export type IImageFit = 'center' | 'contain' | 'cover' | 'none' | 'centerCover' | 'centerContain';

// export type IImageCover = 'landscape' | 'portrait';

// export type IImageTarget = 'top' | 'blank' | 'self' | 'parent';

// export type IImageZoom = '1.0' | '1.1' | '1.2' | '1.5' | '2.0';

// export type IGetHeroChoice = 'inLine' | 'carouselLayout' | 'carouselBuilder' | 'left' | 'right' | 'header' | 'footer' | 'none' ;

// export type IHoverEffect = 'slideUp' | 'fadeUp' | 'none' ;