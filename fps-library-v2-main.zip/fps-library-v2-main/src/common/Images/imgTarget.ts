import { IPropertyPaneDropdownOption } from '@microsoft/sp-property-pane';

export type IImageTarget = 'top' | 'blank' | 'self' | 'parent';

export const imgTargetChoices: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
  { index: 0, key: 'top', text: "Full Body (_top)" },
  { index: 1, key: 'blank', text: "New Window (_blank)" },
];

export const imgTargetChoicesAll: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
  { index: 0, key: 'top', text: "Full Body (_top)" },
  { index: 1, key: 'blank', text: "New Window (_blank)" },
  //  These do not seem to  work. 
  // {   index: 2,   key: 'self', text: "Same Frame (_self)"  },
  // {   index: 3,   key: 'parent', text: "Parent Frameset (_parent)"  },
];

export function getTarget(findMe: IImageTarget) {
  if (findMe === 'blank') {
    return "_blank";

  } else if (findMe === 'self') {
    return "_self";

  } else if (findMe === 'parent') {
    return "_parent";

  } else if (findMe === 'top') {
    return "_top";

  } else {
    return "_top";
  }
}
