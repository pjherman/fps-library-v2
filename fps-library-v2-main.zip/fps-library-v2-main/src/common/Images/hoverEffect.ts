import { IPropertyPaneDropdownOption } from '@microsoft/sp-property-pane';

export type IHoverEffect = 'slideUp' | 'fadeUp' | 'none' ;

export const hoverEffectChoices: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
  { index: 0, key: 'slideUp', text: "Slide panel up" },
  { index: 1, key: 'fadeUp', text: "Fade panel" },
  { index: 9, key: 'none', text: "None" },
];
/**
 * Currently just place holder in case needed.
 * @param findMe
 */


export function getHoverEffect(findMe: string) {
  if (findMe === '1.0') {
    return 1;
  } else if (findMe === '1.5') {
  } else if (findMe === '1.1') {
    return 1.2;
    return 1.1;
  } else if (findMe === '2.0') {
  } else if (findMe === '1.2') {
    return 1.2;
  } else {
    return 0;
  }
}
