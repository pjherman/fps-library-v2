import { IPropertyPaneDropdownOption } from '@microsoft/sp-property-pane';
import { ImageFit, ImageCoverStyle } from 'office-ui-fabric-react/lib/Image';

export type IImageFit = 'center' | 'contain' | 'cover' | 'none' | 'centerCover' | 'centerContain';

export type IImageCover = 'landscape' | 'portrait';

export const imgFitChoices: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
  { index: 0, key: 'center', text: 'Center' },
  { index: 1, key: 'contain', text: 'Contain' },
  { index: 2, key: 'cover', text: 'Cover' },
  { index: 3, key: 'none', text: 'None' },
  { index: 4, key: 'centerCover', text: 'CenterCover' },
  { index: 5, key: 'centerContain', text: 'CenterContain' },
];

export function getImgFit(findMe: IImageFit) {
  if (findMe === 'center') {
    return ImageFit.center;

  } else if (findMe === 'contain') {
    return ImageFit.contain;

  } else if (findMe === 'cover') {
    return ImageFit.cover;

  } else if (findMe === 'none') {
    return ImageFit.none;

  } else if (findMe === 'centerContain') {
    return ImageFit.centerContain;

  } else if (findMe === 'centerCover') {
    return ImageFit.centerCover;

  } else {
    return ImageFit.centerCover;
  }
}

export const imgCoverChoices: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
  { index: 0, key: 'landscape', text: "Landscape ^ stretch full height v" },
  { index: 1, key: 'portrait', text: "Portrait < stretch full width >" },
];

export function getImgCover(findMe: IImageCover) {
  if (findMe === 'landscape') {
    return ImageCoverStyle.landscape;
  } else {
    return ImageCoverStyle.portrait;
  }
}
