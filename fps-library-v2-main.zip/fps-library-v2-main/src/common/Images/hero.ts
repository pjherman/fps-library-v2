import { IPropertyPaneDropdownOption } from '@microsoft/sp-property-pane';

export type IGetHeroChoice = 'inLine' | 'carouselLayout' | 'carouselBuilder' | 'left' | 'right' | 'header' | 'footer' | 'none' ;

export const heroChoices: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
  { index: 0, key: 'inLine', text: "Single In Line (below pivot)" },
  { index: 8, key: 'carouselLayout', text: "Carousel Layout (below pivot)" },
  { index: 7, key: 'carouselBuilder', text: "Alternate Carousel Layout (below pivot)" },
  { index: 3, key: 'header', text: "Above" },
  { index: 4, key: 'footer', text: "Below" },
  { index: 1, key: 'left', text: "Left side" },
  { index: 2, key: 'right', text: "Right side" },
  { index: 9, key: 'none', text: "None" },
];

export function getHeroChoice(findMe: IGetHeroChoice) {
  if (findMe === 'left') {
    return "left";
  } else if (findMe === 'right') {
    return "right";
  } else if (findMe === 'header') {
    return "header";
  } else if (findMe === 'footer') {
    return "footer";
  } else if (findMe === 'none') {
    return "none";
  } else {
    return "left";
  }
}
