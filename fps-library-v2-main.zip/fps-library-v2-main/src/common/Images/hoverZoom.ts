import { IPropertyPaneDropdownOption } from '@microsoft/sp-property-pane';

export type IImageZoom = '1.0' | '1.1' | '1.2' | '1.5' | '2.0';

export const hoverZoomChoices: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
  { index: 0, key: '1.1', text: "1.1 x" },
  { index: 1, key: '1.2', text: "1.2 x" },
  { index: 9, key: '1.0', text: "1.0 - no zoom animation" },
];

export const hoverZoomChoicesAll: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
  { index: 0, key: '1.1', text: "1.1 x" },
  { index: 1, key: '1.2', text: "1.2 x" },
  { index: 2, key: '1.5', text: "1.5 x" },
  { index: 3, key: '2.0', text: "2.0 x" },
  { index: 9, key: '1.0', text: "1.0 - no zoom animation" },
];

export function getHoverZoom(findMe: IImageZoom) {
  if (findMe === '1.0') {
    return 1;
  } else if (findMe === '1.1') {
    return 1.1;
  } else if (findMe === '1.2') {
    return 1.2;
  } else if (findMe === '1.5') {
    return 1.2;
  } else if (findMe === '2.0') {
    return 1.2;
  } else {
    return 0;
  }
}
