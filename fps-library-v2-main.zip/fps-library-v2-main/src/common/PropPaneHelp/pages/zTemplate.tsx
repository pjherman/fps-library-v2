// import * as React from 'react';
// import { Icon, } from 'office-ui-fabric-react/lib/Icon';

// import { escape } from '@microsoft/sp-lodash-subset';

// import { PivotItem, } from 'office-ui-fabric-react/lib/Pivot';

// const padRight15: React.CSSProperties = { paddingRight: '15px' };
// const padRight40: React.CSSProperties = { paddingRight: '40px' };
