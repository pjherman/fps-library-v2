

export const SampleCharts: any = [
  {
    "primaryField": "Id",
    "title": "Count of items",
    "stat": "count",
    "chartTypes": [
      "pareto-dec",
      "stacked-column-labels"
    ]
  }
];