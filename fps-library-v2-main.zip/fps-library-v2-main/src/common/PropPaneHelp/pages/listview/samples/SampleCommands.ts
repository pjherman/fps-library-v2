import { IQuickButton } from "../../../../../components/interfaces/indexes";

export const SampleDividerButton: IQuickButton = { 
      "type": "divider",
      "label": "Tip:  CTRL-Click a button to show commands",
      "icon": "TouchPointer"
    } as IQuickButton;

export const SampleLabelButton: IQuickButton = { 
  "type": "label-only",
  "label": "Have a nice day!",
  "icon": "Emoji2"
} as IQuickButton;

export const SampleCommands: any = {
  "buttons": [[{
      "strPrev": "PREVIOUS Choice Value",
      "str1": "In Process",
      "strNext": "NEXT Choice Value",
      "label": "Set to {str1}",
      "primary": false,
      "confirm": "Are you sure you want to Set to {str1}",
      "alert": "We made our updates!",
      "console": "Message to browser console",
      "panelMessage": "Updated item to {str1}",
      "icon": "UserWarning",
      "updateItem": {
        "DueDate": "[today+14]",
        "AssignedToId": "[Me]",
        "Status": "{str1}",
        "ReviewDays": 99,
        "Body": "Hi! It's [Today+3] and I'm $MyName$",
      },
      // https://github.com/mikezimm/drilldown7/issues/246
      "showWhenEvalTrue": "item.AssignedToTitle !== sourceUserInfo.Title && item.Status === {strPrev}"
    }
  ],[
    SampleDividerButton
  ],[
    SampleLabelButton
  ]


],
  "fields": [],
};

export const AdvancedCommands: any = {
  "updateItem": {
    "Comments": "{{append rich stamp require}}",
    "SharePointLink": "{{spo require}}",
    "OtherLink": "{{link require}}",
    // https://github.com/mikezimm/drilldown7/issues/245
    "CaptchaField": "{{captcha=Author/Title?Verify Created By Name}}",
    //https://github.com/mikezimm/drilldown7/issues/244,   // https://github.com/mikezimm/drilldown7/issues/246
    "ConditionalDate": "eval( item.TESTCOLUMN===`{str1}` ? `[Today]` : item.TESTCOLUMN===`{strNext}` ? null : item.TESTCOLUMN )",
  }
};
