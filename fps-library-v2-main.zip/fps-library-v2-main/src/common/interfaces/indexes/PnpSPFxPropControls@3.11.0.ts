
import type { IPropertyFieldGroupOrPerson,  } from "../openSource/spfxPropControls/@3.11.0/IPropertyFieldGroupOrPerson";
import type { IPropertyPaneWebPartInformationProps, IVideoEmbedProperties } from "../openSource/spfxPropControls/@3.11.0/IPropertyPaneWebPartInformationProps";

export { IPropertyFieldGroupOrPerson, IPropertyPaneWebPartInformationProps, IVideoEmbedProperties };
