
import type { DisplayMode, } from "../@msft/1.15.2/displayMode";

export { DisplayMode, };

