
// import type { SPPermissionCopy_15_2,  } from "../common/interfaces/@msft/WebPermissionsClass@1.15.2";
// import { SPPermissionCopy_15_2,  } from "../common/interfaces/@msft/WebPermissionsClass@1.15.2";

// export { IODataBasePermission_15_2, SPPermissionCopy_15_2, };


