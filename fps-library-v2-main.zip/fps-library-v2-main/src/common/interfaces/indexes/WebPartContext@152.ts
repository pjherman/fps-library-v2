
import { PageContextCopy_15_2, WebPartContextCopy_15_2,  } from "../@msft/1.15.2/WebPartContext";

export { PageContextCopy_15_2, WebPartContextCopy_15_2, };


