
import type { IPageLayoutType, ISupportedHost } from "../@msft/1.15.2/layout";

export { IPageLayoutType, ISupportedHost, };

