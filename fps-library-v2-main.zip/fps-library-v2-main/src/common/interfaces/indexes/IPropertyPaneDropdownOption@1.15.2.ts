
import type { IPropertyPaneDropdownOption_15_2,  } from "../@msft/1.15.2/IPropertyPaneDropdownOption";
import { PropertyPaneDropdownOptionType_15_2,  } from "../@msft/1.15.2/PropertyPaneDropdownOptionType";

export { IPropertyPaneDropdownOption_15_2, PropertyPaneDropdownOptionType_15_2, };