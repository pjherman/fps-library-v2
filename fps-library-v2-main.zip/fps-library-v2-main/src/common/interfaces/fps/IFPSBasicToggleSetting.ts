/**
 * Used for Expandoramic viewing and
 */
export type IFPSBasicToggleSetting = 'skip' | true | false;
