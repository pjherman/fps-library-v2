
export interface IPickedView {
  title: string;
  name: string;
  guid: string;
}
