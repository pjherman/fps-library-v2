
export interface IPickedList {
  title: string;
  name: string;
  guid: string;
  isLibrary: boolean;
}
