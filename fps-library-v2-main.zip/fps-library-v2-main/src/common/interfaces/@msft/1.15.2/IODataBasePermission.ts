
/**
 * Data used for creating a SPPermission object.
 * Copied from 1.15.2 project:  node_modules\@microsoft\sp-odata-types\dist\index-internal.d.ts 
 * @public
 */
 export interface IODataBasePermission_15_2 {
  Low: number;
  High: number;
}