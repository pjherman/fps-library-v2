import { IPropertyPaneDropdownOption, } from "@microsoft/sp-property-pane";

import { PivotLinkSize, PivotLinkFormat } from 'office-ui-fabric-react/lib/Pivot';
import { IPivotFormatChoices, IPivotSizeChoices } from "./Types";


export const pivFormatChoices: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
    {   index: 0,   key: 'links', text: 'Links'  },
    {   index: 1,   key: 'tabs', text: 'Tabs'  },
];

export const  pivSizeChoices: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
    {   index: 0,   key: 'normal', text: "Normal"  },
    {   index: 1,   key: 'large', text: "Large"  },
];

export const  pivOptionsChoices: IPropertyPaneDropdownOption[] = <IPropertyPaneDropdownOption[]>[
    {   index: 0,   key: 'count', text: "Count"  },
    {   index: 1,   key: 'icon', text: "icon"  },
];

export function getPivFormat (findMe: IPivotFormatChoices) {
    if (findMe === 'tabs') {
        return PivotLinkFormat.tabs;
    } else {
        return PivotLinkFormat.links;
    }
}

export function getPivSize (findMe: IPivotSizeChoices) {
    if (findMe === 'large') {
        return PivotLinkSize.large;
    } else {
        return PivotLinkSize.normal;
    }
}

