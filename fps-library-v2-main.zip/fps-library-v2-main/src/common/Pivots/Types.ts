export type IPivotOptionChoices = 'count' | 'icon';

export type IPivotFormatChoices = 'tabs' | 'links';

export type IPivotSizeChoices = 'large' | 'normal';