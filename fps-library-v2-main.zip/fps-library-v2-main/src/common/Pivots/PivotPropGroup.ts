import {
  IPropertyPaneGroup,
  PropertyPaneDropdown,
  IPropertyPaneDropdownProps,
  IPropertyPaneField,
} from '@microsoft/sp-property-pane';
import { pivFormatChoices, pivOptionsChoices, pivSizeChoices } from './PivotOptions';


export function buildPivotStylesGroup( ): IPropertyPaneGroup  {

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const groupFields: IPropertyPaneField<any>[] = [];

  groupFields.push(
    PropertyPaneDropdown('setPivSize', <IPropertyPaneDropdownProps>{
      label: `Set Pivot Size`,
      options: pivSizeChoices,
    })
  );

  groupFields.push(
    PropertyPaneDropdown('setPivFormat', <IPropertyPaneDropdownProps>{
      label: `Set Pivot Format`,
      options: pivFormatChoices,
    })
  );

  groupFields.push(
    PropertyPaneDropdown('setPivOptions', <IPropertyPaneDropdownProps>{
      label: `Select Pivot Options`,
      options: pivOptionsChoices,
      disabled: true,
    })
  );

  const ExportThisGroup: IPropertyPaneGroup = {
    groupName: `Pivot Styles`,
    isCollapsed: true,
    groupFields: groupFields
  };

  return ExportThisGroup;

}
